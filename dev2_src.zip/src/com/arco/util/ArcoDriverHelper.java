package com.arco.util;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.scripts.ASMLoginTest;




public abstract class ArcoDriverHelper 
{
	public static final Logger logger = Logger.getLogger(ArcoDriverHelper.class);
	// Define objects
	
	protected static WebDriver driver;
	public PropertyReaderArco propertyReader;
	protected static WebDriverWait ajaxWait;
	private String time;
	private int TIME_OUT;
	private String pageLoadTime;
	private int PAGE_LOAD_TIME_OUT;
	protected Robot robot;

	// Declare objects
	public ArcoDriverHelper(WebDriver webdriver) {
		ArcoDriverHelper.driver = webdriver;
		propertyReader = new PropertyReaderArco();
		initializeTimeOutValues();
		ajaxWait = new WebDriverWait(driver, TIME_OUT);
		try {
			robot = new Robot();
		} catch (AWTException e) {
			Assert.fail("AWT Exception");
			e.printStackTrace();
		}
	}
	
	

	// Handle locator type
	public static By byLocator(final String locator) {
		By result = null;

		if (locator.startsWith("//")) {
			result = By.xpath(locator);
		} else if (locator.startsWith("css=")) {
			result = By.cssSelector(locator.replace("css=", ""));
		} else if (locator.startsWith("#")) {
			result = By.name(locator.replace("#", ""));
		} else if (locator.startsWith("Link=")) {
			result = By.linkText(locator.replace("Link=", ""));
		} else if (locator.startsWith("xpath=")) {
			result = By.xpath(locator);
		}

		else if (locator.startsWith("(//")) {
			result = By.xpath(locator);
		} else {
			result = By.id(locator);
		}
		return result;
	}

	// Assert element present
	public static Boolean isElementPresent(final String locator) {
		Boolean result = false;
		try {
			driver.findElement(byLocator(locator));
			result = true;
		} catch (final Exception ex) {
		}
		return result;
	}
	
	public Boolean isElementPresent(final WebElement ele)
	{
		Boolean result = false;
		try
		{
			ele.isDisplayed();
			result = true;
		} catch (final Exception ex)
		{
			
		}
		return result;
	}
	
	

	public void saveForm() throws InterruptedException, AWTException {
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_S);
		Thread.sleep(1000);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_S);
		Thread.sleep(1000);
	}

	// Wait for element present
	public static void waitForElementPresent(final String locator, final int timeout) {
		ajaxWait.until(ExpectedConditions.presenceOfElementLocated(byLocator(locator)));
	
	}

	// Wait for element present for WebElement
	public static void waitForWebElementPresent(WebElement element, int timeout) {
		try{
			ajaxWait.until(ExpectedConditions.visibilityOf(element));
		}
		catch ( Error e) {
			Reporter.log("WebElement "+element+" is missing ");
			e.printStackTrace();
			throw e;
		} catch ( Exception e) {
			Reporter.log("WebElement "+element+" is missing ");
			e.printStackTrace();
			throw e;
		}
		
	}
	
	public String getXpathOfABaseProduct(String baseProductId)
	{
		String xpath = "//a[contains(@href,'/p/"+baseProductId+"')]";
		return xpath;
	}
	
	public ProductDetailsPage clickOnAProduct(String productid)
	{
		String locator = "//a[contains(@href,'/p/"+productid+"')]";
		waitForElementPresent(locator, getTimeOut());
		scrollToElementView(driver.findElement(byLocator(locator)));
		clickOn(locator, productid+" base product");
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	

	// Wait for element not present
	public void waitForElementNotPresent(final String locator, final int timeout) {
		ajaxWait.until(ExpectedConditions.invisibilityOfElementLocated(byLocator(locator)));
	}

	// Wait for element enabled
	public void waitForElementEnabled(final String locator, final int timeout) {
		ajaxWait.until(ExpectedConditions.visibilityOfElementLocated(byLocator(locator)));
	}
	
	// Wait for element enabled
		public void waitForElementToBeClickable(WebElement element, final int timeout) {
			ajaxWait.until(ExpectedConditions.elementToBeClickable(element));
		}

	// Wait for element visible
	public static void waitForElementVisible(final String locator, final int timeout) {
		for (int i = 0; i < timeout; i++) {
			if (isElementPresent(locator)) {
				if (driver.findElement(byLocator(locator)).isDisplayed()) {
					break;
				}
			}

			try {
				Thread.sleep(1000);
			} catch (final InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	// Wait for element not visible
	public void waitForElementNotVisible(final String locator, final int timeout) {
		for (int i = 0; i < timeout; i++) {
			if (ArcoDriverHelper.isElementPresent(locator)) {
				if (!ArcoDriverHelper.isElementPresent(locator)) {
					break;
				}
			}

			try {
				Thread.sleep(1000);
			} catch (final InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	// Wait for text present
	public void waitForTextPresent(String locator, String text, final int timeout, final String element) {
		waitForElementPresent(locator, timeout);
		ajaxWait.until(ExpectedConditions.textToBePresentInElementLocated((byLocator(locator)), text));
	}

	// Wait for Alert
	public void waitForAlert() {
		ajaxWait = new WebDriverWait(driver, 30);
		ajaxWait.until(ExpectedConditions.alertIsPresent());
	}

	// Handle mouse over action
	public void mouseOver(final String locator) {
		waitForElementVisible(locator, 50);
		final WebElement el = driver.findElement(ArcoDriverHelper.byLocator(locator));

		// build and perform the mouseOver with Advanced User Interactions API
		final Actions builder = new Actions(driver);
		builder.moveToElement(el).build().perform();
		
	}

	// Handle mouse double click action
	public void mouseDoubleClick(final String locator) {
		waitForElementPresent(locator, 50);
		final WebElement el = driver.findElement(ArcoDriverHelper.byLocator(locator));

		// build and perform the mouse click with Advanced User Interactions API
		final Actions builder = new Actions(driver);
		builder.doubleClick(el);
	}

	// Handle mouse double click action
	public void mouseClick(final String locator) {
		waitForElementPresent(locator, 50);
		final WebElement el = driver.findElement(ArcoDriverHelper.byLocator(locator));

		// build and perform the mouse click with Advanced User Interactions API
		final Actions builder = new Actions(driver);
		builder.click(el).build().perform();
	}

	// Handle drag and drop action
	public void dragAndDrop(final String draggable, final String to) {
		waitForElementPresent(draggable, 50);
		waitForElementPresent(to, 50);
		final WebElement elDraggable = driver.findElement(ArcoDriverHelper.byLocator(draggable));
		final WebElement todrag = driver.findElement(byLocator(to));

		// build and perform drag and drop with Advanced User Interactions API
		final Actions builder = new Actions(driver);
		builder.dragAndDrop(elDraggable, todrag).build().perform();
	}

	public void clickOn(final String locator, final String element) {
		/*
		 * boolean result = false; int attempts = 0;
		 * 
		 * waitForElementPresent(locator, 30);
		 * Assert.assertTrue(isElementPresent(locator), "Element Locator :" +
		 * locator + " Not found for element" + element);
		 * 
		 * while (attempts < 2) { try { logger.debug("click On locator =" +
		 * locator + " for element " + element);
		 * driver.findElement(byLocator(locator)).click(); result = true; break;
		 * } catch (final StaleElementReferenceException e) { } attempts++; }
		 * return result;
		 */

		ajaxWait.until(ExpectedConditions.elementToBeClickable(byLocator(locator)));
		WebElement we = driver.findElement(byLocator(locator));

		try {
			new Actions(driver).moveToElement(we).perform();
			we.click();
		} catch (org.openqa.selenium.interactions.MoveTargetOutOfBoundsException e) {
			// Special case for partially visible elements
			_clickUsingJavaScript(we);
		}
	}

	// Handle click action
	public void typeString(final String locator, final String text, final String element) {
		waitForElementVisible(locator, 30);
		Assert.assertTrue(isElementPresent(locator),
				"Element Locator :" + locator + " Not found for element" + element);
		final WebElement el = driver.findElement(ArcoDriverHelper.byLocator(locator));
		final Actions builder = new Actions(driver);
		el.clear();
		builder.sendKeys(el, text).perform();
		logger.debug("click On locator =" + locator + " for element " + element);

	}

	public void enterPath(String path) throws InterruptedException {

		final Actions builder = new Actions(driver);
		builder.sendKeys(path).perform();

	}

	public void mouseClickByLocator(final String locator, final String element) {

		waitForElementVisible(locator, 30);
		Assert.assertTrue(isElementPresent(locator),
				"Element Locator :" + locator + " Not found for element" + element);
		final WebElement el = driver.findElement(ArcoDriverHelper.byLocator(locator));
		final Actions builder = new Actions(driver);
		builder.moveToElement(el).click(el);
		builder.perform();
		logger.debug("click On locator =" + locator + " for element " + element);
	}

	// Select value from drop down
	public void selectDropDown(final String locator, final String targetValue, final String element) {
		waitForElementPresent(locator, 20);
		Assert.assertTrue(isElementPresent(locator),
				"Element Locator :" + locator + " Not found for element" + element);
		new Select(driver.findElement(byLocator(locator))).selectByVisibleText(targetValue);
		logger.debug("Select value=" + targetValue + " from drop down" + element);

	}

	public void selectDropDown(final WebElement el, final String targetValue) {

		waitForWebElementPresent(el, 20);
		Assert.assertTrue(el.isDisplayed());
		Assert.assertTrue(el.isEnabled());
		new Select(el).selectByVisibleText(targetValue);
		logger.debug("Select value=" + targetValue + " from drop down");

	}
	
	public void dragAndDrop(final WebElement fromEle, final WebElement toEle)
	{
		waitForWebElementPresent(fromEle, 20);
		waitForWebElementPresent(toEle, 20);
		Assert.assertTrue(fromEle.isDisplayed());
		Assert.assertTrue(toEle.isDisplayed());
		final Actions builder = new Actions(driver);
		builder.dragAndDrop(fromEle, toEle).build().perform();
		
	}

	// Assert text present
	public boolean isTextPresent(final String locator, final String str, final String element) {
		Assert.assertTrue(isElementPresent(locator),
				"Element Locator :" + locator + " Not found for element" + element);
		final String message = driver.findElement(byLocator(locator)).getText();
		if (message.contains(str)) {
			logger.debug("Check " + message + " text present at locator " + locator + " for element " + element);
			return true;
		} else {
			return false;
		}

	}

	// Store text from a locator
	public String getText(final String locator, final String element) {
		waitForElementPresent(locator, 60);
		Assert.assertTrue(isElementPresent(locator),
				"Element Locator :" + locator + " Not found for element" + element);
		final String text = driver.findElement(byLocator(locator)).getText();
		logger.debug("Get text from the locator " + locator + " from element " + element);
		return text;
	}
	
	public String getText(final WebElement ele, final String webelementdetails)
	{
		waitForWebElementPresent(ele, getTimeOut());
		Assert.assertTrue(isElementPresent(ele));
		final String text = ele.getText();
		logger.debug("Get text from element "+webelementdetails);
		return text;
	}

	// Assert check box selected
	public boolean isChecked(final String locator, final String element) {
		boolean checkStatus = false;
		waitForElementPresent(locator, 20);
		Assert.assertTrue(isElementPresent(locator),
				"Element Locator :" + locator + " Not found for element" + element);
		final WebElement el = driver.findElement(ArcoDriverHelper.byLocator(locator));
		checkStatus = el.isSelected();
		logger.debug("Verfy " + locator + " is checked  for element " + element);
		return checkStatus;
	}

	// Get attribute value
	public String getAttribute(final String locator, final String attribute, final String element) {
		waitForElementPresent(locator, 20);
		Assert.assertTrue(isElementPresent(locator),
				"Element Locator :" + locator + " Not found for element" + element);
		final String text = driver.findElement(byLocator(locator)).getAttribute(attribute);
		logger.debug("Get attribute " + attribute + " from the locator " + locator + " from element " + element);
		return text;
	}

	// Execute java script
	public void javaScriptExecute(final String javascrpt) {
		final JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript(javascrpt);
	}

	public void acceptAlert(final int time) {
		this.selectAlertPresent(time);
	}

	public int getTotalRow(final String locator) {
		waitForElementVisible(locator, PAGE_LOAD_TIME_OUT);
		Assert.assertTrue(isElementPresent(locator), "Element " + locator + " is not present");
		final int number = driver.findElements(byLocator(locator)).size();
		logger.debug("Count total numbers of Rows at locator " + locator);
		return number;
	}

	// Switch frame
	public static void switchFrame(final String[] arr) {
		driver.switchTo().defaultContent();
		for (final String element : arr) {
			waitForElementVisible(element, 5);
			driver.switchTo().frame(element);
			System.out.println("Selected Frame" + arr);
		}
	}

	// Select value from drop down
	public void selectDropDownByIndex(final String locator, final int index, final String element) {
		Assert.assertTrue(isElementPresent(locator),
				"Element Locator :" + locator + " Not found for element" + element);
		waitForElementPresent(locator, 20);
		new Select(driver.findElement(byLocator(locator))).selectByIndex(index);
		logger.debug("Select index=" + index + " from drop down" + element);
	}
	
	public void selectDropDownByIndex(final WebElement ele, final int index)
	{
		waitForWebElementPresent(ele, getTimeOut());
		Assert.assertTrue(ele.isDisplayed());
		new Select(ele).selectByIndex(index);
	}

	public void dismissAlert() {

		final Alert alert = driver.switchTo().alert();
		alert.dismiss();

		logger.debug("Cancel the Alert Pop up");
	}

	public String selectParentWindow() {
		final Set<String> str = driver.getWindowHandles();
		final Iterator<String> itr = str.iterator();
		final String parrentId = itr.next();
		final String popUpId = itr.next();
		driver.switchTo().window(popUpId);
		return parrentId;
	}

	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			logger.debug("Check if alert present");
			return true;
		} catch (final NoAlertPresentException e) {
			return false;
		}
	}

	public String getCurrentWindowHandle() {
		final String winHandleBefore = driver.getWindowHandle();
		return winHandleBefore;

	}

	public String getNewWindowUrl() {
		_waitForJStoLoad();
		for (String newWinHandle : driver.getWindowHandles())
			driver.switchTo().window(newWinHandle);
		return driver.getCurrentUrl();
	}

	public void closeNewPopup(final String parentWindow) {
		for (final String winHandle : driver.getWindowHandles()) {
			if (!winHandle.equalsIgnoreCase(parentWindow)) {
				driver.switchTo().window(winHandle);
				driver.close();
			}
		}

	}

	public void setWindowHandle(final String winHandleBefore) {
		driver.switchTo().window(winHandleBefore);
	}

	public void selectAlertPresent(final int time) {

		for (int i = 0; i < time; i++) {
			if (isAlertPresent()) {
				final Alert alert = driver.switchTo().alert();
				alert.accept();

				break;

			}
			try {
				Thread.sleep(1000);
			} catch (final InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	// /Method to be deleted//
	// Handle send keys action
	public void sendKeys(final String locator, final String text, final String element) {
		waitForElementPresent(locator, 30);
		Assert.assertTrue(isElementPresent(locator),
				"Element Locator :" + locator + " Not found" + " Not found for element" + element);
		final WebElement el = driver.findElement(ArcoDriverHelper.byLocator(locator));
		el.clear();
		el.sendKeys(text);
		logger.debug("Entered text: " + text + " at locator: " + locator + " for element " + element);

	}

	public void sendKeysWithoutRemovingPreviousText(final String locator, final String text, final String element) {
		waitForElementPresent(locator, 30);
		Assert.assertTrue(isElementPresent(locator),
				"Element Locator :" + locator + " Not found" + " Not found for element" + element);
		final WebElement el = driver.findElement(ArcoDriverHelper.byLocator(locator));
		el.sendKeys(text);
		logger.debug("Entered text: " + text + " at locator: " + locator + " for element " + element);
	}

	public void scrollWindow(final int x, final int y) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(" + x + "," + y + ")");
		logger.debug("Scroll up the window");
	}

	public void scrollWindowToBottomOfPage() {
		final JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollTo(0,document.body.clientHeight)");
		logger.debug("Scroll Down till bottom of the page");
	}

	public void scrollWindowToBottomOfScrollHeight() {
		final JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		logger.debug("Scroll Down till bottom of the page");
	}

	public void scrollWindowToTopOfPage() {
		final JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollTo(0,0)");
		logger.debug("Scroll Up the page");
	}

	public void scrollWindowToElement(WebElement el) {
		final JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", el);
		logger.debug("Scroll To Element");
	}

	public boolean verifyAlertPresent(final int time) {

		for (int i = 0; i < time; i++) {
			if (isAlertPresent()) {
				return true;
			}
		}
		return false;
	}

	public boolean isDialogPresent() {
		try {
			driver.getTitle();
			return true;
		} catch (final NoAlertPresentException e) {
			return false;
		}
	}

	public void mouseClickByWebElement(final WebElement locator) {
		final Actions builder = new Actions(driver);
		builder.moveToElement(locator).click(locator);
		builder.perform();
	}

	// ****************POM Framework Methods*************//
	public void initializeTimeOutValues() {
		time = propertyReader.readApplicationFile("Time_Out");
		TIME_OUT = Integer.parseInt(time);
		pageLoadTime = propertyReader.readApplicationFile("Page_Load_Time_Out");
		PAGE_LOAD_TIME_OUT = Integer.parseInt(pageLoadTime);
	}

	public int getTimeOut() {
		// System.out.println("System time :" + TIME_OUT);
		return TIME_OUT;
	}

	public int getPageLoadTimeOut() {
		return PAGE_LOAD_TIME_OUT;
	}

	public void selectFramePM() {
		switchFrame(new String[] { "content", "jspFrame", "content" });
	}

	public void selectJSPFrame() {
		driver.switchTo().defaultContent();
		switchFrame(new String[] { "jspFrame", "content" });
		logger.debug("Switching the frame");
	}



	@SuppressWarnings({ "unchecked", "rawtypes" })
	public <T> T clickonData(final String text, final String element, final Class className) {
		final String locator = "//nobr[contains(text(),'" + text + "')]";
		waitForElementVisible(locator, TIME_OUT);
		clickOn(locator, element);
		return (T) PageFactory.initElements(driver, className);
	}

	// Wait for element not present
	public void waitForWebElementNotPresent(WebElement element, final int timeout) {
		for (int i = 0; i < timeout; i++) {
			if (!element.isDisplayed()) {
				logger.debug("Locator :" + element + " is displayed in " + timeout + "seconds");
				break;
			}

			try {
				Thread.sleep(1000);
			} catch (final InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

	public void waitForElementNotEnabled1(final String locator, final int timeout) {
		
		for (int i = 0; i < timeout; i++) {
			if (!driver.findElement(byLocator(locator)).isEnabled()) {
				break;
			}

			try {
				Thread.sleep(1000);
			} catch (final InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public <T> T scrollWindow(final int x, final int y, Class className) {
		final JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(" + x + "," + y + ")", "");
		logger.debug("Scroll Down the window");
		return (T) PageFactory.initElements(driver, className);
	}

	public void clear(final String locator, final String element) {
		waitForElementPresent(locator, 30);
		Assert.assertTrue(isElementPresent(locator),
				"Element Locator :" + locator + " Not found" + " Not found for element" + element);
		final WebElement el = driver.findElement(ArcoDriverHelper.byLocator(locator));
		el.clear();
		logger.debug("Cleared text:  at locator: " + locator + " for element " + element);
	}

	public void openNewWindow() throws InterruptedException, AWTException {
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_N);
		Thread.sleep(1000);
		robot.keyRelease(KeyEvent.VK_N);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		Thread.sleep(1000);
	}

	public void runQuery() throws InterruptedException, AWTException {

		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ALT);
		robot.keyPress(KeyEvent.VK_Q);
		Thread.sleep(1000);
		robot.keyRelease(KeyEvent.VK_Q);
		robot.keyRelease(KeyEvent.VK_ALT);
		Thread.sleep(1000);
	}

	// Get random integer
	public int getRandomInteger(final long aStart, final long aEnd) {
		final Random aRandom = new Random();
		if (aStart > aEnd) {
			throw new IllegalArgumentException("Start cannot exceed End.");
		}
		// get the range, casting to long to avoid overflow problems
		final long range = aEnd - aStart + 1;
		// compute a fraction of the range, 0 <= frac < range
		final long fraction = (long) (range * aRandom.nextDouble());
		final int randomNumber = (int) (fraction + aStart);
		return randomNumber;
	}

	// Get random string
	public String randomString(final int len) {
		final String AB = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		final Random rnd = new Random();
		final StringBuilder sb = new StringBuilder(len);
		for (int i = 0; i < len; i++) {
			sb.append(AB.charAt(rnd.nextInt(AB.length())));
		}
		return sb.toString();
	}

	private Object _executeJavaScript(String jsCode) {
		return ((JavascriptExecutor) ArcoDriverHelper.driver).executeScript(jsCode);
	}

	// wait for jQuery to load
	private final ExpectedCondition<Boolean> jQueryLoad = new ExpectedCondition<Boolean>() {
		@Override
		public Boolean apply(WebDriver theDriver) {
			try {
				return ((Long) ArcoDriverHelper.this._executeJavaScript("return jQuery.active") == 0);
			} catch (Exception e) {
				return true;
			}
		}
	};

	
	private final ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
		@Override
		public Boolean apply(WebDriver theDriver) {
			Object rsltJs = ArcoDriverHelper.this._executeJavaScript("return document.readyState");
			if (rsltJs == null) {
				rsltJs = "";
			}
			return rsltJs.toString().equals("complete") || rsltJs.toString().equals("loaded");
		}
	};


	private WebDriverWait _getWebDriverWait(int timeoutInSeconds) {
		return new WebDriverWait(ArcoDriverHelper.driver, timeoutInSeconds);
	}

	public boolean _waitForJStoLoad() {

		WebDriverWait wait = this._getWebDriverWait(getTimeOut());
		boolean waitDone = wait.until(this.jQueryLoad) && wait.until(this.jsLoad);

		return waitDone;
	}
	
	public void _waitForPageLoad(WebDriver driver) 
	{
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>()
				{
			public Boolean apply(WebDriver driver)
			{
				return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("completed");
			}
			
				};
				Wait<WebDriver> wait = new WebDriverWait(driver, 30);
				try
				{
					wait.until(expectation);
				} catch (Throwable error)
				{
					Assert.assertFalse(false, "Timeout waiting for Page Load Request to complete.");
				}
				

	    
	}

	public void scrollUp() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(250,0)", "");
		System.out.println("scrolled up");
	}


	public void scrollWindowToLocator(String locator) {
		final JavascriptExecutor jse = (JavascriptExecutor) driver;
		WebElement el = driver.findElement(byLocator(locator));
		jse.executeScript("arguments[0].scrollIntoView(true);", el);
		logger.debug("Scroll To Element");
	}
	
	public void scrollToWebElement(WebElement element)
	{
		final JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	
	public void scrollToElementView(WebElement element) {
		Point point = element.getLocation();
		int yaxis = point.getY() - 150;
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + yaxis + ");");
	}


	public WebElement getElement(String locator) {
		return driver.findElement(byLocator(locator));
	}

	
	public List<WebElement> getElements(String locator) {
		return driver.findElements(byLocator(locator));
	}

	
	public void waitTillElementClickable(WebElement element) {
		ajaxWait.until(ExpectedConditions.elementToBeClickable(element));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void waitTillElementClickable(String locator) {
		WebElement el = driver.findElement(byLocator(locator));
		ajaxWait.until(ExpectedConditions.elementToBeClickable(el));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}



	public void navigateBack() {
		driver.navigate().back();
		_waitForJStoLoad();
		System.out.println("Navigate Back.");
	}

	public void pressTab() throws InterruptedException, AWTException {

		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_TAB);
        Thread.sleep(2000);
	}

	public void pressEnter(String locator) throws InterruptedException, AWTException {
		Thread.sleep(1000);
		WebElement el = driver.findElement(byLocator(locator));
		el.sendKeys(Keys.ENTER);

	}


	public String presenttDate() {
		DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String currentDate = format.format(date);
		return currentDate;
	}



	public static void _clickUsingJavaScript(WebElement we) {
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", we);
	}


	public void pressKey(final Keys keyName) {
		// build and perform the keypress with Advanced User Interactions API
		final Actions builder = new Actions(driver);
		builder.keyDown(keyName);
	}

	
	public void releaseKey(final Keys keyName) {
		// build and perform the keypress with Advanced User Interactions API
		final Actions builder = new Actions(driver);
		builder.keyUp(keyName);
	}

	
	public void enterValueInFieldInput(WebElement fieldInput, String value) {
		_waitForJStoLoad();
		fieldInput.click();
		fieldInput.clear();
		fieldInput.sendKeys(value);
		fieldInput.sendKeys(Keys.ENTER);
	}


	public void waitForElementPresent(int time) {
		driver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
	}
	
	
	
	public void upload(String path) throws InterruptedException, AWTException {
		
		StringSelection stringSelection = new StringSelection(path);
	    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	    clipboard.setContents(stringSelection, stringSelection);
	    robot.keyPress(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_C);
	    Thread.sleep(1000);
	    robot.keyRelease(KeyEvent.VK_C);
	    robot.keyRelease(KeyEvent.VK_CONTROL);
	    Thread.sleep(1000);
	    robot.keyPress(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_V);
	    Thread.sleep(1000);
	    robot.keyRelease(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_CONTROL);
	    Thread.sleep(1000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
		
		Thread.sleep(1000);
	}

	
	
	public void scrollToRightWindow(){
		final JavascriptExecutor jse = (JavascriptExecutor) driver;
		
		jse.executeScript("window.scrollBy(2000,0)", "");
		logger.debug("Scroll Down till bottom of the page");
	}
	public void scrollToLeftWindow(){
		final JavascriptExecutor jse = (JavascriptExecutor) driver;
		
		jse.executeScript("window.scrollBy(-2000,0)", "");
		logger.debug("Scroll Down till bottom of the page");
	}
	
	public void scrollToElementViewOnScreen(WebElement element) {
		Point point = element.getLocation();
		int xaxis = point.getX();
		int yaxis = point.getY();
		((JavascriptExecutor) driver).executeScript("window.scrollTo(" + xaxis + "," + yaxis + ");");
	}
	
	public void accept_Alert(){
		Alert alert= driver.switchTo().alert();
		alert.accept();
	}
	
	public List<WebElement> allWebElement(String locator)
	{
		List<WebElement> allelement = driver.findElements(byLocator(locator));
		return allelement;
	}

}
