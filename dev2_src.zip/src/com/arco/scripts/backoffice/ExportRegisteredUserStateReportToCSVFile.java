package com.arco.scripts.backoffice;

import org.testng.annotations.Test;

import com.arco.pages.backoffice.BackofficeDashboardPage;
import com.arco.pages.backoffice.BackofficeHomePage;
import com.arco.util.ArcoDriverTestCase;

public class ExportRegisteredUserStateReportToCSVFile extends ArcoDriverTestCase
{
	
	private String test, searchTerm;
	private BackofficeHomePage backofficeHomePage;
	private BackofficeDashboardPage backofficeDashboardPage;
	
	@Test
	public void exportRegisteredUserStateReportToCSVFile()
	{
		try
		{
			test = propertyReader.getCellData(28, 1);
			searchTerm = propertyReader.getCellData(28, 2);
			backofficeHomePage = applicationSetupBackoffice();
			backofficeDashboardPage = backofficeHomePage.login();
			backofficeDashboardPage.enterSearchTermInSearchTreeBox(searchTerm);
			
			
		}catch(Exception e)
		{
			
		}catch(Error e)
		{
			
		}
	}

}
