package com.arco.scripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.backoffice.BackofficeDashboardPage;
import com.arco.pages.backoffice.BackofficeHomePage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;
import com.arco.util.TestData;

public class UserCanLogintoBackOfficeTest extends ArcoDriverTestCase
{
	private String test, expectedTitle, actualTitle;
	private BackofficeHomePage backofficeHomePage;
	private BackofficeDashboardPage backofficeDashboardPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void verifyingUserCanLoginToBackoffice() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(9, 1);
			expectedTitle = propertyReaderArco.getCellData(9, 2);
			
			backofficeHomePage = applicationSetupBackoffice();
			backofficeDashboardPage = backofficeHomePage.login();
			actualTitle = backofficeDashboardPage.getText("//span[contains(@id,'e80')]", "Here we are fatching title of backoffice after login");
			System.out.println(actualTitle);
			softAssert.assertEquals(actualTitle, expectedTitle);
			softAssert.assertAll();
			
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
