package com.arco.scripts;


import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.asm.ASMDashboardPage;
import com.arco.pages.asm.ASMHomePage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;
import com.arco.util.ReTryAnalyzer;
import com.aventstack.extentreports.Status;




public class ASMLoginTest extends ArcoDriverTestCase
{
	
	public static final Logger logger = Logger.getLogger(ASMLoginTest.class);
	
	
	private String test, expectedArcoAdminName, expectedArcoSupportName;
	private ASMHomePage asmHomePage;
	private ASMDashboardPage asmDashboardPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;
	/*
	private ExtentHtmlReporter htmlRepoter;
	private ExtentReports extent;
	private ExtentTest repoterLog;
	
	@BeforeTest
	public void startReport()
	{
		htmlRepoter = new ExtentHtmlReporter(System.getProperty("user.dir")+"/test-output/learnReport.html");
		extent = new ExtentReports();
		extent.attachReporter(htmlRepoter);
		extent.setSystemInfo("OS", "Window 7");
		extent.setSystemInfo("Host Name:", "Sanjoy");
		extent.setSystemInfo("Environment", "QA");
		extent.setSystemInfo("User Name:", "Sanjoy");
		
		htmlRepoter.config().setDocumentTitle("Automation demo");
		htmlRepoter.config().setReportName("My Own Report");
		htmlRepoter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlRepoter.config().setTheme(Theme.DARK);
	}
	
	@AfterMethod
	public void getResult(ITestResult result)
	{
		if(result.getStatus()==ITestResult.FAILURE)
		{
			repoterLog.log(Status.FAIL, MarkupHelper.createLabel(result.getName()+"Test case failed", ExtentColor.RED));
			repoterLog.fail(result.getThrowable());
		}
		else if(result.getStatus()==ITestResult.SUCCESS)
		{
			repoterLog.log(Status.PASS, MarkupHelper.createLabel(result.getName()+"Test case pass", ExtentColor.GREEN));
		}
		else
		{
			repoterLog.log(Status.SKIP, MarkupHelper.createLabel(result.getName()+"Test case skiped", ExtentColor.YELLOW));
			repoterLog.skip(result.getThrowable());
		}
		
	}
	
	@AfterMethod
	public void tearDown1()
	{
		extent.flush();
	}
	*/
	
	@Test(retryAnalyzer=ReTryAnalyzer.class)
	public void asmLoginTestAsArcoAdmin() throws Exception
	{
		 
		
		try
		{
			
			
			
			repoterLog = extent.createTest("asmLoginTestAsArcoAdmin");
			
			
			softAssert = new SoftAssert();
			logger.info("Creating object of Soft assert");
			propertyReaderArco = new PropertyReaderArco();
			test = propertyReaderArco.getCellData(10, 1);
			expectedArcoAdminName = propertyReaderArco.getCellData(10, 2);
		    asmHomePage = applicationSetupASM();
		    repoterLog.log(Status.INFO, "Application setup completed");
		    asmDashboardPage = asmHomePage.loginAsArcoAdmin();
		    repoterLog.log(Status.INFO, "Login completed");
		    addLog("Opening ASM");
		    String actualArcoUser = asmDashboardPage.getText("(//span[@class='ASM_loggedin_text_name'])[2]", "Here we are fetching the Arco admin name for verification");
		    try
		    {
		    	softAssert.assertTrue(actualArcoUser.equals(expectedArcoAdminName));
		    	repoterLog.log(Status.PASS, "Soft assert got passed");
		    } catch(AssertionError e)
		    {
		    	repoterLog.log(Status.FAIL, "Soft assert got failed");
		    }
		    
		    
		    asmHomePage = asmDashboardPage.clickOnLogOutButton();
		    repoterLog.log(Status.INFO, "Login completed");
		    softAssert.assertAll();
		    repoterLog.log(Status.PASS, "Verification got passed");
		    
		    
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
		
		
	}
	/*
	
	@Test
	public void test()
	{
		repoterLog = extent.createTest("test");
		Assert.assertTrue(true);
	}
	
	/*
	@Test
	public void asmLoginTestAsArcoSupport() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(11, 1);
			expectedArcoSupportName = propertyReaderArco.getCellData(11, 2);
			
			asmDashboardPage = asmHomePage.loginAsArcoSupport();
			String actualArcoUser = asmDashboardPage.getText("(//span[@class='ASM_loggedin_text_name'])[2]", "Here we are fetching the Arco admin name for verification");
			softAssert.assertEquals(actualArcoUser, expectedArcoSupportName);
			asmHomePage = asmDashboardPage.clickOnLogOutButton();
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}
	*/

}
