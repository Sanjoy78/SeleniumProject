package com.arco.scripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.arco.pages.backoffice.BackofficeDashboardPage;
import com.arco.pages.backoffice.BackofficeHomePage;
import com.arco.pages.storefront.CategoryListPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.MyAccountPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;
import com.arco.util.TestData;

public class AddUpdateRemoveProductFromBasketTest extends ArcoDriverTestCase
{
	private String test, userName, passWord, productID, numberOfTime;
	private HomePage homePage; 
	private DashboardPage dashboardPage;
	private CategoryListPage categoryListPage;
	private MyAccountPage myAccountPage;
	private BackofficeHomePage backofficeHomePage;
	private BackofficeDashboardPage backofficeDashboardPage;
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void addUpdateRemoveProductsFromBasketPage() throws Exception
	{
		try
		{
			test = propertyReaderArco.getCellData(4, 1);
			userName = propertyReaderArco.getCellData(4, 2);
			passWord = propertyReaderArco.getCellData(4, 3);
			productID = propertyReaderArco.getCellData(4, 4);
			numberOfTime = propertyReaderArco.getCellData(4, 5);
			homePage = applicationSetup();
			addLog("Launching Arco Store front Home page");
			homePage.clickLoginRegister();
			addLog("Clicking on 'Register/Sign in' link");
			dashboardPage = homePage.login(userName, passWord);
			addLog("Signing with userid and password");
			dashboardPage.enterProductNameOrCode(productID);
			categoryListPage = dashboardPage.clickOnFindButton();
			categoryListPage.clickOnBuyNowButton();
			categoryListPage.clickOnincreaseQuantityButton(numberOfTime, "Here we are clicking 2 times");
			
			
		} catch (final Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (final Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
		
		
	}
	
	

}
