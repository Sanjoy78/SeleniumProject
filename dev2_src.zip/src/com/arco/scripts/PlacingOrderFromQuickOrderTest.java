package com.arco.scripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.BasketPage;
import com.arco.pages.storefront.CheckOutPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.OrderConfirmationPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;
import com.arco.util.TestData;

public class PlacingOrderFromQuickOrderTest extends ArcoDriverTestCase
{
	private String test, userId, passWord, productCode, numberOfItem, expectedMessage;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private BasketPage basketPage;
	private CheckOutPage checkOutPage;
	private OrderConfirmationPage orderConfirmationPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;

	@Test
	public void placingOrderForRegisteredUserFromQuickOrder() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(16, 1);
			userId = propertyReaderArco.getCellData(16, 2);
			passWord = propertyReaderArco.getCellData(16, 3);
			productCode = propertyReaderArco.getCellData(16, 4);
			numberOfItem =propertyReaderArco.getCellData(16, 5);
			expectedMessage = propertyReaderArco.getCellData(16, 6);

			
			homePage = applicationSetup();
			homePage.clickOnGotIt();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(userId, passWord);
			dashboardPage.clickOnQuickOrderButton();
			dashboardPage.enterProductID(productCode);
			dashboardPage.enterProductQty(numberOfItem);
			dashboardPage.clickOnAddToBasketButton();
			basketPage = dashboardPage.clickOnCheckOutButton();
			checkOutPage = basketPage.clickOnCheckOutButton();
			checkOutPage.clickOnUseThesePaymentDetailsButton();
			orderConfirmationPage = checkOutPage.clickOnPlaceOrderButton();
			String successMessage = orderConfirmationPage.getText("//p[@class='light-grey']", "Here we are retreving seccess message for verification");
			softAssert.assertEquals(successMessage, expectedMessage);
			orderConfirmationPage.clickOnUserName();
			orderConfirmationPage.clickOnLogOutButton();
			softAssert.assertAll();
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
