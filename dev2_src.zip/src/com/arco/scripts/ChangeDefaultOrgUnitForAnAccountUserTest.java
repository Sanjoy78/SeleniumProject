package com.arco.scripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.MyAccountPage;
import com.arco.pages.storefront.RolesGroupsAndOrgUnitsPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;


public class ChangeDefaultOrgUnitForAnAccountUserTest extends ArcoDriverTestCase
{
	private String test, userName, passWord, expectedText;
	private SoftAssert softAssert;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private MyAccountPage myAccountPage;
	private RolesGroupsAndOrgUnitsPage rolesGroupsAndOrgUnitsPage;
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void changeDefaultOrgUnitForAnAccountUser() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			test = propertyReaderArco.getCellData(5, 1);
			userName = propertyReaderArco.getCellData(5, 2);
			passWord = propertyReaderArco.getCellData(5, 3);
			expectedText = propertyReaderArco.getCellData(5, 4);
			
			softAssert = new SoftAssert();
			homePage = applicationSetup();
			homePage.clickOnGotIt();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(userName, passWord);
			dashboardPage.clickUserName();
			myAccountPage = dashboardPage.clickAccountOverview();
			rolesGroupsAndOrgUnitsPage = myAccountPage.clickManageRoleGroupsAndORGUnitsButton();
			String actualText1 = rolesGroupsAndOrgUnitsPage.getText("(//span[@class='light-grey dateAdded'])[2]", "We are getting text for org unit2");
			softAssert.assertEquals(actualText1, expectedText);
			rolesGroupsAndOrgUnitsPage.setOrgUnit1AsDefault();
			String actualText2 = rolesGroupsAndOrgUnitsPage.getText("(//span[@class='light-grey dateAdded'])[1]", "We are getting test for org unit1");
			softAssert.assertEquals(actualText2, expectedText);
			rolesGroupsAndOrgUnitsPage.setOrgUnit2AsDefault();
			String actualText3 = rolesGroupsAndOrgUnitsPage.getText("(//span[@class='light-grey dateAdded'])[2]", "We are getting text for org unit2");
			softAssert.assertEquals(actualText3, expectedText);
			softAssert.assertAll();
			
		} catch (final Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (final Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
