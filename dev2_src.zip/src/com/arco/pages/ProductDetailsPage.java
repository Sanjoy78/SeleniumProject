package com.arco.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class ProductDetailsPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//input[@name='items[2606007]']/following::span[@class='qtyPlus']")
	private WebElement increaseQuantityButton;
	
	@FindBy(how=How.XPATH, using="//button[@id='addToBasketPdpPage']")
	private WebElement addToBasketButton;
	
	@FindBy(how=How.XPATH, using="//a[@title='Checkout Now']")
	private WebElement checkOutButton;
	
	@FindBy(how=How.XPATH, using="(//span[@class='sku-badgesMsg'])[5]")
	private WebElement skuOf2606007;

	public ProductDetailsPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public ProductDetailsPage scrollToSKU()
	{
		waitForWebElementPresent(skuOf2606007, getTimeOut());
		Assert.assertTrue(skuOf2606007.isDisplayed());
		scrollToElementView(skuOf2606007);
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public BasketPage clickOnCheckOutButton()
	{
		waitForWebElementPresent(checkOutButton, getTimeOut());
		Assert.assertTrue(checkOutButton.isDisplayed());
		checkOutButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, BasketPage.class);
	}
	
	public ProductDetailsPage clickOnIncreaseQuantityButton(String number, String comment)
	{
		waitForWebElementPresent(increaseQuantityButton, getTimeOut());
		Assert.assertTrue(increaseQuantityButton.isDisplayed());
		for(int i=1; i<=Integer.parseInt(number); i++)
		{
			increaseQuantityButton.click();
		}
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public ProductDetailsPage clickOnAddToBasketButton()
	{
		waitForWebElementPresent(addToBasketButton, getTimeOut());
		Assert.assertTrue(addToBasketButton.isDisplayed());
		addToBasketButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}

}
