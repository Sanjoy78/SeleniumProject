package com.arco.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class PurchaseListPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//a[@href='purchasingList/createEdit']")
	private WebElement createListButton;
	
	@FindBy(how=How.XPATH, using="//input[@id='purchaseNameTest']")
	private WebElement purchaseListName;
	
	@FindBy(how=How.XPATH, using="//select[@id='purchasingListType']")
	private WebElement purchaseListType;
	
	@FindBy(how=How.XPATH, using="//button[@class='purchaseFormButton disablePurchaseButton']")
	private WebElement doneButtonForPurchaseListCreation;
	
	@FindBy(how=How.XPATH, using="//button[@class='purchaseListDone']")
	private WebElement doneButtonAfterPurchaseListCreation;
	
	@FindBy(how=How.XPATH, using="//i[@class='fa fa-ellipsis-v dropdownBar-icon dropdown-toggle']")
	private WebElement dotsOfPersonalPurchaseList;
	
	@FindBy(how=How.XPATH, using="//i[@class='fa fa-ellipsis-v dropdownBar-icon dropdown-toggle']")
	private WebElement dotsOfAccountPurchaseList;
	
	@FindBy(how=How.XPATH, using="//a[@title='Edit']")
	private WebElement editButtonForPersonalPurchaseList;
	
	@FindBy(how=How.XPATH, using="//a[@title='Edit']")
	private WebElement editButtonForAccountPurchaseList;
	
	@FindBy(how=How.XPATH, using="(//a[@title='Delete'])[1]")
	private WebElement deleteButtonForAccountPurchaseList;
	
	@FindBy(how=How.XPATH, using="(//a[@title='Delete'])[1]")
	private WebElement deleteButtonForPersonalPurchaseList;
	
	@FindBy(how=How.XPATH, using="//input[@id='searchUserPurchageListInput']")
	private WebElement searchBoxForPurchaseList;
	
	@FindBy(how=How.XPATH, using="(//button[@class='purchaseFormButton'])[2]")
	private WebElement yesButtonForPLDeletation;
	
	@FindBy(how=How.XPATH, using="(//button[@class='purchaseListDone'])[2]")
	private WebElement doneButtonAfterPurchaseListDeletation;
	
	
	
	public PurchaseListPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public PurchaseListPage clickOnDoneButtonAfterPLDeletation()
	{
		waitForWebElementPresent(doneButtonAfterPurchaseListDeletation, getTimeOut());
		Assert.assertTrue(doneButtonAfterPurchaseListDeletation.isDisplayed());
		doneButtonAfterPurchaseListDeletation.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnYesButtonForPLDetetation()
	{
		waitForWebElementPresent(yesButtonForPLDeletation, getTimeOut());
		Assert.assertTrue(yesButtonForPLDeletation.isDisplayed());
		yesButtonForPLDeletation.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnDeleteButtonForPersonalPurchaseList()
	{
		waitForWebElementPresent(deleteButtonForPersonalPurchaseList, getTimeOut());
		Assert.assertTrue(deleteButtonForPersonalPurchaseList.isDisplayed());
		deleteButtonForPersonalPurchaseList.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnDeleteButtonForAccountPurchaseList()
	{
		waitForWebElementPresent(deleteButtonForAccountPurchaseList, getTimeOut());
		Assert.assertTrue(deleteButtonForAccountPurchaseList.isDisplayed());
		deleteButtonForAccountPurchaseList.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnEditButtonForPersonalPurchaseList()
	{
		waitForWebElementPresent(editButtonForPersonalPurchaseList, getTimeOut());
		Assert.assertTrue(editButtonForPersonalPurchaseList.isDisplayed());
		editButtonForPersonalPurchaseList.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnEditButtonForAccountPurchaseList()
	{
		waitForWebElementPresent(editButtonForAccountPurchaseList, getTimeOut());
		Assert.assertTrue(editButtonForAccountPurchaseList.isDisplayed());
		editButtonForAccountPurchaseList.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnDotsOfAccoutPurchaseList()
	{
		waitForWebElementPresent(dotsOfAccountPurchaseList, getTimeOut());
		Assert.assertTrue(dotsOfAccountPurchaseList.isDisplayed());
		dotsOfAccountPurchaseList.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnDotsOfPersonalPurchaseList()
	{
		waitForWebElementPresent(dotsOfPersonalPurchaseList, getTimeOut());
		Assert.assertTrue(dotsOfPersonalPurchaseList.isDisplayed());
		dotsOfPersonalPurchaseList.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage searchPurchaseListByName(String plName)
	{
		waitForWebElementPresent(searchBoxForPurchaseList, getTimeOut());
		Assert.assertTrue(searchBoxForPurchaseList.isDisplayed());
		searchBoxForPurchaseList.sendKeys(plName);
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickCreateListButton()
	{
		waitForWebElementPresent(createListButton, getTimeOut());
		Assert.assertTrue(createListButton.isDisplayed());
		createListButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage enterPurchaseListName(String name)
	{
		waitForWebElementPresent(purchaseListName, getTimeOut());
		Assert.assertTrue(purchaseListName.isDisplayed());
		purchaseListName.clear();
		purchaseListName.sendKeys(name);
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage selectPersonalPurchaseListType()
	{
		waitForWebElementPresent(purchaseListType, getTimeOut());
		Assert.assertTrue(purchaseListType.isDisplayed());
		selectDropDown(purchaseListType, "Personal");
		_waitForJStoLoad();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage selectAccountPurchaseListType()
	{
		waitForWebElementPresent(purchaseListType, getTimeOut());
		Assert.assertTrue(purchaseListType.isDisplayed());
		selectDropDown(purchaseListType, "Account");
		_waitForJStoLoad();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickDoneButtonForPurchaseListCreation()
	{
		waitForWebElementPresent(doneButtonForPurchaseListCreation, getTimeOut());
		Assert.assertTrue(doneButtonForPurchaseListCreation.isDisplayed());
		doneButtonForPurchaseListCreation.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickDoneButtonAfterPurchaseListCreation()
	{
		waitForWebElementPresent(doneButtonAfterPurchaseListCreation, getTimeOut());
		Assert.assertTrue(doneButtonAfterPurchaseListCreation.isDisplayed());
		doneButtonAfterPurchaseListCreation.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}

}
