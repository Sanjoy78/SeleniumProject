package com.arco.pages;

import org.openqa.selenium.WebDriver;

import com.arco.util.ArcoDriverHelper;

public class WCMSCockpitDashboardPage extends ArcoDriverHelper
{
	
	public WCMSCockpitDashboardPage(final WebDriver driver)
	{
		super(driver);
	}

}
