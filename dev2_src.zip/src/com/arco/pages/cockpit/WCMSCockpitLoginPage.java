package com.arco.pages.cockpit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;
import com.arco.util.PropertyReaderArco;



public class WCMSCockpitLoginPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//input[@name='j_username']")
	private WebElement userName;
	
	@FindBy(how=How.XPATH, using="//input[@name='j_password']")
	private WebElement passWord;
	
	@FindBy(how=How.XPATH, using="//td[text()='Login']")
	private WebElement loginButton;
	
	public WCMSCockpitLoginPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public WCMSCockpitLoginPage enterUserName(String user)
	{
		waitForWebElementPresent(userName, getTimeOut());
		Assert.assertTrue(userName.isDisplayed());
		userName.clear();
		userName.sendKeys(user);
		return PageFactory.initElements(driver, WCMSCockpitLoginPage.class);
	}
	
	public WCMSCockpitLoginPage enterPassWord(String password)
	{
		waitForWebElementPresent(passWord, getTimeOut());
		Assert.assertTrue(passWord.isDisplayed());
		passWord.clear();
		passWord.sendKeys(password);
		return PageFactory.initElements(driver, WCMSCockpitLoginPage.class);
	}
	
	public WCMSCockpitDashboardPage clickOnLoginButton()
	{
		waitForWebElementPresent(loginButton, getTimeOut());
		Assert.assertTrue(loginButton.isDisplayed());
		loginButton.click();
		return PageFactory.initElements(driver, WCMSCockpitDashboardPage.class);
	}
	
	public WCMSCockpitDashboardPage loginToWCMSCockpit() throws Exception
	{
		String userName = propertyReader.readApplicationFile(PropertyReaderArco.getDomain()+"_CMSCockpitUser");
		String passWord = propertyReader.readApplicationFile(PropertyReaderArco.getDomain()+"_CMSCockpitPassword");
		enterUserName(userName);
		enterPassWord(passWord);
		clickOnLoginButton();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, WCMSCockpitDashboardPage.class);
	}

}
