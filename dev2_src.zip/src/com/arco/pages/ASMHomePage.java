package com.arco.pages;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;
import com.arco.util.PropertyReaderArco;



public class ASMHomePage extends ArcoDriverHelper
{
	
	@FindBy(how=How.XPATH, using="//input[@name='username']")
	private WebElement userName;
	
	@FindBy(how=How.XPATH, using="//input[@name='password']")
	private WebElement passWord;
	
	@FindBy(how=How.XPATH, using="//button[@class='ASM-btn ASM-btn-login']")
	private WebElement signInButton;
	
	public ASMHomePage(final WebDriver driver)
	{
		super(driver);
	}
	
	public ASMHomePage enterUserName(final String username) 
	{
		waitForWebElementPresent(userName, getTimeOut());
		Assert.assertTrue(userName.isDisplayed());
		userName.clear();
		userName.sendKeys(username);

		return PageFactory.initElements(driver, ASMHomePage.class);
	}

	public ASMHomePage enterPassword(final String password) 
	{
		waitForWebElementPresent(passWord, getTimeOut());
		Assert.assertTrue(passWord.isDisplayed());
		passWord.clear();
		passWord.sendKeys(password);
		return PageFactory.initElements(driver, ASMHomePage.class);
	}
	
	public ASMDashboardPage clickOnSignInButton()
	{
		waitForWebElementPresent(signInButton, getTimeOut());
		Assert.assertTrue(signInButton.isDisplayed());
		signInButton.click();
		return PageFactory.initElements(driver, ASMDashboardPage.class);
	}
	
	public ASMDashboardPage loginAsArcoAdmin() throws Exception 
	{
		String username = propertyReader.readApplicationFile(PropertyReaderArco.getDomain() + "_ASMArcoAdmin");
		String password = propertyReader.readApplicationFile(PropertyReaderArco.getDomain() + "_ASMArcoAdminPassword");
		enterUserName(username);
		enterPassword(password);
		clickOnSignInButton();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, ASMDashboardPage.class);
	}
	
	public ASMDashboardPage loginAsArcoSupport() throws Exception 
	{
		String username = propertyReader.readApplicationFile(PropertyReaderArco.getDomain() + "_ASMArcoSupport");
		String password = propertyReader.readApplicationFile(PropertyReaderArco.getDomain() + "_ASMArcoSupportPassword");
		enterUserName(username);
		enterPassword(password);
		clickOnSignInButton();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, ASMDashboardPage.class);
	}

}
