package com.arco.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class EnterEmailAddressPage extends ArcoDriverHelper
{
	@FindBy(how=How.ID, using="register.email")
	private WebElement emailID;
	
	@FindBy(how=How.XPATH, using="//button[@class='btn btn-primary btn-block-user m-b col-sm-4 col-md-4 col-lg-4']")
	private WebElement continueButton;
	
	public EnterEmailAddressPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public EnterEmailAddressPage enterEmailID(String email)
	{
		waitForWebElementPresent(emailID, getTimeOut());
		Assert.assertTrue(emailID.isDisplayed());
		emailID.sendKeys(email);
		return PageFactory.initElements(driver, EnterEmailAddressPage.class);
	}
	
	public HaveAccountNumberPage clickContinueButton()
	{
		waitForWebElementPresent(continueButton, getTimeOut());
		Assert.assertTrue(continueButton.isDisplayed());
		continueButton.click();
		return PageFactory.initElements(driver, HaveAccountNumberPage.class);
	}

}
