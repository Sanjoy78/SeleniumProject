package com.arco.pages.backoffice;

import org.openqa.selenium.WebDriver;

import com.arco.util.ArcoDriverHelper;

public class B2BCustomerPage extends ArcoDriverHelper
{
	public B2BCustomerPage(final WebDriver driver)
	{
		super(driver);
	}

}
