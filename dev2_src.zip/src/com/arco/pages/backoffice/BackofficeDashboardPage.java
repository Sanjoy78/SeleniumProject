package com.arco.pages.backoffice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;


public class BackofficeDashboardPage extends ArcoDriverHelper
{
	
	@FindBy(how=How.XPATH, using="//input[@placeholder='Filter Tree entries']")
	private WebElement searchTreeBox;
	
	@FindBy(how=How.XPATH, using="//span[text()='B2B Customer']")
	private WebElement b2bCustomer;
	
	public BackofficeDashboardPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public BackofficeDashboardPage enterSearchTermInSearchTreeBox(String value)
	{
		waitForWebElementPresent(searchTreeBox, getTimeOut());
		Assert.assertTrue(searchTreeBox.isDisplayed());
		searchTreeBox.clear();
		searchTreeBox.sendKeys(value);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, BackofficeDashboardPage.class);
	}
	
	public B2BCustomerPage clickOnB2bCustomer()
	{
		waitForWebElementPresent(b2bCustomer, getTimeOut());
		Assert.assertTrue(b2bCustomer.isDisplayed());
		b2bCustomer.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, B2BCustomerPage.class);
	}
	

}
