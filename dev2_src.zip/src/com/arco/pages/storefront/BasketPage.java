package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class BasketPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="(//button[text()='Checkout'])[1]")
	private WebElement checkOutButton;
	
	public BasketPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public CheckOutPage clickOnCheckOutButton()
	{
		waitForWebElementPresent(checkOutButton, getTimeOut());
		Assert.assertTrue(checkOutButton.isDisplayed());
		scrollToElementView(checkOutButton);
		checkOutButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, CheckOutPage.class);
	}

}
