package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class CheckOutPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//button[@id='savePaymentInfoCart']")
	private WebElement useThesePaymentDetailsButton;
	
	@FindBy(how=How.XPATH, using="//a[@class='btn btn-primary checkoutBasket']")
	private WebElement placeOrderButton;
	
	public CheckOutPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public CheckOutPage clickOnUseThesePaymentDetailsButton()
	{
		waitForWebElementPresent(useThesePaymentDetailsButton, getTimeOut());
		Assert.assertTrue(useThesePaymentDetailsButton.isDisplayed());
		scrollToWebElement(useThesePaymentDetailsButton);
		useThesePaymentDetailsButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, CheckOutPage.class);
	}
	
	public OrderConfirmationPage clickOnPlaceOrderButton()
	{
		waitForWebElementPresent(placeOrderButton, getTimeOut());
		Assert.assertTrue(placeOrderButton.isDisplayed());
		placeOrderButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, OrderConfirmationPage.class);
	}

}
