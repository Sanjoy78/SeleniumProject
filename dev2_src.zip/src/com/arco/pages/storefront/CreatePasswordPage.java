package com.arco.pages.storefront;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.arco.util.ArcoDriverHelper;

public class CreatePasswordPage extends ArcoDriverHelper
{
	@FindBy(how=How.ID, using="passwordInput")
	private WebElement password;
	
	@FindBy(how=How.XPATH, using="//button[@class='btn btn-primary btn-block-user m-b col-sm-4 col-md-4 col-lg-4']")
	private WebElement registerButton;
	
	public CreatePasswordPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public CreatePasswordPage enterPassword(String passWord)
	{
		waitForWebElementPresent(password, getTimeOut());
		Assert.assertTrue(password.isDisplayed());
		password.sendKeys(passWord);
		return PageFactory.initElements(driver, CreatePasswordPage.class);
	}
	
	public RegistrationSuccessPage clickRegisterButton()
	{
		waitForWebElementPresent(registerButton, getTimeOut());
		Assert.assertTrue(registerButton.isDisplayed());
		registerButton.click();
		return PageFactory.initElements(driver, RegistrationSuccessPage.class);
	}

}
