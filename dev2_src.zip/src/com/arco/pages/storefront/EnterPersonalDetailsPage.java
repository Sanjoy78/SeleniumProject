package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class EnterPersonalDetailsPage extends ArcoDriverHelper
{
	@FindBy(how=How.ID, using="register.title")
	private WebElement title;
	
	@FindBy(how=How.ID, using="register.firstName")
	private WebElement firstname;
	
	@FindBy(how=How.ID, using="register.surname")
	private WebElement surname;
	
	@FindBy(how=How.ID, using="register.phoneNumber")
	private WebElement phonenumber;
	
	@FindBy(how=How.ID, using="register.jobTitle")
	private WebElement jobtitle;
	
	@FindBy(how=How.ID, using="I agree to the Terms & Conditions")
	private WebElement TCCheckbox;
	
	@FindBy(how=How.XPATH, using="//input[@name='marketingPreferencePermission']")
	private WebElement marketingCheckbox;
	
	@FindBy(how=How.XPATH, using="//button[@class='btn btn-primary btn-block-user m-b col-sm-4 col-md-4 col-lg-4']")
	private WebElement continueButton;
	
	public EnterPersonalDetailsPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public EnterPersonalDetailsPage selectTitle(String value)
	{
		selectDropDown(title, value);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, EnterPersonalDetailsPage.class);
	}
	
	public EnterPersonalDetailsPage enterFirstName(String name)
	{
		waitForWebElementPresent(firstname, getTimeOut());
		Assert.assertTrue(firstname.isDisplayed());
		firstname.clear();
		firstname.sendKeys(name);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, EnterPersonalDetailsPage.class);
	}
	
	public EnterPersonalDetailsPage enterSurName(String surName)
	{
		waitForWebElementPresent(surname, getTimeOut());
		Assert.assertTrue(surname.isDisplayed());
		surname.clear();
		surname.sendKeys(surName);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, EnterPersonalDetailsPage.class);
	}
	
	public EnterPersonalDetailsPage enterPhoneNumber(String number)
	{
		waitForWebElementPresent(phonenumber, getTimeOut());
		Assert.assertTrue(phonenumber.isDisplayed());
		phonenumber.clear();
		phonenumber.sendKeys(number);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, EnterPersonalDetailsPage.class);
	}
	
	public EnterPersonalDetailsPage enterJobTitle(String jobTitle)
	{
		waitForWebElementPresent(jobtitle, getTimeOut());
		Assert.assertTrue(jobtitle.isDisplayed());
		jobtitle.clear();
		jobtitle.sendKeys(jobTitle);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, EnterPersonalDetailsPage.class);
	}
	
	public EnterPersonalDetailsPage selectTCCheckbox()
	{
		waitForWebElementPresent(TCCheckbox, getTimeOut());
		scrollToElementView(TCCheckbox);
		Assert.assertTrue(TCCheckbox.isDisplayed());
		TCCheckbox.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, EnterPersonalDetailsPage.class);
	}
	
	public EnterPersonalDetailsPage selectMarketingCheckbox()
	{
		waitForWebElementPresent(marketingCheckbox, getTimeOut());
		scrollToElementView(marketingCheckbox);
		Assert.assertTrue(marketingCheckbox.isDisplayed());
		marketingCheckbox.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, EnterPersonalDetailsPage.class);
	}
	
	public CreatePasswordPage clickContinueButton()
	{
		waitForWebElementPresent(continueButton, getTimeOut());
		scrollToElementView(continueButton);
		Assert.assertTrue(continueButton.isDisplayed());
		continueButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, CreatePasswordPage.class);
	}

}
