package com.arco.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class RolesGroupsAndOrgUnitsPage extends ArcoDriverHelper
{	
	@FindBy(how=How.XPATH, using="(//span[@id='dropdownMenu1'])[1]")
	private WebElement dotButtonForFirstOrgUnit;
	
	@FindBy(how=How.XPATH, using="(//a[@id='setdefaultb2bUnit0'])[1]")
	private WebElement setAsDefaultButtonForOrgUnit1;
	
	@FindBy(how=How.XPATH, using="(//span[@id='dropdownMenu1'])[2]")
	private WebElement dotButtonForSecondOrgUnit;
	
	@FindBy(how=How.XPATH, using="(//a[@id='setdefaultb2bUnit1'])[1]")
	private WebElement setAsDefaultButtonForOrgUnit2;
	
	public RolesGroupsAndOrgUnitsPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public RolesGroupsAndOrgUnitsPage clickOnDotFor1stOrgUnit()
	{
		waitForWebElementPresent(dotButtonForFirstOrgUnit, getTimeOut());
		Assert.assertTrue(dotButtonForFirstOrgUnit.isDisplayed());
		dotButtonForFirstOrgUnit.click();
		return PageFactory.initElements(driver, RolesGroupsAndOrgUnitsPage.class);
	}
	
	public RolesGroupsAndOrgUnitsPage clickOnSetAsDefaultButtonForORG1()
	{
		waitForWebElementPresent(setAsDefaultButtonForOrgUnit1, getTimeOut());
		Assert.assertTrue(setAsDefaultButtonForOrgUnit1.isDisplayed());
		setAsDefaultButtonForOrgUnit1.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, RolesGroupsAndOrgUnitsPage.class);
	}
	
	public RolesGroupsAndOrgUnitsPage setOrgUnit1AsDefault()
	{
		clickOnDotFor1stOrgUnit();
		clickOnSetAsDefaultButtonForORG1();
		return PageFactory.initElements(driver, RolesGroupsAndOrgUnitsPage.class);
	}
	
	public RolesGroupsAndOrgUnitsPage clickOnDotFor2ndOrgUnit()
	{
		waitForWebElementPresent(dotButtonForSecondOrgUnit, getTimeOut());
		Assert.assertTrue(dotButtonForSecondOrgUnit.isDisplayed());
		dotButtonForSecondOrgUnit.click();
		return PageFactory.initElements(driver, RolesGroupsAndOrgUnitsPage.class);
	}
	
	public RolesGroupsAndOrgUnitsPage clickOnSetAsDefaultButtonForORG2()
	{
		waitForWebElementPresent(setAsDefaultButtonForOrgUnit2, getTimeOut());
		Assert.assertTrue(setAsDefaultButtonForOrgUnit2.isDisplayed());
		setAsDefaultButtonForOrgUnit2.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, RolesGroupsAndOrgUnitsPage.class);
	}
	
	public RolesGroupsAndOrgUnitsPage setOrgUnit2AsDefault()
	{
		clickOnDotFor2ndOrgUnit();
		clickOnSetAsDefaultButtonForORG2();
		return PageFactory.initElements(driver, RolesGroupsAndOrgUnitsPage.class);
	}

}
