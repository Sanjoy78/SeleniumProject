package com.arco.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class OrderConfirmationPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="(//strong)[1]")
	private WebElement userName;
	
	@FindBy(how=How.XPATH, using="//a[@href='/logout']")
	private WebElement logOutButton;
	
	public OrderConfirmationPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public OrderConfirmationPage clickOnUserName()
	{
		waitForWebElementPresent(userName, getTimeOut());
		Assert.assertTrue(userName.isDisplayed());
		userName.click();
		return PageFactory.initElements(driver, OrderConfirmationPage.class);
	}
	
	public HomePage clickOnLogOutButton()
	{
		waitForWebElementPresent(logOutButton, getTimeOut());
		Assert.assertTrue(logOutButton.isDisplayed());
		logOutButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, HomePage.class);
	}

}
