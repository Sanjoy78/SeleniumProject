package com.company.project.staticData;

/** Created by pavankovurru on 5/3/17. */
public class Constants {

  // ALL INVALID DATA AND OTHER STATIC DATA WHICH IS INDEPENDENT OF TEST ENVIRONMENT GOES HERE

  public static final String INVALID_AUTH = "ydqgiqwudiowqdopqw";
  public static final String INVALID_CUSTOMER_ID = "00000";
  public static final String LIMIT = "10";
}
