package com.arco.scripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.cockpit.WCMSCockpitDashboardPage;
import com.arco.pages.cockpit.WCMSCockpitLoginPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;
import com.arco.util.TestData;

public class WCMSCockpitLoginTest extends ArcoDriverTestCase
{
	
	private String test, expectedMessage;
	private WCMSCockpitLoginPage wcmsCockpitLoginPage;
	private WCMSCockpitDashboardPage wcmsCockpitDashboardPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void verifyWCMSCockpitLogin() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(14, 1);
			expectedMessage = propertyReaderArco.getCellData(14, 2);
			
			wcmsCockpitLoginPage = applicationSetupWCSM();
			wcmsCockpitDashboardPage = wcmsCockpitLoginPage.loginToWCMSCockpit();
			String actualMessage = wcmsCockpitDashboardPage.getText("//span[@class='navigation_path_label z-label']", "Here we are fatching text of welcome message for verification");
			softAssert.assertEquals(actualMessage, expectedMessage);
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
