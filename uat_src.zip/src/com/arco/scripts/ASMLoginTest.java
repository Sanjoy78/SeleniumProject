package com.arco.scripts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.asm.ASMDashboardPage;
import com.arco.pages.asm.ASMHomePage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;
import com.aventstack.extentreports.Status;


public class ASMLoginTest extends ArcoDriverTestCase
{
	private String test, expectedArcoAdminName, expectedArcoSupportName;
	private ASMHomePage asmHomePage;
	private ASMDashboardPage asmDashboardPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void asmLoginTestAsArcoAdmin() throws Exception
	{
		try
		{
			repoterLog = extent.createTest("asmLoginTestAsArcoAdmin");
			softAssert = new SoftAssert();
			
			propertyReaderArco = new PropertyReaderArco();
			test = propertyReaderArco.getCellData(10, 1);
			expectedArcoAdminName = propertyReaderArco.getCellData(10, 2);
		    asmHomePage = applicationSetupASM();
		    repoterLog.log(Status.INFO, "Application setup completed");
		    asmDashboardPage = asmHomePage.loginAsArcoAdmin();
		    repoterLog.log(Status.INFO, "Login completed");
		    addLog("Opening ASM");
		    String actualArcoUser = asmDashboardPage.getText("(//span[@class='ASM_loggedin_text_name'])[2]", "Here we are fetching the Arco admin name for verification");
		    softAssert.assertEquals(actualArcoUser, expectedArcoAdminName);
		    asmHomePage = asmDashboardPage.clickOnLogOutButton();
		    
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}
	
	@Test
	public void asmLoginTestAsArcoSupport() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(11, 1);
			expectedArcoSupportName = propertyReaderArco.getCellData(11, 2);
			
			asmDashboardPage = asmHomePage.loginAsArcoSupport();
			String actualArcoUser = asmDashboardPage.getText("(//span[@class='ASM_loggedin_text_name'])[2]", "Here we are fetching the Arco admin name for verification");
			softAssert.assertEquals(actualArcoUser, expectedArcoSupportName);
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
