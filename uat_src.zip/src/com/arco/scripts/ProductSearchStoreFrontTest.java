package com.arco.scripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.CategoryListPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;
import com.arco.util.TestData;

public class ProductSearchStoreFrontTest extends ArcoDriverTestCase
{
	private String test, productID, expectedTitle;
	private HomePage homePage;
	private CategoryListPage categoryListPage;
	private ProductDetailsPage productDetailsPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void searchProductFromArcoStoreFront() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			test = propertyReaderArco.getCellData(12, 1);
			productID = propertyReaderArco.getCellData(12, 2);
			expectedTitle = propertyReaderArco.getCellData(12, 3);
			
			softAssert = new SoftAssert();
			homePage = applicationSetup();
			homePage.enterProductCodeInSearchBox(productID);
			categoryListPage = homePage.clickOnFindButton();
			String actualTitle = categoryListPage.getText("//title", "Here we are retreiving title of CLP");
			softAssert.assertEquals(actualTitle, expectedTitle);
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
