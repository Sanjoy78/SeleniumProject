package com.arco.scripts;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.MyAccountPage;
import com.arco.pages.storefront.UserManagementPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;
import com.arco.util.TestData;

public class CreateUserArcoAdminTest extends ArcoDriverTestCase
{
	private String test, arcoAdmUserName, arcoAdmPassWord, title, name, surname, emailid, phonenumber, jobtitle, orgunit, role;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private MyAccountPage myAccountPage;
	private UserManagementPage userManagementPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void createUserAsArcoAdmin() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			test = propertyReaderArco.getCellData(18, 1);
			arcoAdmUserName = propertyReaderArco.getCellData(18, 2);
			arcoAdmPassWord = propertyReaderArco.getCellData(18, 3);
			title = propertyReaderArco.getCellData(18, 4);
			name = propertyReaderArco.getCellData(18, 5);
			surname = propertyReaderArco.getCellData(18, 6);
			emailid = propertyReaderArco.getCellData(18, 7);
			phonenumber = propertyReaderArco.getCellData(18, 8);
			jobtitle = propertyReaderArco.getCellData(18, 9);
			orgunit = propertyReaderArco.getCellData(18, 10);
			role = propertyReaderArco.getCellData(18, 11);
			
			homePage = applicationSetup();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(arcoAdmUserName, arcoAdmPassWord);
			dashboardPage.clickUserName();
			myAccountPage = dashboardPage.clickAccountOverview();
			userManagementPage = myAccountPage.clickOnUserManagementLink();
			userManagementPage.clickOnCreateUserButton();
			userManagementPage.selectTitle(title);
			userManagementPage.enterFirstName(name);
			userManagementPage.enterSurname(surname);
			userManagementPage.enterEmailAddress(emailid);
			userManagementPage.enterPhoneNumber(phonenumber);
			userManagementPage.enterJobTitle(jobtitle);
			userManagementPage.selectOrgUnit();
			userManagementPage.selectUserRole(role);
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
		
	}

}
