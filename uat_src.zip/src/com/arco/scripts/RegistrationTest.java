package com.arco.scripts;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.CreatePasswordPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.EnterEmailAddressPage;
import com.arco.pages.storefront.EnterPersonalDetailsPage;
import com.arco.pages.storefront.HaveAccountNumberPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.RegistrationSuccessPage;
import com.arco.pages.storefront.VerifyAccountPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;
import com.arco.util.TestData;

public class RegistrationTest extends ArcoDriverTestCase
{
	private String test, emailID, title, name, surname, phoneno, jobtitle, password, expectedmessage, accountno, postcode;
	//private PropertyReaderArco propertyReaderArco;
	private HomePage homePage;
	private EnterEmailAddressPage enterEmailAddressPage;
	private HaveAccountNumberPage haveAccountNumberPage;
	private VerifyAccountPage verifyAccountPage;
	private EnterPersonalDetailsPage enterPersonalDetailsPage;
	private CreatePasswordPage createPasswordPage;
	private RegistrationSuccessPage registrationSuccessPage;
	private PropertyReaderArco propertyReaderArco;
	
	
	@Test(enabled=true)
	public void registrationAsCashUser() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
		SoftAssert softassert = new SoftAssert();
		test = propertyReaderArco.getCellData(1, 1);
		emailID = propertyReaderArco.getCellData(1, 2);
		title = propertyReaderArco.getCellData(1, 3);
		name = propertyReaderArco.getCellData(1, 4);
		surname = propertyReaderArco.getCellData(1, 5);
		phoneno = propertyReaderArco.getCellData(1, 6);
		jobtitle = propertyReaderArco.getCellData(1, 7);
		password = propertyReaderArco.getCellData(1, 8);
		expectedmessage = propertyReaderArco.getCellData(1, 9);
		
		homePage = applicationSetup();
		homePage.clickLoginRegister();
		enterEmailAddressPage = homePage.clickRegisterNow();
		enterEmailAddressPage.enterEmailID(emailID);
		haveAccountNumberPage = enterEmailAddressPage.clickContinueButton();
		haveAccountNumberPage.selectNoAccount();
		enterPersonalDetailsPage = haveAccountNumberPage.clickContinueButtonForCash();
		enterPersonalDetailsPage.selectTitle(title);
		enterPersonalDetailsPage.enterFirstName(name);
		enterPersonalDetailsPage.enterSurName(surname);
		enterPersonalDetailsPage.enterPhoneNumber(phoneno);
		enterPersonalDetailsPage.enterJobTitle(jobtitle);
		enterPersonalDetailsPage.selectTCCheckbox();
		enterPersonalDetailsPage.selectMarketingCheckbox();
		createPasswordPage = enterPersonalDetailsPage.clickContinueButton();
		createPasswordPage.enterPassword(password);
		registrationSuccessPage = createPasswordPage.clickRegisterButton();
		String actualmessage = registrationSuccessPage.getText("//h1", "We are retrieving registration success message");
		softassert.assertEquals(actualmessage, expectedmessage);
		softassert.assertAll();
		} catch (final Error e){
			captureScreenshot(test);
			throw e;
		} catch (final Exception e) {
			captureScreenshot(test);
			throw e;
		}
	}
	
	@Test(enabled=true)
	public void registrationAsAccountUserAccountPay() throws Exception
	{
		try 
		{
			propertyReaderArco = new PropertyReaderArco();
			SoftAssert softassert = new SoftAssert();
			test = propertyReaderArco.getCellData(2, 1);
			emailID = propertyReaderArco.getCellData(2, 2);
			accountno = propertyReaderArco.getCellData(2, 3);
			title = propertyReaderArco.getCellData(2, 4);
			name = propertyReaderArco.getCellData(2, 5);
			surname = propertyReaderArco.getCellData(2, 6);
			phoneno = propertyReaderArco.getCellData(2, 7);
			jobtitle = propertyReaderArco.getCellData(2, 8);
			password = propertyReaderArco.getCellData(2, 9);
			expectedmessage = propertyReaderArco.getCellData(2, 10);
			
			homePage = applicationSetup();
			homePage.clickLoginRegister();
			enterEmailAddressPage = homePage.clickRegisterNow();
			enterEmailAddressPage.enterEmailID(emailID);
			haveAccountNumberPage = enterEmailAddressPage.clickContinueButton();
			haveAccountNumberPage.selectYesAccount();
			haveAccountNumberPage.enterAccountNumber(accountno);
			verifyAccountPage = haveAccountNumberPage.clickContinueButtonForAccount();
			enterPersonalDetailsPage = verifyAccountPage.clickContinueButton_Acc();
			enterPersonalDetailsPage.selectTitle(title);
			enterPersonalDetailsPage.enterFirstName(name);
			enterPersonalDetailsPage.enterSurName(surname);
			enterPersonalDetailsPage.enterPhoneNumber(phoneno);
			enterPersonalDetailsPage.enterJobTitle(jobtitle);
			enterPersonalDetailsPage.selectTCCheckbox();
			enterPersonalDetailsPage.selectMarketingCheckbox();
			createPasswordPage = enterPersonalDetailsPage.clickContinueButton();
			createPasswordPage.enterPassword(password);
			registrationSuccessPage = createPasswordPage.clickRegisterButton();
			String actualmessage = registrationSuccessPage.getText("//h1", "We are retrieving registration success message");
			softassert.assertEquals(actualmessage, expectedmessage);
			softassert.assertAll();
		} catch (final Error e) {
			captureScreenshot(test);
			throw e;
		} catch (final Exception e) {
			captureScreenshot(test);
			throw e;
		}
	}
	
	@Test(enabled=true)
	public void registrationAsAccountUserImidiatePay() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			SoftAssert softassert = new SoftAssert();
			test = propertyReaderArco.getCellData(3, 1);
			emailID = propertyReaderArco.getCellData(3, 2);
			accountno = propertyReaderArco.getCellData(3, 3);
			postcode = propertyReaderArco.getCellData(3, 4);
			title = propertyReaderArco.getCellData(3, 5);
			name = propertyReaderArco.getCellData(3, 6);
			surname = propertyReaderArco.getCellData(3, 7);
			phoneno = propertyReaderArco.getCellData(3, 8);
			jobtitle = propertyReaderArco.getCellData(3, 9);
			password = propertyReaderArco.getCellData(3, 10);
			expectedmessage = propertyReaderArco.getCellData(3, 11);
			
			homePage = applicationSetup();
			homePage.clickLoginRegister();
			enterEmailAddressPage = homePage.clickRegisterNow();
			enterEmailAddressPage.enterEmailID(emailID);
			haveAccountNumberPage = enterEmailAddressPage.clickContinueButton();
			haveAccountNumberPage.selectYesAccount();
			haveAccountNumberPage.enterAccountNumber(accountno);
			verifyAccountPage = haveAccountNumberPage.clickContinueButtonForAccount();
			verifyAccountPage.enterPostCode(postcode);
			enterPersonalDetailsPage = verifyAccountPage.clickContinueButton_Imi();
			enterPersonalDetailsPage.selectTitle(title);
			enterPersonalDetailsPage.enterFirstName(name);
			enterPersonalDetailsPage.enterSurName(surname);
			enterPersonalDetailsPage.enterPhoneNumber(phoneno);
			enterPersonalDetailsPage.enterJobTitle(jobtitle);
			enterPersonalDetailsPage.selectTCCheckbox();
			enterPersonalDetailsPage.selectMarketingCheckbox();
			createPasswordPage = enterPersonalDetailsPage.clickContinueButton();
			createPasswordPage.enterPassword(password);
			registrationSuccessPage = createPasswordPage.clickRegisterButton();
			String actualmessage = registrationSuccessPage.getText("//h1", "We are retrieving registration success message");
			softassert.assertEquals(actualmessage, expectedmessage);
			softassert.assertAll();
		}catch (final Error e) {
			captureScreenshot(test);
			throw e;
		} catch (final Exception e) {
			captureScreenshot(test);
			throw e;
		}
	}

}
