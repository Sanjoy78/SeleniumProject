package com.arco.scripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.StoreFinderPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;
import com.arco.util.TestData;
import com.aventstack.extentreports.Status;

public class StoreLocatorFunctionalityTest extends ArcoDriverTestCase
{
	private String test, storeName;
	private HomePage homePage;
	private StoreFinderPage storeFinderPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void findAStoreByStoreLocator() throws Exception
	{
		try
		{
			repoterLog = extent.createTest("findAStoreByStoreLocator");
			propertyReaderArco = new PropertyReaderArco();
			test = propertyReaderArco.getCellData(13, 1);
			storeName = propertyReaderArco.getCellData(13, 2);
			
			
			softAssert = new SoftAssert();
			homePage = applicationSetup();
			repoterLog.log(Status.INFO, "Application lunched");
			storeFinderPage = homePage.clickOnStoreLocator();
			repoterLog.log(Status.INFO, "clicked on Store locator");
			storeFinderPage.selectStoreFromDropDown(storeName);
			repoterLog.log(Status.INFO, "Drop down selected");
			storeFinderPage.clickOnArrowButton();
			String actualStoreName = storeFinderPage.getText("//span[@class='store-finder-details-info-name js-store-displayName']", "Here we are fatching store name for verification");
			softAssert.assertEquals(actualStoreName, storeName);
			softAssert.assertAll();
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
		
	}

}
