package com.arco.scripts;

import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;
import com.arco.util.TestData;

public class QuickOrderButtonAvailabilityForRegisteredUserTest extends ArcoDriverTestCase
{
	
	private String test, userName, passWord, expectedUser;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private PropertyReaderArco propertyReaderArco;
	
	
	@Test
	public void verifyQuickOrderButtonAvailabilityForRegisteredUserWhoHasAddToBasketPeermission() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			SoftAssert softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(6, 1);
			userName = propertyReaderArco.getCellData(6, 2);
			passWord = propertyReaderArco.getCellData(6, 3);
			expectedUser = propertyReaderArco.getCellData(6, 4);
			
			homePage = applicationSetup();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(userName, passWord);
			String actualUser1 = dashboardPage.getText("(//strong)[1]", "Here we are getting actual user details displayed in header");
			softAssert.assertEquals(actualUser1, expectedUser);
			dashboardPage.quickOrderButtonIsDisplayed();
			dashboardPage.clickUserName();
			homePage = dashboardPage.clickSignOutButton();
			
			softAssert.assertAll();
		} catch(Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}
	
	@Test(expectedExceptions = NoSuchElementException.class)
	public void verifyQuickOrderButtonAvailabilityForRegisteredUserWhoHasNotAddToBasketPeermission() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			SoftAssert softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(7, 1);
			userName = propertyReaderArco.getCellData(7, 2);
			passWord = propertyReaderArco.getCellData(7, 3);
			expectedUser = propertyReaderArco.getCellData(7, 4);
			
			//homePage1 = applicationSetup();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(userName, passWord);
			String actualUser2 = dashboardPage.getText("(//strong)[1]", "Here we are getting actual user details displayed in header");
			softAssert.assertEquals(actualUser2, expectedUser);
			dashboardPage.quickOrderButtonIsDisplayed();
			dashboardPage.clickUserName();
			homePage = dashboardPage.clickSignOutButton();
			softAssert.assertAll();
		} catch(Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}
}
