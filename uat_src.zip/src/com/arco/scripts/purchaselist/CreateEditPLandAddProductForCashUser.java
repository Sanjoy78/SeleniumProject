package com.arco.scripts.purchaselist;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.PurchaseListPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class CreateEditPLandAddProductForCashUser extends ArcoDriverTestCase
{
	
	private String test, emailId, passWord, expectedUserName, actualUserName, plPageTitle, createListPopUpTitle, plType;
	private String existingPLName, expectedError, newPLName, updatedPLName, noProductMessage, productId;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private PurchaseListPage purchaseListPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void createEditPLandAddProductForCashUser() throws Exception
	{
		try
		{
			softAssert = new SoftAssert();
			propertyReaderArco = new PropertyReaderArco();
			test = propertyReaderArco.getCellData(19, 1);
			emailId = propertyReaderArco.getCellData(19, 2);
			passWord = propertyReaderArco.getCellData(19, 3);
			expectedUserName = propertyReaderArco.getCellData(19, 4);
			plPageTitle = propertyReaderArco.getCellData(19, 5);
			createListPopUpTitle = propertyReaderArco.getCellData(19, 6);
			plType = propertyReaderArco.getCellData(19, 7);
			existingPLName = propertyReaderArco.getCellData(19, 8);
			expectedError = propertyReaderArco.getCellData(19, 9);
			newPLName = propertyReaderArco.getCellData(19, 10);
			
			homePage = applicationSetup();
			
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(emailId, passWord);
			actualUserName = dashboardPage.getText("(//strong)[1]", "Getting text from header");
			softAssert.assertEquals(actualUserName, expectedUserName);
			purchaseListPage = dashboardPage.clickPurchaseListLink();
			String actualPLPageTitle = purchaseListPage.getText("//h1", "Getting text from PL page title");
			softAssert.assertEquals(actualPLPageTitle, plPageTitle);
			purchaseListPage.clickCreateListButton();
			String actualCreateListPopUpTitle = purchaseListPage.getText("(//h4[@id='myModalLabel'])[3]", "Getting text from pop-up header");
			softAssert.assertEquals(actualCreateListPopUpTitle, createListPopUpTitle);
			String actualPLType = purchaseListPage.getText("//select[@id='purchasingListType']", "Getting text from PL type");
			softAssert.assertEquals(actualPLType, plType);
			softAssert.assertFalse(purchaseListPage.isPLTypeEnable());
			purchaseListPage.enterPurchaseListName(existingPLName);
			purchaseListPage.clickDoneButtonForPurchaseListCreation();
			String actualErrorMessage = purchaseListPage.getText("//span[@id='name.errors']", "Here we are getting error message for same PL name.");
			softAssert.assertEquals(actualErrorMessage, expectedError);
			purchaseListPage.enterPurchaseListName(newPLName);
			purchaseListPage.clickDoneButtonForPurchaseListCreation();
			purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
			softAssert.assertTrue(purchaseListPage.searchPLExist(newPLName, purchaseListPage.allPL()));
			purchaseListPage.clickOnDotForAPL(newPLName);
			purchaseListPage.clickOnEditForAPL(newPLName);
			softAssert.assertAll();
			
		} catch(Exception e)
		{
			captureScreenshot(test);
			throw e;
		} catch(Error e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
