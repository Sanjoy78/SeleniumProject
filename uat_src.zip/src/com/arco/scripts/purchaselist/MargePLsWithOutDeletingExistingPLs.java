package com.arco.scripts.purchaselist;

import org.testng.annotations.Test;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.PurchaseListPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class MargePLsWithOutDeletingExistingPLs extends ArcoDriverTestCase
{
	private String test, userID, passWord, userDetails, pL1, pL2, newPLName;
	
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private PurchaseListPage purchaseListPage;
	
	
	@Test
	public void margeTwoPLsWithoutDeletingExistingPLs() throws Exception
	{
		try
		{
			PropertyReaderArco propertyReaderArco = new PropertyReaderArco();
			test = propertyReaderArco.getCellData(21, 1);
			userID = propertyReaderArco.getCellData(21, 2);
			passWord = propertyReaderArco.getCellData(21, 3);
			userDetails = propertyReaderArco.getCellData(21, 4);
			pL1 = propertyReaderArco.getCellData(21, 5);
			pL2 = propertyReaderArco.getCellData(21, 6);
			newPLName = propertyReaderArco.getCellData(21, 7);
			
			
			homePage = applicationSetup();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(userID, passWord);
			purchaseListPage = dashboardPage.clickPurchaseListLink();
			purchaseListPage.clickOnCheckBoxForAPL(pL1);
			purchaseListPage.clickOnCheckBoxForAPL(pL2);
			purchaseListPage.clickSelectActionButton();
			purchaseListPage.clickMergeButton();
			purchaseListPage.clickMergeAndKeepEP();
			purchaseListPage.clickSelectButton();
			purchaseListPage.enterPurchaseListName(newPLName);
			purchaseListPage.clickDoneButtonForPurchaseListCreation();
			purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
			purchaseListPage.searchPurchaseListByName(newPLName);
			purchaseListPage.clickOnDotForAPL(newPLName);
			purchaseListPage.clickOnViewForAPL(newPLName);
			
			
		} catch(Error e)
		{
			captureScreenshot(test);
			throw e;
		}
		
		
		
		
	}

}
