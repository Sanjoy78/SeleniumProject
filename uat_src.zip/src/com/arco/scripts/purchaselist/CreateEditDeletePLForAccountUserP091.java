package com.arco.scripts.purchaselist;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.PurchaseListPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class CreateEditDeletePLForAccountUserP091 extends ArcoDriverTestCase
{
	
	private static final Logger logger = LoggerFactory.getLogger(CreateEditDeletePLForAccountUserP091.class);
	private String test, userID, passWord, userDetails, personalPLName, accountPLName, updatedPersonalPLName, updatedAccountPLName;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private PurchaseListPage purchaseListPage;
	
	
	@Test
	public void createEditDeletePLForAccountUserP091() throws Exception
	{
		try
		{
			softAssert = new SoftAssert();
			logger.debug("We are creating object for SoftAssert");
			propertyReaderArco = new PropertyReaderArco();
			logger.debug("We are creating object for PropertyReaderArco");
			test = propertyReaderArco.getCellData(20, 1);
			logger.debug("Fatching test case name from excel sheet");
			userID = propertyReaderArco.getCellData(20, 2);
			logger.debug("Fatching username from excel sheet");
			passWord = propertyReaderArco.getCellData(20, 3);
			logger.debug("Fatching password from excel sheet");
			userDetails = propertyReaderArco.getCellData(20, 4);
			logger.debug("Fatching user details from excel sheet");
			personalPLName = propertyReaderArco.getCellData(20, 5);
			logger.debug("Fatching personal purchase list name from excel sheet");
			accountPLName = propertyReaderArco.getCellData(20, 6);
			logger.debug("Fatching account purchase list name from excel sheet");
			updatedPersonalPLName = propertyReaderArco.getCellData(20, 7);
			logger.debug("Fatching updated personal purchase list name from excel sheet");
			updatedAccountPLName = propertyReaderArco.getCellData(20, 8);
			logger.debug("Fatching updated account purchase list name from excel sheet");
			
			homePage = applicationSetup();
			logger.debug("Opening Arco home page");
			homePage.clickLoginRegister();
			logger.debug("Clicking on Login & Register link on home page");
			dashboardPage = homePage.login(userID, passWord);
			logger.debug("Performing login throw useername and password");
			String actualUserDetails = dashboardPage.getText("(//strong)[1]", "Getting text from header");
			logger.debug("Fatching actual user details");
			softAssert.assertEquals(actualUserDetails, userDetails);
			logger.debug("Verifying actual and expected user details");
			purchaseListPage = dashboardPage.clickPurchaseListLink();
			logger.debug("Clicking on purchase list link to nevigate to purchase list page");
			purchaseListPage.clickCreateListButton();
			logger.debug("Clicking on create list button to create new purchase list");
			purchaseListPage.enterPurchaseListName(personalPLName);
			logger.debug("Entering new purchase list name(Personal type)");
			purchaseListPage.selectPersonalPurchaseListType();
			logger.debug("Selecting personal purchase list type");
			purchaseListPage.clickDoneButtonForPurchaseListCreation();
			logger.debug("Clicking on done button for purchase list creation");
			purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
			logger.debug("Clicking on done button after purchase list creation");
			purchaseListPage.searchPurchaseListByName(personalPLName);
			logger.debug("Searching for the purchase list after purchase list creation");
			softAssert.assertTrue(purchaseListPage.searchPLExist(personalPLName, purchaseListPage.allPL()));
			logger.debug("Verifying purchase list is created or not");
			purchaseListPage.clickCreateListButton();
			logger.debug("Clicking on create list button to create new purchase list");
			purchaseListPage.enterPurchaseListName(accountPLName);
			logger.debug("Entering new purchase list name(Account type)");
			purchaseListPage.selectAccountPurchaseListType();
			logger.debug("Selecting account purchase list type");
			purchaseListPage.clickDoneButtonForPurchaseListCreation();
			logger.debug("Clicking on done button for purchase list creation");
			purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
			logger.debug("Clicking on done button after purchase list creation");
			purchaseListPage.searchPurchaseListByName(personalPLName);
			logger.debug("Searching for the purchase list after purchase list creation");
			softAssert.assertTrue(purchaseListPage.searchPLExist(accountPLName, purchaseListPage.allPL()));
			logger.debug("Verifying purchase list is created or not");
			purchaseListPage.searchPurchaseListByName(personalPLName);
			logger.debug("Searching personal purchase list");
			purchaseListPage.clickOnDotForAPL(personalPLName);
			logger.debug("Clicking on three dot for searched purchase list");
			purchaseListPage.clickOnEditForAPL(personalPLName);
			logger.debug("Clicking on edit button for searched purchase list");
			purchaseListPage.enterPurchaseListName(updatedPersonalPLName);
			logger.debug("Entering new purchase list name for purchase list name updation");
			purchaseListPage.clickDoneButtonForPurchaseListCreation();
			logger.debug("Clicking on done button for purchase list updation");
			purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
			logger.debug("Clicking on done button after purchase list updation");
			purchaseListPage.searchPurchaseListByName(accountPLName);
			logger.debug("Searching account purchase list");
			purchaseListPage.clickOnDotForAPL(accountPLName);
			logger.debug("Clicking on three dot for searched purchase list");
			purchaseListPage.clickOnEditForAPL(accountPLName);
			logger.debug("Clicking on edit button for searched purchase list");
			purchaseListPage.enterPurchaseListName(updatedAccountPLName);
			logger.debug("Entering new purchase list name for purchase list name updation");
			purchaseListPage.clickDoneButtonForPurchaseListCreation();
			logger.debug("Clicking on done button for purchase list updation");
			purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
			logger.debug("Clicking on done button after purchase list updation");
			purchaseListPage.searchPurchaseListByName(updatedPersonalPLName);
			logger.debug("Searching for updated personal purchase list");
			purchaseListPage.clickOnDotForAPL(updatedPersonalPLName);
			logger.debug("Clicking on three dot for searched purchase list");
			purchaseListPage.clickOnDeleteForAPL(updatedPersonalPLName);
			logger.debug("Clicking on delete for searched purchase list");
			purchaseListPage.clickOnYesButtonForPLDetetation();
			logger.debug("Clicking on yes button for purchase list deletation");
			purchaseListPage.clickOnDoneButtonAfterPLDeletation();
			logger.debug("Clicking on done button for purchase list deletation");
			purchaseListPage.searchPurchaseListByName(updatedAccountPLName);
			logger.debug("Searching for updated account purchase list");
			purchaseListPage.clickOnDotForAPL(updatedAccountPLName);
			logger.debug("Clicking on three dot for searched purchase list");
			purchaseListPage.clickOnDeleteForAPL(updatedAccountPLName);
			logger.debug("Clicking on delete for searched purchase list");
			purchaseListPage.clickOnYesButtonForPLDetetation();
			logger.debug("Clicking on yes button for purchase list deletation");
			purchaseListPage.clickOnDoneButtonAfterPLDeletation();
			logger.debug("Clicking on done button for purchase list deletation");
			
			softAssert.assertAll();
			
		} catch(Exception e)
		{
			captureScreenshot(test);
			throw e;
		} catch(Error e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
