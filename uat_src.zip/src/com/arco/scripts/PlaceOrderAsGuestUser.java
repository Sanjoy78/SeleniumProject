package com.arco.scripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.arco.pages.storefront.BasketPage;
import com.arco.pages.storefront.CheckOutCardPaymentPage;
import com.arco.pages.storefront.CheckOutPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.util.ArcoDriverTestCase;

public class PlaceOrderAsGuestUser extends ArcoDriverTestCase
{
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private ProductDetailsPage productDetailsPage;
	private BasketPage basketPage;
	private CheckOutPage checkOutPage;
	private CheckOutCardPaymentPage checkOutCardPaymentPage;
	
	@Test
	public void placeOrderAsGuestUser() throws Exception
	{
		homePage = applicationSetup();
		homePage.clickOnGotIt();
		homePage.clickLoginRegister();
		
		dashboardPage = homePage.login("akakak@gmail.com", "Sanjoyarco123");
		dashboardPage.enterProductNameOrCode("PIM111500");
		productDetailsPage = dashboardPage.clickOnFindButtonToNevigateToPDP();
		productDetailsPage.enterQTYForSKU("111700", "2");
		driver.findElement(By.xpath("//a[text()='View Details']")).click();
		productDetailsPage.clickOnAddToBasketButton();
		basketPage = productDetailsPage.clickOnCheckOutButton();
		checkOutPage = basketPage.clickOnCheckOutButton();
		checkOutPage.clickOnCardRadioButton();
		checkOutPage.clickOnUseThesePaymentDetailsButton();
		checkOutCardPaymentPage = checkOutPage.clickOnPlaceOrderButtonToMoveCardPage();
		checkOutCardPaymentPage.clickOnAddNewCardButton();
		checkOutCardPaymentPage.switchToiFrame();
		checkOutCardPaymentPage.enterCardNumber("4012");
		Thread.sleep(1000);
		checkOutCardPaymentPage.enterCardNumber("0010");
		Thread.sleep(1000);
		checkOutCardPaymentPage.enterCardNumber("3627");
		Thread.sleep(1000);
		checkOutCardPaymentPage.enterCardNumber("5556");
		Thread.sleep(1000);
		checkOutCardPaymentPage.enterSecurityCode("719");
		checkOutCardPaymentPage.selectMonthlist("05");
		checkOutCardPaymentPage.selectYearlist("2024");
		
		checkOutCardPaymentPage.clickOnSelectPayByCard();
			
	}

}
