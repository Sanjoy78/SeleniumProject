package com.arco.pages.asm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class ASMDashboardPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//button[@class='ASM-btn ASM-btn-logout']")
	private WebElement logOutButton;
	
	public ASMDashboardPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public ASMHomePage clickOnLogOutButton()
	{
		waitForWebElementPresent(logOutButton, getTimeOut());
		Assert.assertTrue(logOutButton.isDisplayed());
		logOutButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, ASMHomePage.class);
	}

}
