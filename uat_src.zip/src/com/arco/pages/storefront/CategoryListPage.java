package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class CategoryListPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="(//button[@id='buynow1'])[1]")
	private WebElement buyNowButton;
	
	@FindBy(how=How.XPATH, using="(//span[@class='plpQtyPlus'])[2]")
	private WebElement increaseQuantityButton;
	
	@FindBy(how=How.XPATH, using="(//button[text()='Add to Basket'])[3]")
	private WebElement addToBasketButton;
	
	@FindBy(how=How.XPATH, using="//a[contains(@href,'/p/PIM2606000')]")
	private WebElement productPIM2606000;
	
	
	public CategoryListPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public ProductDetailsPage clickOnProductPIM2606000()
	{
		waitForWebElementPresent(productPIM2606000, getTimeOut());
		Assert.assertTrue(productPIM2606000.isDisplayed());
		productPIM2606000.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public CategoryListPage clickOnBuyNowButton()
	{
		waitForWebElementPresent(buyNowButton, getTimeOut());
		Assert.assertTrue(buyNowButton.isDisplayed());
		buyNowButton.click();
		return PageFactory.initElements(driver, CategoryListPage.class);
	}
	
	public CategoryListPage clickOnincreaseQuantityButton(String number, String comment)
	{
		waitForWebElementPresent(increaseQuantityButton, getTimeOut());
		Assert.assertTrue(increaseQuantityButton.isDisplayed());
		for(int i=1; i<=Integer.parseInt(number);i++)
		{
			increaseQuantityButton.click();
		}
		return PageFactory.initElements(driver, CategoryListPage.class);
	}
	
	public CategoryListPage clickOnAddToBasketButton()
	{
		waitForWebElementPresent(addToBasketButton, getTimeOut());
		Assert.assertTrue(addToBasketButton.isDisplayed());
		addToBasketButton.click();
		return PageFactory.initElements(driver, CategoryListPage.class);
	}

}
