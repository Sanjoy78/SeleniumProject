package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class ProductDetailsPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//input[@name='items[111700]']/following::span[@class='qtyPlus'][1]")
	private WebElement increaseQuantityButton;
	
	@FindBy(how=How.XPATH, using="//button[@id='addToBasketPdpPage']")
	private WebElement addToBasketButton;
	
	@FindBy(how=How.XPATH, using="//a[@class='continueSku']")
	private WebElement checkOutButton;
	
	@FindBy(how=How.XPATH, using="(//span[@class='sku-badgesMsg'])[1]")
	private WebElement skuOf111700;
	
	@FindBy(how=How.XPATH, using="//input[@name='items[3E8200]']")
	private WebElement quantityBox;
	
	@FindBy(how=How.XPATH, using="(//strong)[6]")
	private WebElement codeText;

	public ProductDetailsPage(final WebDriver driver)
	{
		super(driver);
	}
	

	public ProductDetailsPage clickOnCodeText()
	{
		waitForWebElementPresent(codeText, getTimeOut());
		Assert.assertTrue(codeText.isDisplayed());
		scrollToElementView(codeText);
		codeText.click();
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public ProductDetailsPage scrollToSKU()
	{
		waitForWebElementPresent(skuOf111700, getTimeOut());
		Assert.assertTrue(skuOf111700.isDisplayed());
		scrollToElementView(skuOf111700);
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public BasketPage clickOnCheckOutButton()
	{
		waitForWebElementPresent(checkOutButton, getTimeOut());
		Assert.assertTrue(checkOutButton.isDisplayed());
		checkOutButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, BasketPage.class);
	}
	
	public ProductDetailsPage enterQTYForSKU(String skuId, String qty)
    {
        String locator = "//input[@name='items["+skuId+"]']";
        waitForElementPresent(locator, getTimeOut());
        scrollToElementView(driver.findElement(byLocator(locator)));
        driver.findElement(byLocator(locator)).clear();
        driver.findElement(byLocator(locator)).sendKeys(qty);
        _waitForJStoLoad();
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public ProductDetailsPage clickOnIncreaseQuantityButton(String number, String comment)
	{
		waitForWebElementPresent(increaseQuantityButton, getTimeOut());
		Assert.assertTrue(increaseQuantityButton.isDisplayed());
		for(int i=1; i<=Integer.parseInt(number); i++)
		{
			increaseQuantityButton.click();
		}
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public ProductDetailsPage enterQuantity(String numberOfProduct)
	{
		waitForWebElementPresent(quantityBox, getTimeOut());
		Assert.assertTrue(quantityBox.isDisplayed());
		quantityBox.clear();
		quantityBox.sendKeys(numberOfProduct);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public ProductDetailsPage clickOnAddToBasketButton()
	{
		waitForWebElementPresent(addToBasketButton, getTimeOut());
		Assert.assertTrue(addToBasketButton.isDisplayed());
		addToBasketButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}

}
