package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class CheckOutPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//button[@id='savePaymentInfoCart']")
	private WebElement useThesePaymentDetailsButton;
	
	@FindBy(how=How.XPATH, using="//a[@class='btn btn-primary checkoutBasket']")
	private WebElement placeOrderButton;
	
	@FindBy(how=How.XPATH, using="//input[@id='card']")
	private WebElement cardRadioButton;
	
	public CheckOutPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public CheckOutPage clickOnCardRadioButton()
	{
		  //Actions builder = new Actions(driver);
	      //builder.moveToElement(cardRadioButton).click().build().perform();
		_clickUsingJavaScript(cardRadioButton);
	      return PageFactory.initElements(driver, CheckOutPage.class);
	}
	
	public CheckOutPage clickOnUseThesePaymentDetailsButton()
	{
		waitForWebElementPresent(useThesePaymentDetailsButton, getTimeOut());
		Assert.assertTrue(useThesePaymentDetailsButton.isDisplayed());
		scrollToWebElement(useThesePaymentDetailsButton);
		useThesePaymentDetailsButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, CheckOutPage.class);
	}
	
	public OrderConfirmationPage clickOnPlaceOrderButton()
	{
		waitForWebElementPresent(placeOrderButton, getTimeOut());
		waitForElementEnabled("//a[@class='btn btn-primary checkoutBasket']", getTimeOut());
		Assert.assertTrue(placeOrderButton.isDisplayed());
		placeOrderButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, OrderConfirmationPage.class);
	}
	
	public CheckOutCardPaymentPage clickOnPlaceOrderButtonToMoveCardPage()
	{
		waitForWebElementPresent(placeOrderButton, getTimeOut());
		waitForElementEnabled("//a[@class='btn btn-primary checkoutBasket']", getTimeOut());
		Assert.assertTrue(placeOrderButton.isDisplayed());
		placeOrderButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);
	}

}
