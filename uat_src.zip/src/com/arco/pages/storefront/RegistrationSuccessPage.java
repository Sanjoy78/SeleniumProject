package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.arco.util.ArcoDriverHelper;

public class RegistrationSuccessPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//h1")
	private WebElement successMessage;
	
	public RegistrationSuccessPage(final WebDriver driver)
	{
		super(driver);
	}

}
