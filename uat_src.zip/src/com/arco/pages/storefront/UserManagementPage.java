package com.arco.pages.storefront;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.arco.util.ArcoDriverHelper;

public class UserManagementPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//button[text()='Create User']")
	private WebElement createUserButton;
	
	@FindBy(how=How.ID, using="titleCode")
	private WebElement title;
	
	@FindBy(how=How.ID, using="firstName")
	private WebElement firstName;
	
	@FindBy(how=How.ID, using="lastName")
	private WebElement lastName;
	
	@FindBy(how=How.ID, using="email")
	private WebElement emailID;
	
	@FindBy(how=How.ID, using="phoneNumber")
	private WebElement phoneNumber;
	
	@FindBy(how=How.ID, using="jobTitle")
	private WebElement jobTitle;
	
	@FindBy(how=How.ID, using="userAccountNumber")
	private WebElement orgUnit;
	
	@FindBy(how=How.ID, using="userRole")
	private WebElement userRole;
	
	@FindBy(how=How.XPATH, using="//label[@for='issueRegistrationEmailImmediatelyYes']")
	private WebElement nowRadioButton;
	
	@FindBy(how=How.XPATH, using="//button[@id='createAccountBtn']")
	private WebElement createButton;
	
	public UserManagementPage(final WebDriver driver)
	{
		super(driver);
	}
	
	
	
	public UserManagementPage selectNowRadioButton()
	{
		waitForWebElementPresent(nowRadioButton, getTimeOut());
		Assert.assertTrue(nowRadioButton.isDisplayed());
		nowRadioButton.click();
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage enterJobTitle(String title)
	{
		waitForWebElementPresent(jobTitle, getTimeOut());
		Assert.assertTrue(jobTitle.isDisplayed());
		jobTitle.clear();
		jobTitle.sendKeys(title);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage enterPhoneNumber(String number)
	{
		waitForWebElementPresent(phoneNumber, getTimeOut());
		Assert.assertTrue(phoneNumber.isDisplayed());
		phoneNumber.clear();
		phoneNumber.sendKeys(number);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage enterEmailAddress(String emailAddress)
	{
		waitForWebElementPresent(emailID, getTimeOut());
		Assert.assertTrue(emailID.isDisplayed());
		emailID.clear();
		emailID.sendKeys(emailAddress);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage enterFirstName(String name)
	{
		waitForWebElementPresent(firstName, getTimeOut());
		Assert.assertTrue(firstName.isDisplayed());
		firstName.clear();
		firstName.sendKeys(name);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage enterSurname(String surname)
	{
		waitForWebElementPresent(lastName, getTimeOut());
		Assert.assertTrue(lastName.isDisplayed());
		lastName.clear();
		lastName.sendKeys(surname);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage clickOnCreateUserButton()
	{
		waitForWebElementPresent(createUserButton, getTimeOut());
		Assert.assertTrue(createUserButton.isDisplayed());
		createUserButton.click();
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage selectOrgUnit()
	{
		
		selectDropDownByIndex(orgUnit, 1);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage selectUserRole(String vaule)
	{
		selectDropDown(userRole, vaule);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage selectTitle(String value)
	{
		selectDropDown(title, value);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}

}
