package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;



public class CheckOutCardPaymentPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//input[@id='edPN']")
	private WebElement cardNumber;
	
	@FindBy(how=How.XPATH, using="//select[@id='edExpMonth']")
    private WebElement selectMonth;
    
    @FindBy(how=How.XPATH, using="//select[@id='edExpYear']")
    private WebElement selectYear;
    
    @FindBy(how=How.XPATH, using="//input[@id='btPayNow']")
    private WebElement selectPaybyCard;
    
    @FindBy(how=How.XPATH, using="//input[@placeholder='Security Code']")
    private WebElement enterSecurityCodeBox;
    
    @FindBy(how=How.XPATH, using="//a[@class='addNewCardBtn']")
    private WebElement addNewCard;
    
    String frameName = "AFX_POST_101_iframe";
	
	
	public CheckOutCardPaymentPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public CheckOutCardPaymentPage clickOnAddNewCardButton()
	{
		waitForWebElementPresent(addNewCard, getTimeOut());
		Assert.assertTrue(addNewCard.isDisplayed());
		addNewCard.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);
	}
	
	public CheckOutCardPaymentPage switchToiFrame()
	{
		switchFrameByFrameIndex(0);
		return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);
		
	}
	
	public OrderConfirmationPage clickOnSelectPayByCard()
    
	   {
	        waitForWebElementPresent(selectPaybyCard, getTimeOut());
	        Assert.assertTrue(selectPaybyCard.isDisplayed());
	        selectPaybyCard.click();
	        _waitForPageLoad(driver);
	        return PageFactory.initElements(driver, OrderConfirmationPage.class);
	        
	    }
	
	public CheckOutCardPaymentPage enterCardNumber(String number)
	{
		waitForWebElementPresent(cardNumber, getTimeOut());
		Assert.assertTrue(cardNumber.isDisplayed());
		cardNumber.sendKeys(number);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);
	}
	
	public CheckOutCardPaymentPage selectMonthlist(String month)
    {
        waitForWebElementPresent(selectMonth, getTimeOut());
        Assert.assertTrue(selectMonth.isDisplayed());
        selectDropDownByIndex(selectMonth, 6);
        _waitForJStoLoad();
        return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);
       
    }
	
	public CheckOutCardPaymentPage selectYearlist(String year)
    {
        waitForWebElementPresent(selectYear, getTimeOut());
        Assert.assertTrue(selectYear.isDisplayed());
        selectDropDown(selectYear, year);
        _waitForJStoLoad();
        return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);
       
    }
	
	public CheckOutCardPaymentPage enterSecurityCode(String securitycode)
    {
        waitForWebElementPresent(enterSecurityCodeBox, getTimeOut());
        Assert.assertTrue(enterSecurityCodeBox.isDisplayed());
        enterSecurityCodeBox.click();
        enterSecurityCodeBox.clear();
        enterSecurityCodeBox.sendKeys(securitycode);
        _waitForJStoLoad();
        return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);
    }

}
