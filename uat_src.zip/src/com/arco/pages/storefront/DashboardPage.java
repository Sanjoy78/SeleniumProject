package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class DashboardPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="(//strong)[1]")
	private WebElement userName;
	
	@FindBy(how=How.XPATH, using="//span[@title='header.link.b2b.account']")
	private WebElement accountDetails;
	
	@FindBy(how=How.XPATH, using="//a[@href='/my-account']")
	private WebElement accountOverview;
	
	@FindBy(how=How.XPATH, using="//a[@href='/logout']")
	private WebElement logOut;
	
	@FindBy(how=How.XPATH, using="//label[@class='org-unit-display']")
	private WebElement changeAccount;
	
	@FindBy(how=How.XPATH, using="//span[@class='glyphicon pull-right']")
	private WebElement changeAccountArrowDown;
	
	@FindBy(how=How.CLASS_NAME, using="glyphicon pull-right arrowUp")
	private WebElement changeAccountArrowUp;
	
	@FindBy(how=How.XPATH, using="(//input[@placeholder='Enter product name or code...'])[1]")
	private WebElement searchBox;
	
	@FindBy(how=How.XPATH, using="(//button[@class='glyphicon glyphicon-search'])[1]")
	private WebElement findButton;
	
	@FindBy(how=How.XPATH, using="//span[@class='nav-icon-text quickOrder']")
	private WebElement quickOrderButton;
	
	@FindBy(how=How.XPATH, using="//a[@class='btn btn-primary btn-block']")
	private WebElement signOutButton;
	
	@FindBy(how=How.XPATH, using="//a[@title='PurchasingList']")
	private WebElement purchaseListLink;
	
	@FindBy(how=How.XPATH, using="//input[@name='productCodes[0]']")
	private WebElement inputProductBox1;
	
	@FindBy(how=How.XPATH, using="//input[@name='productQtys[0]']")
	private WebElement inputQtyBox1;
	
	@FindBy(how=How.XPATH, using="//button[@class='arco-primary-btn full-width top-space js-quick-order-submit']")
	private WebElement addToBasketButton;
	
	@FindBy(how=How.XPATH, using="//a[@class='continueSku']")
	private WebElement checkOutButton;
	
	@FindBy(how=How.XPATH, using="//a[text()='Got it ']")
	private WebElement gotIt;
	
	
	public DashboardPage (final WebDriver driver)
	{
		super(driver);
	}
	
	
	public HomePage clickOnGotIt()
	{
		waitForWebElementPresent(gotIt, getTimeOut());
		Assert.assertTrue(gotIt.isDisplayed());
		gotIt.click();
		return PageFactory.initElements(driver, HomePage.class);
	}
	
	public BasketPage clickOnCheckOutButton()
	{
		waitForWebElementPresent(checkOutButton, getTimeOut());
		Assert.assertTrue(checkOutButton.isDisplayed());
		checkOutButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, BasketPage.class);
	}
	
	public DashboardPage clickOnAddToBasketButton()
	{
		waitForWebElementPresent(addToBasketButton, getTimeOut());
		scrollToElementView(addToBasketButton);
		Assert.assertTrue(addToBasketButton.isDisplayed());
		addToBasketButton.click();
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public DashboardPage enterProductID(String productID)
	{
		waitForWebElementPresent(inputProductBox1, getTimeOut());
		Assert.assertTrue(inputProductBox1.isDisplayed());
		inputProductBox1.clear();
		inputProductBox1.sendKeys(productID);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public DashboardPage enterProductQty(String qty)
	{
		waitForWebElementPresent(inputQtyBox1, getTimeOut());
		Assert.assertTrue(inputQtyBox1.isDisplayed());
		inputQtyBox1.clear();
		inputQtyBox1.sendKeys(qty);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public PurchaseListPage clickPurchaseListLink()
	{
		waitForWebElementPresent(purchaseListLink, getTimeOut());
		Assert.assertTrue(purchaseListLink.isDisplayed());
		purchaseListLink.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public boolean quickOrderButtonIsDisplayed()
	{
		waitForWebElementPresent(quickOrderButton, getTimeOut());
		boolean result = false;
		if(quickOrderButton.isDisplayed())
		{
			result=true;
		} else
		{
			result = false;
		}
		return result;
	}
	
	public DashboardPage clickOnQuickOrderButton()
	{
		waitForWebElementPresent(quickOrderButton, getTimeOut());
		Assert.assertTrue(quickOrderButton.isDisplayed());
		quickOrderButton.click();
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public DashboardPage enterProductNameOrCode(String nameOrCode)
	{
		waitForWebElementPresent(searchBox, getTimeOut());
		Assert.assertTrue(searchBox.isDisplayed());
		searchBox.sendKeys(nameOrCode);
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public CategoryListPage clickOnFindButton()
	{
		waitForWebElementPresent(findButton, getTimeOut());
		Assert.assertTrue(findButton.isDisplayed());
		findButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, CategoryListPage.class);
	}
	
	public ProductDetailsPage clickOnFindButtonToNevigateToPDP()
	{
		waitForWebElementPresent(findButton, getTimeOut());
		Assert.assertTrue(findButton.isDisplayed());
		findButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public MyAccountPage clickAccountOverview()
	{
		waitForWebElementPresent(accountOverview, getTimeOut());
		Assert.assertTrue(accountOverview.isDisplayed());
		accountOverview.click();
		return PageFactory.initElements(driver, MyAccountPage.class);
	}
	
	public DashboardPage clickUserName()
	{
		waitForWebElementPresent(userName, getTimeOut());
		Assert.assertTrue(userName.isDisplayed());
		userName.click();
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public HomePage clickSignOutButton()
	{
		waitForWebElementPresent(signOutButton, getTimeOut());
		Assert.assertTrue(signOutButton.isDisplayed());
		signOutButton.click();
		return PageFactory.initElements(driver, HomePage.class);
	}

}
