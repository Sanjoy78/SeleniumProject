package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;


public class HomePage extends ArcoDriverHelper
{
	
	@FindBy(how=How.XPATH, using="//span[@title='Register | Sign in']")
	private WebElement loginRegisterLink;
	
	
	@FindBy(how=How.ID, using="j_username")
	private WebElement userName;
	
	@FindBy(how=How.ID, using="j_password")
	private WebElement passWord;
	
	@FindBy(how=How.ID, using="continueLoginBtnHeader")
	private WebElement signIn;
	
	@FindBy(how=How.XPATH, using="//a[@title='Register']")
	private WebElement registerNow;
	
	@FindBy(how=How.XPATH, using="//span[@class='nav-icon-text quickOrder']")
	private WebElement quickOrderButton;
	
	@FindBy(how=How.XPATH, using="(//input[@placeholder='Enter product name or code...'])[1]")
	private WebElement searchBox;
	
	@FindBy(how=How.XPATH, using="(//button[@class='glyphicon glyphicon-search'])[1]")
	private WebElement findButton;
	
	@FindBy(how=How.XPATH, using="//span[text()='Store Locator']")
	private WebElement storeLocator;
	
	@FindBy(how=How.XPATH, using="//a[text()='Got it ']")
	private WebElement gotIt;
	
	
	public HomePage(final WebDriver driver) 
	{
		super(driver);
		
	}
	
	public HomePage clickOnGotIt()
	{
		waitForWebElementPresent(gotIt, getTimeOut());
		Assert.assertTrue(gotIt.isDisplayed());
		gotIt.click();
		return PageFactory.initElements(driver, HomePage.class);
	}
	
	public StoreFinderPage clickOnStoreLocator()
	{
		waitForWebElementPresent(storeLocator, getTimeOut());
		Assert.assertTrue(storeLocator.isDisplayed());
		storeLocator.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, StoreFinderPage.class);
	}
	
	public CategoryListPage clickOnFindButton()
	{
		waitForWebElementPresent(findButton, getTimeOut());
		Assert.assertTrue(findButton.isDisplayed());
		findButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, CategoryListPage.class);
	}
	
	public HomePage enterProductCodeInSearchBox(String productCode)
	{
		Assert.assertNotNull(productCode, "product code should not null");
		waitForWebElementPresent(searchBox, getTimeOut());
		Assert.assertTrue(searchBox.isDisplayed());
		searchBox.sendKeys(productCode);
		return PageFactory.initElements(driver, HomePage.class);
	}
	
	public EnterEmailAddressPage clickRegisterNow()
	{
		waitForWebElementPresent(registerNow, getTimeOut());
		Assert.assertTrue(registerNow.isDisplayed());
		registerNow.click();
		return PageFactory.initElements(driver, EnterEmailAddressPage.class);
	}
	
	public HomePage clickLoginRegister()
	{
		waitForWebElementPresent(loginRegisterLink, getTimeOut());
		Assert.assertTrue(loginRegisterLink.isDisplayed());
		loginRegisterLink.click();
		return PageFactory.initElements(driver, HomePage.class);
	}
	
	public HomePage enterUserName(String username)
	{
		waitForWebElementPresent(userName, getTimeOut());
		Assert.assertTrue(userName.isDisplayed());
		userName.sendKeys(username);
		return PageFactory.initElements(driver, HomePage.class);
	}
	
	public HomePage enterPassWord(String password)
	{
		waitForWebElementPresent(passWord, getTimeOut());
		Assert.assertTrue(passWord.isDisplayed());
		passWord.sendKeys(password);
		return PageFactory.initElements(driver, HomePage.class);
	}
	
	public DashboardPage clickSignIn()
	{
		waitForWebElementPresent(signIn, getTimeOut());
		Assert.assertTrue(signIn.isDisplayed());
		signIn.click();
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public DashboardPage login(String userName, String passWord)
	{
		enterUserName(userName);
		enterPassWord(passWord);
		clickSignIn();
		return PageFactory.initElements(driver, DashboardPage.class);
	}

}
