package com.arco.pages.backoffice;

import org.openqa.selenium.WebDriver;

import com.arco.util.ArcoDriverHelper;

public class BackofficeDashboardPage extends ArcoDriverHelper
{
	
	public BackofficeDashboardPage(final WebDriver driver)
	{
		super(driver);
	}

}
