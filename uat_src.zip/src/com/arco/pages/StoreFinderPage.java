package com.arco.pages;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.arco.util.ArcoDriverHelper;

public class StoreFinderPage extends ArcoDriverHelper
{
	
	@FindBy(how=How.ID, using="storeDropDown")
	private WebElement selectStore;
	
	@FindBy(how=How.XPATH, using="//button[@class='arco-secondary-btn search-btn']")
	private WebElement arrowButton;
	
	public StoreFinderPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public StoreFinderPage selectStoreFromDropDown(String targetStore)
	{
		waitForWebElementPresent(selectStore, getTimeOut());
		Assert.assertTrue(selectStore.isDisplayed());
		selectDropDown(selectStore, targetStore);
		return PageFactory.initElements(driver, StoreFinderPage.class);
	}
	
	public StoreFinderPage clickOnArrowButton()
	{
		waitForWebElementPresent(arrowButton, getTimeOut());
		Assert.assertTrue(arrowButton.isDisplayed());
		arrowButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, StoreFinderPage.class);
	}

}
