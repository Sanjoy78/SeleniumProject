package com.arco.util;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class TestData 
{
	//private  XSSFCell Cell;
	private String cellData;
	
	
	public  String getCellData(int RowNo, int ColNo) throws Exception
	{
		try
		{
			File source = new File("");
			if(source.exists())
			{
				FileInputStream fis = new FileInputStream(source);
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				XSSFSheet sheet = wb.getSheetAt(0);
				XSSFCell Cell = sheet.getRow(RowNo).getCell(ColNo);
				if(Cell.getCellType()==Cell.CELL_TYPE_NUMERIC)
				{
					cellData = NumberToTextConverter.toText(Cell.getNumericCellValue());
				} else
				{
					cellData = Cell.getStringCellValue();
				}
			}
		} catch (Exception e)
		{
			System.out.println("Exception occoure while reading data from excel "+e.getMessage());
		}
		return cellData;
	}

}
