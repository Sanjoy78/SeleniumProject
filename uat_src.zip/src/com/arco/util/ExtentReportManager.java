package com.arco.util;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReportManager 
{
	
	protected static ExtentReports extent;

	@BeforeClass
	public static ExtentReports getInstance() 
	{
		if (extent == null)
			createInstance();

		return extent;
	}
	
	
@BeforeClass
	public static ExtentReports createInstance() {
		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir")+"/test-output/learnReport.html");
		htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlReporter.config().setChartVisibilityOnOpen(true);
		htmlReporter.config().setTheme(Theme.DARK);
		htmlReporter.config().setDocumentTitle("Automation demo");
		htmlReporter.config().setEncoding("utf-8");
		htmlReporter.config().setReportName("My Own Report");

		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		extent.setSystemInfo("OS", "Window 7");
		extent.setSystemInfo("Host Name:", "Sanjoy");
		extent.setSystemInfo("Environment", "QA");
		extent.setSystemInfo("User Name:", "Sanjoy");

		return extent;
	}



@AfterClass
public void tearDown1()
{
	extent.flush();
	
}

}
