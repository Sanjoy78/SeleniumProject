package com.arco.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestContext;
import org.testng.ITestNGListener;
import org.testng.ITestResult;
import org.testng.internal.annotations.IListeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;

public class TestListener extends ExtentReportManager implements IListeners
{
	
	protected static ExtentReports extent = ExtentReportManager.createInstance();
	private static Map extentTestMap = new HashMap();

	public static synchronized ExtentTest getTest() {
        return (ExtentTest)extentTestMap.get((int) (long) (Thread.currentThread().getId()));
    }
 
    public static synchronized ExtentTest startTest(String testName, String desc) {
        ExtentTest test = extent.createTest(testName, desc);
        extentTestMap.put((int) (long) (Thread.currentThread().getId()), test);
        return test;
    }
	
	public synchronized void onStart(ITestContext context) 
	{
		
	}

	public synchronized void onFinish(ITestContext context) {
		extent.flush();
	}

	public synchronized void onTestStart(ITestResult result) {
		startTest(result.getMethod().getMethodName(),"");
	}

	public synchronized void onTestSuccess(ITestResult result) {
		getTest().pass("Test Passed.");
	}

	public synchronized void onTestFailure(ITestResult result) {
        MediaEntityModelProvider mediaModel;
        
		try {
			mediaModel = MediaEntityBuilder.createScreenCaptureFromPath("").build();
			getTest().fail(result.getThrowable(), mediaModel);
		} catch (IOException e) {
			getTest().fail(result.getThrowable());
		}
	}

	public synchronized void onTestSkipped(ITestResult result) {
		getTest().skip(result.getThrowable());
	}

	public synchronized void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	@Override
	public Class<? extends ITestNGListener>[] getValue() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setValue(Class<? extends ITestNGListener>[] arg0) {
		// TODO Auto-generated method stub
		
	}

}
