package com.arco.util;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;


import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;

import com.arco.pages.asm.ASMHomePage;
import com.arco.pages.backoffice.BackofficeHomePage;
import com.arco.pages.cockpit.WCMSCockpitLoginPage;
import com.arco.pages.storefront.HomePage;



public abstract class ArcoDriverTestCase 
{
	private static final Logger logger = LoggerFactory.getLogger(ArcoDriverTestCase.class);

	public static Object action;
	protected Robot robot;
	public String domain = "";

	// Initialize objects
	public PropertyReaderArco propertyReader = new PropertyReaderArco();
	protected String browser = propertyReader.readApplicationFile("BROWSER");
	// Define objects
	protected WebDriver driver;
	private Runtime runtime = Runtime.getRuntime();
	private static final long MEGABYTE = 1024L * 1024L;
	private FirefoxProfile profile;
	private String path = "";
	private HashMap<String, Object> chromePrefs;
	private ChromeOptions options;
	private String gickoPath;

	@SuppressWarnings("deprecation")
	@BeforeClass
	public void setUp() throws Exception {
		if (("firefox").equalsIgnoreCase(browser)) {
			FirefoxProfile firefoxProfile = new FirefoxProfile();
	        firefoxProfile.setPreference("browser.private.browsing.autostart",true);
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			capabilities.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
			capabilities.setCapability("browser.private.browsing.autostart", true);
			//capabilities.setCapability(CapabilityType.
			gickoPath = propertyReader.readApplicationFile("_gicko_path");
			System.setProperty("webdriver.gecko.driver", gickoPath);
			driver = new FirefoxDriver();
		} else if (("IE").equalsIgnoreCase(browser)) {
			String path = getPath();
			File file = new File(path + "//drivers//IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, false);
			driver = new InternetExplorerDriver(capabilities);
		} else if (("chrome").equalsIgnoreCase(browser)) {
			final String path = getPath();
			System.out.println("path::::::" + path);
			final File file = new File(path + "//drivers//chromedriver.exe");
			System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
			@SuppressWarnings("static-access")
			final DesiredCapabilities capabilities = new DesiredCapabilities().chrome();
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			capabilities.setCapability(ChromeOptions.CAPABILITY, setChromePreferenceForFileDownload());
			driver = new ChromeDriver(capabilities);
		}
		// Maximize window
		driver.manage().window().maximize();

		// Delete cookies
		driver.manage().deleteAllCookies();
		PropertyReaderArco.domainName = propertyReader.readApplicationFile("Server");
	}

	/**
	 * Navigate to the application
	 * 
	 * @throws Exception
	 * 
	 */
	public HomePage applicationSetup() throws Exception {
		driver.navigate().to(propertyReader.readApplicationFile(PropertyReaderArco.getDomain() + "_URL"));
		return PageFactory.initElements(driver, HomePage.class);
	}
	
	public BackofficeHomePage applicationSetupBackoffice() throws Exception
	{
		driver.navigate().to(propertyReader.readApplicationFile(PropertyReaderArco.getDomain()+"_BackofficeURL"));
		return PageFactory.initElements(driver, BackofficeHomePage.class);
	}
	
	public ASMHomePage applicationSetupASM() throws Exception
	{
		driver.navigate().to(propertyReader.readApplicationFile(PropertyReaderArco.getDomain()+"_ASMURL"));
		return PageFactory.initElements(driver, ASMHomePage.class);
	}
	
	public WCMSCockpitLoginPage applicationSetupWCSM() throws Exception
	{
		driver.navigate().to(propertyReader.readApplicationFile(PropertyReaderArco.getDomain()+"_CMSCockpit"));
		return PageFactory.initElements(driver, WCMSCockpitLoginPage.class);
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws IOException {
		logger.debug("Execution completed for test\n");
		logger.debug("*****************************************************************************");
		logger.debug("Memory after execution (in MB) " + runtime.totalMemory() / MEGABYTE);

		// Run the garbage collector
		runtime.gc();
		logger.debug("Memory freed after execution (in MB) " + runtime.freeMemory() / MEGABYTE);

		// Calculate the used memory
		final long memory = runtime.totalMemory() - runtime.freeMemory();
		logger.debug("Used memory (in MB) " + memory / MEGABYTE);
		try {
			if (!(driver == null)) {
				driver.quit();
			}
		} catch (final Exception e) {
			// runtime.exec("taskkill /F /IM IEDriverServer.exe");
		}
		// Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
		// runtime.exec("taskkill /F /IM iexplore.exe");
		System.out.println("Aftet" + Runtime.getRuntime().freeMemory());
	}

	@AfterSuite(alwaysRun = true)
	public void afterMainMethod() throws IOException {

		// runtime.exec("taskkill /F /IM IEDriverServer.exe");
		// runtime.exec("taskkill /F /IM iexplore.exe");

		// driver.findElement(By.xpath("//*[@id='tb_0']")).click();
		// driver.findElement(By.xpath("//button[text()='Logout']")).click();

		// driver.findElement(By.xpath("//*[@id='tb_0']")).click();
		// driver.findElement(By.xpath("//button[text()='Logout']")).click();

	}

	public void setWebDriver(WebDriver driver) {
		this.driver = driver;
	}

	// Handle child windows
	public String switchPreviewWindow() {
		final Set<String> windows = driver.getWindowHandles();
		final Iterator<String> iter = windows.iterator();
		final String parent = iter.next();

		driver.switchTo().window(iter.next());
		return parent;
	}

	// Get absolute path
	public String getPath() {
		String path = "";
		final File file = new File("");
		final String absolutePathOfFirstFile = file.getAbsolutePath();
		path = absolutePathOfFirstFile.replaceAll("\\\\+", "/");
		return path;
	}

	// Get absolute path
	public String getPathUpload() {
		String path = "";
		final File file = new File("");
		final String absolutePathOfFirstFile = file.getAbsolutePath();
		path = absolutePathOfFirstFile.replaceAll("/", "//");
		return path;
	}

	// Capture Screenshot
	public void captureScreenshot(final String fileName) {
		try {

			File file = new File(getPath() + "/screenshots/");
			String[] myFiles;
			if (file.isDirectory()) {
				myFiles = file.list();
				for (int i = 0; i < myFiles.length; i++) {
					File myFile = new File(file, myFiles[i]);
					myFile.delete();
				}
			}
			String screenshotName = this.getFileName(fileName);
			FileOutputStream out = new FileOutputStream("screenshots//" + screenshotName + ".jpg");
			out.write(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES));
			out.close();
			String path = getPath();
			String screen = "file://" + path + "/screenshots/" + screenshotName + ".jpg";
			System.setProperty("org.uncommons.reportng.escape-output", "false");
			Reporter.log("<a href= '" + screen + "'target='_blank' ><img src='" + screen
					+ "' height=\"42\" width=\"42\" >" + screenshotName + "</a>");
		} catch (Exception e) {

		}
	}

	// Creating file name
	public String getFileName(final String file) {
		final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat dateFormat1 = new SimpleDateFormat("hh-mm-ss");
		final Calendar cal = Calendar.getInstance();

		final String fileName = file + dateFormat.format(cal.getTime()) + "_" + dateFormat1.format(cal.getTime());

		return fileName;
	}

	// Switch frame
	public void switchFrame(final String[] arr) {
		for (final String element : arr) {
			driver.switchTo().frame(element);
		}
	}

	enum DriverType {
		Firefox, IE, Chrome
	}

	public void minimizeAllWindows() throws InterruptedException, AWTException {
		robot.keyPress(KeyEvent.VK_WINDOWS);
		Thread.sleep(1000);

		robot.keyPress(KeyEvent.VK_D);
		Thread.sleep(1000);
		robot.keyRelease(KeyEvent.VK_D);
		Thread.sleep(1000);

		robot.keyRelease(KeyEvent.VK_WINDOWS);
		Thread.sleep(1000);

	}

	public void clearMemory() {
		// Get the Java runtime
		final int MAXJVMMemoryUsage = 50;
		logger.debug("Initial Memory consumed (in MB) "
				+ (runtime.totalMemory() - runtime.freeMemory()) / runtime.totalMemory() * 100);
		if ((runtime.totalMemory() - runtime.freeMemory()) / runtime.totalMemory() * 100 >= MAXJVMMemoryUsage) {
			runtime.gc();
			runtime.gc();
			logger.debug("Memory Cleared");
		}
	}



	public String getRandomNumber() {
		DateFormat format = new SimpleDateFormat("ddMMyyHHmmSS");
		Date date = new Date();
		String randomInteger = format.format(date);
		return randomInteger;
	}


	public HomePage applicationStartUp(String application) throws Exception {

		driver.navigate().to(propertyReader.readApplicationFile(application + "_URL"));
		return PageFactory.initElements(driver, HomePage.class);
	}

	public void addLog(String message) {
		Reporter.log(message + "<br>");
	}


	public String randomString(int len) {
		String AB = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		Random rnd = new Random();
		StringBuilder sb = new StringBuilder(len);
		for (int i = 0; i < len; i++)
			sb.append(AB.charAt(rnd.nextInt(AB.length())));
		return sb.toString();
	}


	public FirefoxProfile setFirefoxPreferenceForFileDownload() {
		profile = new FirefoxProfile();
		path = propertyReader.readApplicationFile("File_Path");
		profile.setPreference("browser.download.folderList", 2);
		profile.setPreference("browser.download.dir", path);
		profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
		profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
				"application/msword, application/csv, application/ris, text/csv, image/png, application/pdf, text/html, text/plain, application/zip, application/x-zip, application/x-zip-compressed, application/download, application/octet-stream");
		profile.setPreference("browser.download.manager.showWhenStarting", false);
		profile.setPreference("browser.download.manager.focusWhenStarting", false);
		profile.setPreference("browser.download.useDownloadDir", true);
		profile.setPreference("browser.helperApps.alwaysAsk.force", false);
		profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
		profile.setPreference("browser.download.manager.closeWhenDone", true);
		profile.setPreference("browser.download.manager.showAlertOnComplete", false);
		profile.setPreference("browser.download.manager.useWindow", false);
		profile.setPreference("services.sync.prefs.sync.browser.download.manager.showWhenStarting", false);
		profile.setPreference("pdfjs.disabled", true);
		return profile;
	}


	public ChromeOptions setChromePreferenceForFileDownload() {
		path = propertyReader.readApplicationFile("File_Path");
		chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("profile.default_content_settings.popups", 0);
		chromePrefs.put("download.default_directory", path);
		options = new ChromeOptions();
		options.setExperimentalOption("prefs", chromePrefs);
		return options;
	}



}
