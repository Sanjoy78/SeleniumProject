package com.arco.scripts.asm;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.asm.ASMDashboardPage;
import com.arco.pages.asm.ASMHomePage;
import com.arco.pages.asm.ASMUserCategoryListPage;
import com.arco.pages.asm.ASMUserDashboardPage;
import com.arco.pages.asm.ASMUserMyAccountPage;
import com.arco.pages.asm.ASMUserProductDetailsPage;
import com.arco.pages.asm.ASMUserPurchaseListPage;
import com.arco.util.ArcoDriverTestCase;

public class AddAndRemoveProductInPLThrowASM extends ArcoDriverTestCase
{
	
	private String test;
	private SoftAssert softAssert;
	private ASMHomePage aSMHomePage;
	private ASMDashboardPage aSMDashboardPage;
	private ASMUserMyAccountPage aSMUserMyAccountPage;
	private ASMUserDashboardPage aSMUserDashboardPage;
	private ASMUserPurchaseListPage aSMUserPurchaseListPage;
	private ASMUserCategoryListPage aSMUserCategoryListPage;
	private ASMUserProductDetailsPage aSMUserProductDetailsPage;
	
	@Test
	public void placingOrderForAnonymousUser() throws Exception
	{
		try
		{
			softAssert = new SoftAssert();
			test = propertyReader.getCellData(42, 1);
			
			aSMHomePage = applicationSetupASM();
			aSMDashboardPage = aSMHomePage.loginAsArcoSupport();
			aSMDashboardPage.enterCustomerNameOrEmailId("arcoautomationaccountuserpl@gmail.com");
			aSMDashboardPage.selectUser();
			aSMUserMyAccountPage = aSMDashboardPage.clickOnStartSessionButton();
			aSMUserDashboardPage = aSMUserMyAccountPage.clickOnHomePageLogo();
			aSMUserDashboardPage.enterProductNameOrCode("PIM111500");
			aSMUserProductDetailsPage = aSMUserDashboardPage.clickOnFindButtonToNavigatePDP();
			//aSMUserProductDetailsPage = aSMUserCategoryListPage.clickOnAProductInASM("PIM111500");
			aSMUserProductDetailsPage.clickOnAddToListButton();
			aSMUserProductDetailsPage.clickOnPurchaseListButton();
			aSMUserProductDetailsPage.enterPlNameInSearchPLBox("Apl002");
			aSMUserProductDetailsPage.selectAPL("aSMUserProductDetailsPage");
			aSMUserProductDetailsPage.clickOnSelectProductButton();
			aSMUserProductDetailsPage.clickOnAddToPlButton();
			aSMUserProductDetailsPage.clickOnDoneButton();
			
		}catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
