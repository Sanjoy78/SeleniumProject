package com.arco.scripts.asm;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.asm.ASMDashboardPage;
import com.arco.pages.asm.ASMHomePage;
import com.arco.pages.asm.ASMOrgUnitPage;
import com.arco.pages.asm.ASMUserPurchaseListPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class VerifyDownloadOptionAvailableInASMPLActionDropdown extends ArcoDriverTestCase
{
	
	private String test, expectedArcoAdminName, orgUnit, pL1, actualDownlodLink, expectedDownloadLink;
    private ASMHomePage asmHomePage;
    private ASMDashboardPage asmDashboardPage;
    private ASMOrgUnitPage asmOrgUnitPage ;
    private ASMUserPurchaseListPage aSMUserPurchaseListPage;
    private SoftAssert softAssert;

    private PropertyReaderArco propertyReaderArco;
    @Test
    public void verifyDownloadOptionAvailableInPurchaseListPageInActionDropDown() throws Exception
    {
        try
        {
            softAssert = new SoftAssert();
            propertyReaderArco = new PropertyReaderArco();
            test = propertyReaderArco.getCellData(50, 1);
            expectedArcoAdminName = propertyReaderArco.getCellData(50, 2);
            orgUnit=propertyReaderArco.getCellData(50, 3);
            pL1 = propertyReaderArco.getCellData(50, 4);
        
            expectedDownloadLink=propertyReaderArco.getCellData(50, 5);
            
            asmHomePage = applicationSetupASM();
            asmDashboardPage = asmHomePage.loginAsArcoAdmin();
            addLog("Opening ASM");
            String actualArcoUser = asmDashboardPage.getText("(//span[@class='ASM_loggedin_text_name'])[2]", "Here we are fetching the Arco admin name for verification");
            softAssert.assertEquals(actualArcoUser, expectedArcoAdminName);
            asmDashboardPage.enterOrgUnit(orgUnit);
            asmDashboardPage.selectOrgUnit(orgUnit);
            asmOrgUnitPage= asmDashboardPage.clickManageOrgButton();
            aSMUserPurchaseListPage =asmOrgUnitPage.clickOnPurchaseListLink();
            aSMUserPurchaseListPage.clickOnCheckBoxForAPL(pL1);
            aSMUserPurchaseListPage.clickOnSlectActionDropdown();
            String actualDownlodLink = asmDashboardPage.getText("(//a[@title='Download'])[4]", "Here we are fetching the Download link for verification");
            softAssert.assertEquals(actualDownlodLink, expectedDownloadLink);
            softAssert.assertAll();




        } catch (Error e)
        {
            captureScreenshot(test);
            throw e;
        } catch (Exception e)
        {
            captureScreenshot(test);
            throw e;
        }
    }

}
