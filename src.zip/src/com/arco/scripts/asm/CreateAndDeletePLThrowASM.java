package com.arco.scripts.asm;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.asm.ASMDashboardPage;
import com.arco.pages.asm.ASMHomePage;
import com.arco.pages.asm.ASMUserDashboardPage;
import com.arco.pages.asm.ASMUserMyAccountPage;
import com.arco.pages.asm.ASMUserPurchaseListPage;
import com.arco.util.ArcoDriverTestCase;


public class CreateAndDeletePLThrowASM extends ArcoDriverTestCase
{
	
	private String test;
	private SoftAssert softAssert;
	private ASMHomePage aSMHomePage;
	private ASMDashboardPage aSMDashboardPage;
	private ASMUserMyAccountPage aSMUserMyAccountPage;
	private ASMUserDashboardPage aSMUserDashboardPage;
	private ASMUserPurchaseListPage aSMUserPurchaseListPage;
    
    @Test
	public void placingOrderForAnonymousUser() throws Exception
	{
		try
		{
			softAssert = new SoftAssert();
			test = propertyReader.getCellData(42, 1);
			
			aSMHomePage = applicationSetupASM();
			aSMDashboardPage = aSMHomePage.loginAsArcoSupport();
			aSMDashboardPage.enterCustomerNameOrEmailId("arcoautomationaccountuserpl@gmail.com");
			aSMDashboardPage.selectUser();
			aSMUserMyAccountPage = aSMDashboardPage.clickOnStartSessionButton();
			aSMUserDashboardPage = aSMUserMyAccountPage.clickOnHomePageLogo();
			aSMUserPurchaseListPage = aSMUserDashboardPage.clickPurchaseListLink();
			aSMUserPurchaseListPage.clickCreateListButton();
			aSMUserPurchaseListPage.enterPurchaseListName("PL0003");
			aSMUserPurchaseListPage.selectAccountPurchaseListType();
			aSMUserPurchaseListPage.clickDoneButtonForPurchaseListCreation();
			aSMUserPurchaseListPage.clickDoneButtonAfterPurchaseListCreation();
			aSMUserPurchaseListPage.searchPurchaseListByName("PL0003");
			aSMUserPurchaseListPage.clickOnDotForAPL("PL0003");
			softAssert.assertTrue(aSMUserPurchaseListPage.isElementPresent("(//a[@title='View'])[1]"));
			softAssert.assertTrue(aSMUserPurchaseListPage.isElementPresent("(//a[@title='Edit'])[1]"));
			softAssert.assertTrue(aSMUserPurchaseListPage.isElementPresent("(//a[@title='Copy'])[1]"));
			softAssert.assertTrue(aSMUserPurchaseListPage.isElementPresent("(//a[@title='Delete'])[1]"));
			aSMUserPurchaseListPage.clickOnDeleteForAPL("PL0003");
			aSMUserPurchaseListPage.clickOnYesButtonForConfirmation();
			softAssert.assertAll();
			
			
			} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}


}
