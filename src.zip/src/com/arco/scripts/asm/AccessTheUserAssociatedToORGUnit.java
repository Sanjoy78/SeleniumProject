package com.arco.scripts.asm;

import com.arco.util.ArcoDriverTestCase;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.asm.ASMDashboardPage;
import com.arco.pages.asm.ASMHomePage;
import com.arco.pages.asm.ASMOrgUnitPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class AccessTheUserAssociatedToORGUnit extends ArcoDriverTestCase
{
	
	private String test, expectedArcoAdminName, actualArcoUser, orgUnit, user;
    private ASMHomePage asmHomePage;
    private ASMDashboardPage asmDashboardPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;
    private ASMOrgUnitPage asmOrgUnitPage;
    
    
    
    @Test
    public void accessTheUserAssociatedToORGUnit() throws Exception
    {
        try
        {
            softAssert = new SoftAssert();
            propertyReaderArco = new PropertyReaderArco();
            test = propertyReaderArco.getCellData(45, 1);
            expectedArcoAdminName = propertyReaderArco.getCellData(45, 2);
            orgUnit = propertyReaderArco.getCellData(45, 3);
            user = propertyReaderArco.getCellData(45, 4);
            
            
            asmHomePage = applicationSetupASM();
            asmDashboardPage = asmHomePage.loginAsArcoAdmin();
            actualArcoUser = asmDashboardPage.getText("(//span[@class='ASM_loggedin_text_name'])[2]", "Here we are fetching the Arco admin name for verification");
            softAssert.assertEquals(actualArcoUser, expectedArcoAdminName);
            
            
            asmDashboardPage.enterOrgUnit(orgUnit);
            asmDashboardPage.selectOrgUnit(orgUnit);
            asmOrgUnitPage= asmDashboardPage.clickManageOrgButton();
            asmOrgUnitPage.clickToExpandRootOrgUnit();
            asmOrgUnitPage.clickToSelectUnitOrg();
            asmOrgUnitPage.clickToSelectUserFromDropdownList();
            softAssert.assertTrue(asmOrgUnitPage.isUserPresent(user));
            
            
        } catch (Error e)
        {
            captureScreenshot(test);
            throw e;
        } catch (Exception e)
        {
            captureScreenshot(test);
            throw e;
        }
    }

}
