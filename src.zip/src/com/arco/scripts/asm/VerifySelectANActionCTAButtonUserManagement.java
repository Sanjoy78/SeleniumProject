package com.arco.scripts.asm;

import com.arco.util.ArcoDriverTestCase;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.asm.ASMDashboardPage;
import com.arco.pages.asm.ASMHomePage;
import com.arco.pages.asm.ASMOrgUnitPage;
import com.arco.pages.asm.ASMUserMyAccountPage;
import com.arco.pages.asm.ASMUserUserManagementPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class VerifySelectANActionCTAButtonUserManagement extends ArcoDriverTestCase
{
	
	 private String test, expectedArcoAdminName, actualArcoUser, orgUnit;
	    private ASMHomePage asmHomePage;
	    private ASMDashboardPage asmDashboardPage;
	    private ASMUserMyAccountPage asmUserMyAccountPage;
	    private ASMUserUserManagementPage asmUserUserManagementPage;
	    private ASMOrgUnitPage aSMOrgUnitPage;
	    private SoftAssert softAssert;
	    private PropertyReaderArco propertyReaderArco;
	    
	    
	    
	    @Test
	    public void verifySelectANActionCTAButtonUserManagement() throws Exception
	    {
	        try
	        {
	            softAssert = new SoftAssert();
	            propertyReaderArco = new PropertyReaderArco();
	            test = propertyReaderArco.getCellData(46, 1);
	            expectedArcoAdminName = propertyReaderArco.getCellData(46, 2);
	            orgUnit = propertyReaderArco.getCellData(46, 3);
	            
	            
	            
	            asmHomePage = applicationSetupASM();
	            asmDashboardPage = asmHomePage.loginAsArcoAdmin();
	            actualArcoUser = asmDashboardPage.getText("(//span[@class='ASM_loggedin_text_name'])[2]", "Here we are fetching the Arco admin name for verification");
	            softAssert.assertEquals(actualArcoUser, expectedArcoAdminName);
	            
	            asmDashboardPage.enterOrgUnit(orgUnit);
	            asmDashboardPage.selectOrgUnit(orgUnit);
	            aSMOrgUnitPage= asmDashboardPage.clickManageOrgButton();
	            aSMOrgUnitPage.clickUserName();
	            asmUserMyAccountPage = aSMOrgUnitPage.clickAccountOverview();
	            asmUserUserManagementPage = asmUserMyAccountPage.clickOnUserManagementLink();
	            asmUserUserManagementPage.clickToSelectUser();
	            softAssert.assertTrue(asmUserUserManagementPage.isSelectAnActionCTAButton());
	            
	            
	            
	        } catch (Error e)
	        {
	            captureScreenshot(test);
	            throw e;
	        } catch (Exception e)
	        {
	            captureScreenshot(test);
	            throw e;
	        }
	    }

}
