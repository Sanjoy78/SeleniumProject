package com.arco.scripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.MyAccountPage;
import com.arco.pages.storefront.UserManagementPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;


public class CreateUserCustomerAdminTest extends ArcoDriverTestCase
{
	private String test, customerAdmUserName, customerAdmPassWord, title, name, surname, emailid, phonenumber, jobtitle, orgunit, role;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private MyAccountPage myAccountPage;
	private UserManagementPage userManagementPage;
	
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void createUserAsCustomerAdmin() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			test = propertyReaderArco.getCellData(17, 1);
			customerAdmUserName = propertyReaderArco.getCellData(17, 2);
			customerAdmPassWord = propertyReaderArco.getCellData(17, 3);
			title = propertyReaderArco.getCellData(17, 4);
			name = propertyReaderArco.getCellData(17, 5);
			surname = propertyReaderArco.getCellData(17, 6);
			emailid = propertyReaderArco.getCellData(17, 7);
			phonenumber = propertyReaderArco.getCellData(17, 8);
			jobtitle = propertyReaderArco.getCellData(17, 9);
			orgunit = propertyReaderArco.getCellData(17, 10);
			role = propertyReaderArco.getCellData(17, 11);
			
			homePage = applicationSetup();
			homePage.clickOnGotIt();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(customerAdmUserName, customerAdmPassWord);
			dashboardPage.clickOnGotIt();
			dashboardPage.clickUserName();
			myAccountPage = dashboardPage.clickAccountOverview();
			userManagementPage = myAccountPage.clickOnUserManagementLink();
			userManagementPage.clickOnCreateUserButton();
			userManagementPage.selectTitle(title);
			userManagementPage.enterFirstName(name);
			userManagementPage.enterSurname(surname);
			userManagementPage.enterEmailAddress(emailid);
			userManagementPage.enterPhoneNumber(phonenumber);
			userManagementPage.enterJobTitle(jobtitle);
			userManagementPage.selectOrgUnit(orgunit);
			userManagementPage.selectUserRole(role);
			userManagementPage.clickOnCreateButton();
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
