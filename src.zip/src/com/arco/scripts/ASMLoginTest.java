package com.arco.scripts;

/*
 * We will open ASM home page verify home page title
 * Will enter user id and password and click on sign in button
 * Then it will verify if the Arco admin or Arco support is able to logged in successfully or not.
 */


import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.asm.ASMDashboardPage;
import com.arco.pages.asm.ASMHomePage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;


public class ASMLoginTest extends ArcoDriverTestCase
{
	private String test, homePageTitle, actualHomePageTitle, expectedArcoAdminName, expectedArcoSupportName;
	private ASMHomePage asmHomePage;
	private ASMDashboardPage asmDashboardPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void asmLoginTestAsArcoAdmin() throws Exception
	{
		try
		{
			softAssert = new SoftAssert();
			test = propertyReader.getCellData(10, 1);
			expectedArcoAdminName = propertyReader.getCellData(10, 2);
			homePageTitle = propertyReader.getCellData(10, 3);
		    asmHomePage = applicationSetupASM();
		    actualHomePageTitle = asmHomePage.getTitle();
		    System.out.println(actualHomePageTitle);
		    softAssert.assertEquals(homePageTitle, actualHomePageTitle);
		    asmDashboardPage = asmHomePage.loginAsArcoAdmin();
		    String actualArcoUser = asmDashboardPage.getText("(//span[@class='ASM_loggedin_text_name'])[2]", "Here we are fetching the Arco admin name for verification");
		    softAssert.assertEquals(actualArcoUser, expectedArcoAdminName);
		    asmHomePage = asmDashboardPage.clickOnLogOutButton();
		    softAssert.assertAll();
		    
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}
	
	@Test
	public void asmLoginTestAsArcoSupport() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(11, 1);
			expectedArcoSupportName = propertyReaderArco.getCellData(11, 2);
			
			asmDashboardPage = asmHomePage.loginAsArcoSupport();
			String actualArcoUser = asmDashboardPage.getText("(//span[@class='ASM_loggedin_text_name'])[2]", "Here we are fetching the Arco admin name for verification");
			softAssert.assertEquals(actualArcoUser, expectedArcoSupportName);
			asmHomePage = asmDashboardPage.clickOnLogOutButton();
			softAssert.assertAll();
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
