package com.arco.scripts;

/*
 * 1) We will open Hybris backoffice and verify login page title
 * 2) Will enter user id and password and click on login button
 * 3) Will verify if used is logged in successfully by verifying backoffice dash board page title.
 * 4) Search for an left navigation menu and verify that the menu bar is displayed.
 */

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.backoffice.BackofficeDashboardPage;
import com.arco.pages.backoffice.BackofficeHomePage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;


public class UserCanLogintoBackOfficeTest extends ArcoDriverTestCase
{
	private String test, loginPageTitle, actualLoginPageTitle, dashboardPageTitle, actualDashboardPageTitle, searchTerm;
	private BackofficeHomePage backofficeHomePage;
	private BackofficeDashboardPage backofficeDashboardPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void verifyingUserCanLoginToBackoffice() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(9, 1);
			actualLoginPageTitle = propertyReaderArco.getCellData(9, 2);
			actualDashboardPageTitle = propertyReader.getCellData(9, 3);
			searchTerm = propertyReader.getCellData(9, 4);
			
			backofficeHomePage = applicationSetupBackoffice();
			loginPageTitle = backofficeHomePage.getTitle();
			softAssert.assertEquals(loginPageTitle, actualLoginPageTitle);
			backofficeDashboardPage = backofficeHomePage.login();
			dashboardPageTitle = backofficeDashboardPage.getTitle();
			softAssert.assertEquals(dashboardPageTitle, actualDashboardPageTitle);
			backofficeDashboardPage.enterSearchTermInSearchTreeBox(searchTerm);
			softAssert.assertTrue(backofficeDashboardPage.isLeftNavigationMenuDisplayed(searchTerm));
			softAssert.assertAll();
			
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
