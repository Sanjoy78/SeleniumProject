package com.arco.scripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.cockpit.WCMSCockpitDashboardPage;
import com.arco.pages.cockpit.WCMSCockpitLoginPage;
import com.arco.util.ArcoDriverTestCase;



public class WCMSCockpitLoginTest extends ArcoDriverTestCase
{
	
	private String test, cmsLoginPageTitle, actualCmsLoginPageTitle, cmsDashboardPageTitle, ActualCmsDashboardPageTitle;
	private WCMSCockpitLoginPage wcmsCockpitLoginPage;
	private WCMSCockpitDashboardPage wcmsCockpitDashboardPage;
	private SoftAssert softAssert;
	
	@Test
	public void verifyWCMSCockpitLogin() throws Exception
	{
		try
		{
			softAssert = new SoftAssert();
			test = propertyReader.getCellData(14, 1);
			cmsDashboardPageTitle = propertyReader.getCellData(14, 2);
			cmsLoginPageTitle = propertyReader.getCellData(14, 3);
			
			wcmsCockpitLoginPage = applicationSetupWCSM();
			actualCmsLoginPageTitle = wcmsCockpitLoginPage.getTitle();
			softAssert.assertEquals(actualCmsLoginPageTitle, cmsLoginPageTitle);
			wcmsCockpitDashboardPage = wcmsCockpitLoginPage.loginToWCMSCockpit();
			ActualCmsDashboardPageTitle = wcmsCockpitDashboardPage.getTitle();
			softAssert.assertEquals(cmsDashboardPageTitle, ActualCmsDashboardPageTitle);
			softAssert.assertAll();
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
