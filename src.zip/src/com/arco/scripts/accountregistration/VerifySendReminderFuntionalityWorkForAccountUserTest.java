package com.arco.scripts.accountregistration;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.MyAccountPage;

import com.arco.pages.storefront.UserManagementPage;

import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class VerifySendReminderFuntionalityWorkForAccountUserTest extends ArcoDriverTestCase
{
	
	private String test, userId, passWord, accountuserID, expectedUserDetails, actualUserDetails,
    actualEmailReminderCountBefore, actualEmailReminderCountAfter;
    
    
    private HomePage homePage;
    private DashboardPage dashboardPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;
    private UserManagementPage userManagementPage;
    private MyAccountPage myAccountPage;
    private SoftAssert softassert;


    
    @Test
    public void verifySendReminderLink() throws Exception
    {
        try
        {
            propertyReaderArco = new PropertyReaderArco();
            softAssert = new SoftAssert();
            test = propertyReaderArco.getCellData(36, 1);
            userId = propertyReaderArco.getCellData(36, 2);
            passWord = propertyReaderArco.getCellData(36, 3);
            expectedUserDetails = propertyReaderArco.getCellData(36, 4);
            accountuserID = propertyReaderArco.getCellData(36, 5);
            
            
            homePage = applicationSetup();
            homePage.clickLoginRegister();
            dashboardPage = homePage.login(userId, passWord);
            actualUserDetails = dashboardPage.getText("(//strong)[1]", "Here we are featching user details");
            softAssert.assertEquals(actualUserDetails, expectedUserDetails);
            dashboardPage.clickUserName();
            myAccountPage = dashboardPage.clickAccountOverview();
            userManagementPage = myAccountPage.clickOnUserManagementLink();
            userManagementPage.enterSearchUsersBox(accountuserID);
            userManagementPage.clickOnUser(accountuserID);
            actualEmailReminderCountBefore = userManagementPage.getText("//span[@id = 'regReminderCountId']", "Here we are featching actual Reminder Count");
            userManagementPage.clickOnSendReminderButton();
            actualEmailReminderCountAfter = userManagementPage.getText("//span[@id = 'regReminderCountId']", "Here we are featching actual Reminder Count");
            
            
            }
        catch (final Error e) {
            captureScreenshot(test);
            throw e;
        } catch (final Exception e) {
            captureScreenshot(test);
            throw e;
        }
    }

}
