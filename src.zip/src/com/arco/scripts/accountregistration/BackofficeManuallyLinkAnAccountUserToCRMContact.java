package com.arco.scripts.accountregistration;

import com.arco.util.ArcoDriverTestCase;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.backoffice.BackofficeDashboardPage;
import com.arco.pages.backoffice.BackofficeHomePage;
import com.arco.pages.backoffice.B2BCustomerPage;
import com.arco.util.PropertyReaderArco;

public class BackofficeManuallyLinkAnAccountUserToCRMContact extends ArcoDriverTestCase
{
	
	private String test, B2BCustomer, customerEmailID, SAPContactID, expectedLastName, expectedSAPContactID;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;
    private BackofficeHomePage backofficeHomePage;
    private BackofficeDashboardPage backofficeDashboardPage;
    private B2BCustomerPage b2bCustomerPage;
    
    @Test
    public void backofficeManuallyLinkAnAccountUserToCRMContact() throws Exception
    {
        try
        {
            propertyReaderArco = new PropertyReaderArco();
            softAssert = new SoftAssert();
            test = propertyReaderArco.getCellData(40, 1);
            B2BCustomer = propertyReaderArco.getCellData(40, 2);
            customerEmailID = propertyReaderArco.getCellData(40, 3);
            SAPContactID = propertyReaderArco.getCellData(40, 4);
            expectedLastName = propertyReaderArco.getCellData(40, 5);
            
            
            
            
            backofficeHomePage = applicationSetupBackoffice();
            backofficeDashboardPage = backofficeHomePage.login();
            backofficeDashboardPage.ifErrorMessageExistThenClickOnIt();
            backofficeDashboardPage.enterSearchTermInSearchTreeBox(B2BCustomer);
            b2bCustomerPage = backofficeDashboardPage.clickOnB2BCustomer();
            b2bCustomerPage.enterValueInSearchBox(customerEmailID);
            b2bCustomerPage.clickOnSearchButton();
            String actualLastName = b2bCustomerPage.getText("(//div[@class='z-listcell-content'])[4]/span", "Here we are retrieving the last name of the customer for verification");
            softAssert.assertEquals(actualLastName, expectedLastName);
            b2bCustomerPage.selectUser();
            b2bCustomerPage.clickOnExpandArrowButton();
            b2bCustomerPage.clickOnAdministrationTab();
            b2bCustomerPage.enterSAPContactIDInTextBox("0000"+SAPContactID);
            b2bCustomerPage.clickOnSaveButton();
            String actualSAPContactID = b2bCustomerPage.getAttribute("(//input[@class='ye-input-text ye-com_hybris_cockpitng_editor_defaulttext z-textbox'])[21]", "value", "Here we are retrieving the actual updated SAP contact ID of the customer for verification");
            softAssert.assertEquals(actualSAPContactID, "0000"+SAPContactID);
            softAssert.assertAll();
            
        }
        catch (final Error e) {
            captureScreenshot(test);
            throw e;
        } catch (final Exception e) {
            captureScreenshot(test);
            throw e;
        }
    }

}
