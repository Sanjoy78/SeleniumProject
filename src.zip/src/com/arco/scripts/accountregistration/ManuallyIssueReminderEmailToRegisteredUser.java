package com.arco.scripts.accountregistration;

import org.testng.annotations.Test;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.MyAccountPage;
import com.arco.pages.storefront.UserDetailsPage;
import com.arco.pages.storefront.UserManagementPage;
import com.arco.util.ArcoDriverTestCase;

public class ManuallyIssueReminderEmailToRegisteredUser extends ArcoDriverTestCase
{
	
	private String test, arcoAdminID, arcoAdminPassword, userDetails, accountUserDetails;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private MyAccountPage myAccountPage;
	private UserManagementPage userManagementPage;
	private UserDetailsPage userDetailsPage;
	
	@Test
	public void manuallyIssueReminderEmailToRegisteredUser()
	{
		try
		{
			test = propertyReader.getCellData(29, 1);
			arcoAdminID = propertyReader.getCellData(29, 2);
			arcoAdminPassword = propertyReader.getCellData(29, 3);
			userDetails = propertyReader.getCellData(29, 4);
			accountUserDetails = propertyReader.getCellData(29, 5);
			
			homePage = applicationSetup();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(arcoAdminID, arcoAdminPassword);
			dashboardPage.clickUserName();
			myAccountPage = dashboardPage.clickAccountOverview();
			userManagementPage = myAccountPage.clickOnUserManagementLink();
			userManagementPage.searchUser(accountUserDetails);
			userDetailsPage = userManagementPage.clickOnUser();
			userDetailsPage.clickOSendReminderLink();
			
		}catch(Exception e)
		{
			
		}catch(Error e)
		{
			
		}
	}

}
