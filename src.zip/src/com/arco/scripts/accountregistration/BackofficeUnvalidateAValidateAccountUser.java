package com.arco.scripts.accountregistration;

import com.arco.util.ArcoDriverTestCase;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.backoffice.BackofficeDashboardPage;
import com.arco.pages.backoffice.BackofficeHomePage;
import com.arco.pages.backoffice.B2BCustomerPage;
import com.arco.util.PropertyReaderArco;

public class BackofficeUnvalidateAValidateAccountUser extends ArcoDriverTestCase
{
	private String test, B2BCustomer, customerEmailID, expectedLastName, expectedUserStateBefore, expectedUserStateAfter;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;
    private BackofficeHomePage backofficeHomePage;
    private BackofficeDashboardPage backofficeDashboardPage;
    private B2BCustomerPage b2bCustomerPage;
    
   @Test
    public void backofficeUnvalidateAValidateAccountUser() throws Exception
    {
        try
        {
            propertyReaderArco = new PropertyReaderArco();
            softAssert = new SoftAssert();
            test = propertyReaderArco.getCellData(39, 1);
            B2BCustomer = propertyReaderArco.getCellData(39, 2);
            customerEmailID = propertyReaderArco.getCellData(39, 3);
            expectedLastName = propertyReaderArco.getCellData(39, 4);
            expectedUserStateBefore = propertyReaderArco.getCellData(39, 5);
            expectedUserStateAfter = propertyReaderArco.getCellData(39, 6);
            
            
            backofficeHomePage = applicationSetupBackoffice();
            backofficeDashboardPage = backofficeHomePage.login();
            backofficeDashboardPage.ifErrorMessageExistThenClickOnIt();
            backofficeDashboardPage.enterSearchTermInSearchTreeBox(B2BCustomer);
            b2bCustomerPage = backofficeDashboardPage.clickOnB2BCustomer();
            b2bCustomerPage.enterValueInSearchBox(customerEmailID);
            b2bCustomerPage.clickOnSearchButton();
            String actualLastName = b2bCustomerPage.getText("(//div[@class='z-listcell-content'])[4]/span", "Here we are retrieving the last name of the customer for verification");
            softAssert.assertEquals(actualLastName, expectedLastName);
            b2bCustomerPage.selectUser();
            b2bCustomerPage.clickOnExpandArrowButton();
            String actualUserState = b2bCustomerPage.getAttribute("(//input[@class='z-combobox-input'])[14]", "value", "Here we are retrieving the user state of the customer for verification");
            softAssert.assertEquals(actualUserState, expectedUserStateBefore);
            b2bCustomerPage.clickOnDownArrowForUserState();
            b2bCustomerPage.clickOnVerifiedButton();
            b2bCustomerPage.clickOnSaveButton();
            actualUserState = b2bCustomerPage.getAttribute("(//input[@class='z-combobox-input'])[14]", "value", "Here we are retrieving the user state of the customer for verification");
            softAssert.assertEquals(actualUserState, expectedUserStateAfter);
            b2bCustomerPage.clickOnDownArrowForUserState();
            b2bCustomerPage.clickOnAuthorisedButton();
            b2bCustomerPage.clickOnSaveButton();
            softAssert.assertAll();
            
        }
        catch (final Error e) {
            captureScreenshot(test);
            throw e;
        } catch (final Exception e) {
            captureScreenshot(test);
            throw e;
        }
    }
	

}
