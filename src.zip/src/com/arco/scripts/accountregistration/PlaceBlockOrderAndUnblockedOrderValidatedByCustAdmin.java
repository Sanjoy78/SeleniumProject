package com.arco.scripts.accountregistration;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.backoffice.B2BCustomerPage;
import com.arco.pages.backoffice.BackofficeDashboardPage;
import com.arco.pages.backoffice.BackofficeHomePage;
import com.arco.pages.backoffice.OrdersPage;
import com.arco.pages.storefront.BasketPage;
import com.arco.pages.storefront.CheckOutPage;
import com.arco.pages.storefront.CreatePasswordPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.EnterEmailAddressPage;
import com.arco.pages.storefront.EnterPersonalDetailsPage;
import com.arco.pages.storefront.HaveAccountNumberPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.OrderConfirmationPage;
import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.pages.storefront.RegistrationSuccessPage;
import com.arco.pages.storefront.VerifyAccountPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class PlaceBlockOrderAndUnblockedOrderValidatedByCustAdmin extends ArcoDriverTestCase
{
	private String test, emailId, orgUnit, title, name, surName, phoneNo, jobtitle, passWord, expectedmessage, productCode, sku, numberOfItem, 
	purchaseOrderNumber, country, address1, town, postCode, contactName, contactNumber, orderSuccessMessage, orderId; 
	private HomePage homePage;
	private EnterEmailAddressPage enterEmailAddressPage;
	private HaveAccountNumberPage haveAccountNumberPage;
	private VerifyAccountPage verifyAccountPage;
	private EnterPersonalDetailsPage enterPersonalDetailsPage;
	private CreatePasswordPage createPasswordPage;
	private RegistrationSuccessPage registrationSuccessPage;
	private PropertyReaderArco propertyReaderArco;
	private DashboardPage dashboardPage;
	private ProductDetailsPage productDetailsPage;
	private BasketPage basketPage;
	private CheckOutPage checkOutPage;
	private OrderConfirmationPage orderConfirmationPage;
	
	private String searchTerm1 = "B2B Customer";
	private String searchTerm2 = "Orders";
	private BackofficeHomePage backofficeHomePage;
	private BackofficeDashboardPage backofficeDashboardPage;
	private B2BCustomerPage b2BCustomerPage;
	private OrdersPage ordersPage;
	
	@Test
	public void placeBlockOrderAndUnblockedOrderValidatedByCustAdmin() throws Exception
	{
		try
		{
			SoftAssert softassert = new SoftAssert();
			test = propertyReader.getCellData(37, 1);
			emailId = propertyReader.getCellData(37, 2);
			orgUnit = propertyReader.getCellData(37, 3);
			title = propertyReader.getCellData(37, 4);
			name = propertyReader.getCellData(37, 5);
			surName = propertyReader.getCellData(37, 6);
			phoneNo = propertyReader.getCellData(37, 7);
			jobtitle = propertyReader.getCellData(37, 8);
			passWord = propertyReader.getCellData(37, 9);
			expectedmessage = propertyReader.getCellData(37, 10);
			productCode = propertyReader.getCellData(37, 11);
			sku = propertyReader.getCellData(37, 12);
			numberOfItem = propertyReader.getCellData(37, 13);
			purchaseOrderNumber = propertyReader.getCellData(37, 14);
			country = propertyReader.getCellData(37, 15);
			address1 = propertyReader.getCellData(37, 16);
			town = propertyReader.getCellData(37, 17);
			postCode = propertyReader.getCellData(37, 18);
			contactName = propertyReader.getCellData(37, 19);
			contactNumber = propertyReader.getCellData(37, 20);
			
			homePage = applicationSetup();
			homePage.clickOnGotIt();
			homePage.clickLoginRegister();
			enterEmailAddressPage = homePage.clickRegisterNow();
			enterEmailAddressPage.enterEmailID(emailId);
			haveAccountNumberPage = enterEmailAddressPage.clickContinueButton();
			haveAccountNumberPage.selectYesAccount();
			haveAccountNumberPage.enterAccountNumber(orgUnit);
			verifyAccountPage = haveAccountNumberPage.clickContinueButtonForAccount();
			enterPersonalDetailsPage = verifyAccountPage.clickContinueButton_Acc();
			enterPersonalDetailsPage.selectTitle(title);
			enterPersonalDetailsPage.enterFirstName(name);
			enterPersonalDetailsPage.enterSurName(surName);
			enterPersonalDetailsPage.enterPhoneNumber(phoneNo);
			enterPersonalDetailsPage.enterJobTitle(jobtitle);
			enterPersonalDetailsPage.selectTCCheckbox();
			enterPersonalDetailsPage.selectMarketingCheckbox();
			createPasswordPage = enterPersonalDetailsPage.clickContinueButton();
			createPasswordPage.enterPassword(passWord);
			registrationSuccessPage = createPasswordPage.clickRegisterButton();
			String actualmessage = registrationSuccessPage.getText("//h1", "We are retrieving registration success message");
			softassert.assertEquals(actualmessage, expectedmessage);
			backofficeHomePage = applicationSetupBackoffice();
			backofficeDashboardPage = backofficeHomePage.login();
			backofficeDashboardPage.ifErrorMessageExistThenClickOnIt();
			backofficeDashboardPage.enterSearchTermInSearchTreeBox(searchTerm1);
			b2BCustomerPage = backofficeDashboardPage.clickOnB2BCustomer();
			b2BCustomerPage.enterValueInSearchBox(emailId);
			b2BCustomerPage.clickOnSearchButton();
			b2BCustomerPage.selectUser();
			b2BCustomerPage.clickOnExpandArrowButton();
			b2BCustomerPage.clickOnDownArrowForUserState();
			b2BCustomerPage.clickOnVerifiedButton();
			b2BCustomerPage.clickOnSaveButton();
			
			homePage = applicationSetup();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(emailId, passWord);
			dashboardPage.enterProductNameOrCode(productCode);
			productDetailsPage = dashboardPage.clickOnFindButtonToNavigatePDP();
			productDetailsPage.enterQTYForSKU(sku, numberOfItem);
			productDetailsPage.clickOnViewDetails();
			productDetailsPage.clickOnAddToBasketButton();
			basketPage = productDetailsPage.clickOnCheckOutButton();
			basketPage.enterPurchaseOrderNumber(purchaseOrderNumber);
			basketPage.clickOnOrderTotalText();
			checkOutPage = basketPage.clickOnCheckOutButton();
			checkOutPage.clickOnChange();
			checkOutPage.clickOnAddNewAddressButton();
			checkOutPage.selectCountry(country);
			checkOutPage.enterAddressL1(address1);
			checkOutPage.enterCityTown(town);
			checkOutPage.enterPostCode(postCode);
			checkOutPage.enterContactName(contactName);
			checkOutPage.enterContactPhoneNumber(contactNumber);
			checkOutPage.clickOnUsethisAddress();
			checkOutPage.clickOnUseThesePaymentDetailsButton();
			orderConfirmationPage = checkOutPage.clickOnPlaceOrderButton();
			orderSuccessMessage = orderConfirmationPage.getText("//h1", "Here we are fatching order success message.");
			orderId = orderSuccessMessage.substring(12, 21);
			System.out.println(orderId);
			dashboardPage = orderConfirmationPage.clickOnHomePageLogo();
			dashboardPage.clickUserName();
			homePage = dashboardPage.clickSignOutButton();
			
			backofficeHomePage = applicationSetupBackoffice();
			backofficeDashboardPage = backofficeHomePage.login();
			backofficeDashboardPage.ifErrorMessageExistThenClickOnIt();
			backofficeDashboardPage.enterSearchTermInSearchTreeBox(searchTerm2);
			ordersPage = backofficeDashboardPage.clickOnOrders();
			ordersPage.enterValueInSearchBox(orderId);
			ordersPage.clickOnSearchButton();
			ordersPage.selectOrder();
			ordersPage.clickOnExpandArrowButton();
			ordersPage.clickOnArrowButtonToMoveRight(5);
			
			
			
		} catch(Exception e)
		{
			captureScreenshot(test);
			throw e;
		}catch(Error e)
		{
			captureScreenshot(test);
			throw e;
		}
		
	}
	

}
