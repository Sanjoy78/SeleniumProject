package com.arco.scripts.accountregistration;

import org.testng.annotations.Test;

import com.arco.pages.backoffice.B2BCustomerPage;
import com.arco.pages.backoffice.BackofficeDashboardPage;
import com.arco.pages.backoffice.BackofficeHomePage;
import com.arco.util.ArcoDriverTestCase;

public class ExportRegisteredUserStateReportToCSVFile extends ArcoDriverTestCase
{
	private String test, searchTerm;
	private BackofficeHomePage backofficeHomePage;
	private BackofficeDashboardPage backofficeDashboardPage;
	private B2BCustomerPage b2BCustomerPage;
	
	@Test
	public void exportRegisteredUserStateReportToCSVFile()
	{
		try
		{
			test = propertyReader.getCellData(28, 1);
			searchTerm = propertyReader.getCellData(28, 2);
			backofficeHomePage = applicationSetupBackoffice();
			backofficeDashboardPage = backofficeHomePage.login();
			backofficeDashboardPage.ifErrorMessageExistThenClickOnIt();
			backofficeDashboardPage.enterSearchTermInSearchTreeBox(searchTerm);
			b2BCustomerPage = backofficeDashboardPage.clickOnB2BCustomer();
			b2BCustomerPage.clickOnSwitchSearchMode();
			b2BCustomerPage.clickOnDownArrowForUserState();
			b2BCustomerPage.clickOnVerifiedButton();
			b2BCustomerPage.clickOnSearchButton();
			b2BCustomerPage.scrollWindowToBottomOfPage();
			b2BCustomerPage.clickcsvExportIcon();
		}catch(Exception e)
		{
			
		}catch(Error e)
		{
			
		}
	}

}
