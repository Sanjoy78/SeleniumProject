package com.arco.scripts.accountregistration;

import com.arco.util.ArcoDriverTestCase;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class VerifyAccountUserEnabledToChangeOrgUnit extends ArcoDriverTestCase
{
	
	 private String test, userId, passWord, expectedUserDetails, actualUserDetails,
	    actualOrgUnitBefore, expectedOrgUnitBefore, actualOrgUnitAfter, expectedOrgUnitAfter;
	    private HomePage homePage;
	    private DashboardPage dashboardPage;
	    private SoftAssert softAssert;
	    private PropertyReaderArco propertyReaderArco;
	    
	    

	    @Test
	    public void verifyAccountUserEnabledToChangeOrgUnit() throws Exception
	    {
	        try
	        {
	            propertyReaderArco = new PropertyReaderArco();
	            softAssert = new SoftAssert();
	            test = propertyReaderArco.getCellData(38, 1);
	            userId = propertyReaderArco.getCellData(38, 2);
	            passWord = propertyReaderArco.getCellData(38, 3);
	            expectedUserDetails = propertyReaderArco.getCellData(38, 4);
	            expectedOrgUnitBefore = propertyReaderArco.getCellData(38, 5);
	            expectedOrgUnitAfter = propertyReaderArco.getCellData(38, 6);
	            
	            homePage = applicationSetup();
	            homePage.clickLoginRegister();
	            dashboardPage = homePage.login(userId, passWord);
	            actualUserDetails = dashboardPage.getText("(//strong)[1]", "Here we are featching user details");
	            softAssert.assertEquals(actualUserDetails, expectedUserDetails);
	            actualOrgUnitBefore = dashboardPage.getText("//span[@title = 'header.link.b2b.account']/span", "Here we are featching actual org unit");
	            softAssert.assertEquals(actualOrgUnitBefore, expectedOrgUnitBefore);
	            dashboardPage.clickUserName();
	            dashboardPage.clickOnchangeAccountButton();
	            dashboardPage.enterOrgUnitToBeSearch(expectedOrgUnitAfter);
	            dashboardPage.clickToSelectOrgUnit(expectedOrgUnitAfter);
	            dashboardPage.clickOnDoneAfterAccountChanged();
	            actualOrgUnitAfter = dashboardPage.getText("//span[@title = 'header.link.b2b.account']/span", "Here we are featching actual org unit");
	            softAssert.assertEquals(actualOrgUnitAfter, expectedOrgUnitAfter);
	            dashboardPage.clickUserName();
	            dashboardPage.clickOnchangeAccountButton();
	            dashboardPage.enterOrgUnitToBeSearch(expectedOrgUnitBefore);
	            dashboardPage.clickToSelectOrgUnit(expectedOrgUnitBefore);
	            dashboardPage.clickOnDoneAfterAccountChanged();
	            softAssert.assertAll();
	        
	        }
	        catch (final Error e) {
	            captureScreenshot(test);
	            throw e;
	        } catch (final Exception e) {
	            captureScreenshot(test);
	            throw e;
	        }
	    }

}
