package com.arco.scripts.accountregistration;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.CreatePasswordPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.EnterEmailAddressPage;
import com.arco.pages.storefront.EnterPersonalDetailsPage;
import com.arco.pages.storefront.HaveAccountNumberPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.MyAccountPage;
import com.arco.pages.storefront.RegistrationSuccessPage;
import com.arco.pages.storefront.UserManagementPage;
import com.arco.pages.storefront.VerifyAccountPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class ValidateAccountUserFromStorefrontTest extends ArcoDriverTestCase
{
	private String test, accountID, title, name, surname, phoneno, jobtitle, password, expectedMessage, 
	accountno, customerAdmin, customerAdminPassword, expectedCustomerAdminDetails, expectedUserStatus;
	private HomePage homePage;
	private EnterEmailAddressPage enterEmailAddressPage;
	private HaveAccountNumberPage haveAccountNumberPage;
	private VerifyAccountPage verifyAccountPage;
	private EnterPersonalDetailsPage enterPersonalDetailsPage;
	private CreatePasswordPage createPasswordPage;
	private RegistrationSuccessPage registrationSuccessPage;
	private PropertyReaderArco propertyReaderArco;
	private DashboardPage dashboardPage;
	private MyAccountPage myAccountPage;
	private UserManagementPage userManagementPage;
	
	
	@Test
	public void validationAndDevalidationAccountUserFromStorefront() throws Exception
	{
		try 
		{
			propertyReaderArco = new PropertyReaderArco();
			SoftAssert softassert = new SoftAssert();
			test = propertyReaderArco.getCellData(34, 1);
			accountID = propertyReaderArco.getCellData(34, 2);
			accountno = propertyReaderArco.getCellData(34, 3);
			title = propertyReaderArco.getCellData(34, 4);
			name = propertyReaderArco.getCellData(34, 5);
			surname = propertyReaderArco.getCellData(34, 6);
			phoneno = propertyReaderArco.getCellData(34, 7);
			jobtitle = propertyReaderArco.getCellData(34, 8);
			password = propertyReaderArco.getCellData(34, 9);
			expectedMessage = propertyReaderArco.getCellData(34, 10);
			customerAdmin = propertyReaderArco.getCellData(34, 11);
			customerAdminPassword = propertyReaderArco.getCellData(34, 12);
			expectedCustomerAdminDetails = propertyReaderArco.getCellData(34, 13);
			expectedUserStatus = propertyReaderArco.getCellData(34, 14);
			
			
			
			homePage = applicationSetup();
			homePage.clickOnGotIt();
			homePage.clickLoginRegister();
			enterEmailAddressPage = homePage.clickRegisterNow();
			enterEmailAddressPage.enterEmailID(accountID);
			haveAccountNumberPage = enterEmailAddressPage.clickContinueButton();
			haveAccountNumberPage.selectYesAccount();
			haveAccountNumberPage.enterAccountNumber(accountno);
			verifyAccountPage = haveAccountNumberPage.clickContinueButtonForAccount();
			enterPersonalDetailsPage = verifyAccountPage.clickContinueButton_Acc();
			enterPersonalDetailsPage.selectTitle(title);
			enterPersonalDetailsPage.enterFirstName(name);
			enterPersonalDetailsPage.enterSurName(surname);
			enterPersonalDetailsPage.enterPhoneNumber(phoneno);
			enterPersonalDetailsPage.enterJobTitle(jobtitle);
			enterPersonalDetailsPage.selectTCCheckbox();
			enterPersonalDetailsPage.selectMarketingCheckbox();
			createPasswordPage = enterPersonalDetailsPage.clickContinueButton();
			createPasswordPage.enterPassword(password);
			registrationSuccessPage = createPasswordPage.clickRegisterButton();
			String actualmessage = registrationSuccessPage.getText("//h1", "We are retrieving registration success message");
			softassert.assertEquals(actualmessage, expectedMessage);
			homePage = registrationSuccessPage.clickOnHomePageLogo();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(customerAdmin, customerAdminPassword);
			dashboardPage.clickUserName();
	        String actualUserDetails = dashboardPage.getText("(//strong)[1]", "Here we are featching user details");
			softassert.assertEquals(actualUserDetails, expectedCustomerAdminDetails);
			myAccountPage = dashboardPage.clickAccountOverview();
			userManagementPage = myAccountPage.clickOnUserManagementLink();
			userManagementPage.enterUserDetailsInSearchBox(accountID);
			String actualUserStatus = userManagementPage.getText("//span[@id='userStatus"+accountID+"']", "Here we are featching user details");
			softassert.assertEquals(actualUserStatus, expectedUserStatus);
			userManagementPage.clickOndotButtonForUser(accountID);
			userManagementPage.clickOnAuthoriseToPurchaseButton(accountID);
			softassert.assertFalse(userManagementPage.isUserStatusIndicator(accountID));
            userManagementPage.clickOndotButtonForUser(accountID);
            userManagementPage.clickOnDeauthoriseToPurchaseButton(accountID);
            softassert.assertFalse(userManagementPage.isUserStatusIndicator(accountID));
            softassert.assertAll();
			} 
		catch (final Error e) {
			captureScreenshot(test);
			throw e;
		} catch (final Exception e) {
			captureScreenshot(test);
			throw e;
		}
	}

}
