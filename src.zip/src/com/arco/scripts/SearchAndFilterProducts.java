package com.arco.scripts;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.CategoryListPage;
import com.arco.pages.storefront.HomePage;
import com.arco.util.ArcoDriverTestCase;


public class SearchAndFilterProducts extends ArcoDriverTestCase
{
	
	private String test, productID, catagoryName;
	private HomePage homePage;
	private CategoryListPage categoryListPage;
	private SoftAssert softAssert;
	
	@Test
	public void createUserAsArcoAdmin() throws Exception
	{
		try
		{
			test = propertyReader.getCellData(47, 1);
			productID = propertyReader.getCellData(47, 2);
			catagoryName = propertyReader.getCellData(47, 3);
			softAssert = new SoftAssert();
			homePage = applicationSetup();
			homePage.enterProductCodeInSearchBox(productID);
			categoryListPage = homePage.clickOnFindButton();
			String expectedText = categoryListPage.getText("//h1", "Here we are getting text for product code verification");
			softAssert.assertEquals(expectedText, productID);
			String productCount = categoryListPage.getText("(//span[text()='"+catagoryName+"'])[1]/following::span[1]", "We are fatching number of products for specific catagory");
			String intValueOfProductCount = productCount.substring(1, 2);
			categoryListPage.clickOnACategory(catagoryName);
			String productCountAfterSelectCatagory = categoryListPage.getText("//p[@id='paragraphBold']", "We are fatching number of products for specific catagory");
			String intValueOfProductCountAfterSelectCatagory = productCountAfterSelectCatagory.substring(0, 1);
			softAssert.assertEquals(intValueOfProductCount, intValueOfProductCountAfterSelectCatagory);
			softAssert.assertAll();
			
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
		
	}

}
