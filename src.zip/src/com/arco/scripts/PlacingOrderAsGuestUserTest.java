package com.arco.scripts;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.BasketPage;

import com.arco.pages.storefront.CheckOutCardPaymentPage;
import com.arco.pages.storefront.CheckOutPage;
import com.arco.pages.storefront.EmailConfirmationPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.OrderConfirmationPage;
import com.arco.pages.storefront.ProductDetailsPage;

import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;


public class PlacingOrderAsGuestUserTest extends ArcoDriverTestCase
{
	private String test, anonymousUserId, productCodeOrText, town, postcode, purchaseOrderNumber, skuID, numberOfItem, 
	expectedMessage, addressLine1, contactName, contactNumber, country, cardNumber, securityCode, month, year; 
    private HomePage homePage;
  
	private ProductDetailsPage productDetailsPage;
	private BasketPage basketPage;
	private CheckOutPage checkOutPage;
	private OrderConfirmationPage orderConfirmationPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;
	private EmailConfirmationPage emailConfirmationPage;
	private CheckOutCardPaymentPage checkOutCardPaymentPage;
	
    
    @Test
	public void placingOrderForAnonymousUser() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(25, 1);
			productCodeOrText = propertyReaderArco.getCellData(25, 2);
			numberOfItem =propertyReaderArco.getCellData(25, 3);
			skuID = propertyReaderArco.getCellData(25, 4);
			anonymousUserId = propertyReaderArco.getCellData(25, 5);
			addressLine1 = propertyReaderArco.getCellData(25, 6);
			contactName = propertyReaderArco.getCellData(25, 7);
			contactNumber = propertyReaderArco.getCellData(25, 8);
			country = propertyReaderArco.getCellData(25, 9);
			cardNumber = propertyReaderArco.getCellData(25, 10);
		    securityCode = propertyReaderArco.getCellData(25, 11);
		    month = propertyReaderArco.getCellData(25, 12);
		    year = propertyReaderArco.getCellData(25, 13);
		    expectedMessage = propertyReaderArco.getCellData(25, 14);
		    
			purchaseOrderNumber = propertyReaderArco.getCellData(25, 16);
			town = propertyReaderArco.getCellData(25, 17);
			postcode = propertyReaderArco.getCellData(25, 18);
			
		    
			
		    
			homePage = applicationSetup();
			homePage.enterProductCodeInSearchBox(productCodeOrText);
			productDetailsPage = homePage.clickOnFindButtonToNavigatePDP();
			//productDetailsPage = categoryListPage.clickOnAProduct(baseProductCode);
			productDetailsPage.enterQTYForSKU(skuID, numberOfItem);
			productDetailsPage.clickOnViewDetails();
			productDetailsPage.clickOnAddToBasketButton();
			basketPage = productDetailsPage.clickOnCheckOutButton();
			//basketPage.enterPurchaseOrderNumber(purchaseOrderNumber);
			//basketPage.clickOnOrderTotalText();
			emailConfirmationPage = basketPage.clickOnCheckOutButtonforAnonymousUser();
			emailConfirmationPage.enterguestEmailIdinemailBox(anonymousUserId);
			emailConfirmationPage.enterguestEmailIdinconfirmemailbox(anonymousUserId);
			checkOutPage = emailConfirmationPage.clickOnCheckoutAsaGuestButton();
			checkOutPage.selectCountry(country);
			//checkOutPage.enteraddressinaddressbox(address);
			checkOutPage.enterAddressL1(addressLine1);
			checkOutPage.enterCityTown(town);
			checkOutPage.enterPostCode(postcode);
			checkOutPage.enterContactName(contactName);
			checkOutPage.enterContactPhoneNumber(contactNumber);
			checkOutPage.clickOnUsethisAddress();
			checkOutPage.clickOnUseTheseDeliveryDetailsButton();
			checkOutPage.clickOnUseThesePaymentDetailsButton();
			checkOutPage.clickOnCheckBoxForTC();
			
			checkOutCardPaymentPage = checkOutPage.clickOnPlaceOrderButtonforAnonymous();
			
			checkOutCardPaymentPage.switchToiFrame();
	        checkOutCardPaymentPage.enterCardNumber(cardNumber);
	        
	        checkOutCardPaymentPage.selectMonthlist(month);
	        checkOutCardPaymentPage.selectYearlist(year);
	        checkOutCardPaymentPage.enterSecurityCode(securityCode);
	        orderConfirmationPage = checkOutCardPaymentPage.clickOnSelectPayByCard();
	        checkOutCardPaymentPage.switchToDefaultFrame();
			String successMessage = orderConfirmationPage.getText("//a[text() = 'Register']", "Here we are retreiving success message for verification");
			softAssert.assertEquals(successMessage, expectedMessage);
			softAssert.assertAll();
			
			
			} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
