package com.arco.scripts.productaccesscontrollist;

import com.arco.util.ArcoDriverTestCase;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.MyAccountPage;
import com.arco.pages.storefront.ProductAccessControlPage;
import com.arco.util.PropertyReaderArco;

public class CreateEditDeletePACListTest extends ArcoDriverTestCase
{
	
	private String test, userId, passWord, actualUserDetails, expectedUserDetails, pacName, context, actualPACListName;
    private HomePage homePage;
    private DashboardPage dashboardPage;
    private MyAccountPage myAccountPage;
    private ProductAccessControlPage productAccessControlPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;
    
    
    @Test
    public void createEditDeletePACListTest() throws Exception
    {
        try
        {
            propertyReaderArco = new PropertyReaderArco();
            softAssert = new SoftAssert();
            test = propertyReaderArco.getCellData(52, 1);
            userId = propertyReaderArco.getCellData(52, 2);
            passWord = propertyReaderArco.getCellData(52, 3);
            expectedUserDetails = propertyReaderArco.getCellData(52, 4);
            pacName = propertyReaderArco.getCellData(52, 5);
            context = propertyReaderArco.getCellData(52, 6);
            
            
            homePage = applicationSetup();
            homePage.clickLoginRegister();
            dashboardPage = homePage.login(userId, passWord);
            actualUserDetails = dashboardPage.getText("(//strong)[1]", "Here we are featching user details");
            softAssert.assertEquals(actualUserDetails, expectedUserDetails);
            dashboardPage.clickUserName();
            myAccountPage = dashboardPage.clickAccountOverview();
            productAccessControlPage = myAccountPage.clickOnManageProductAccessControlButton();
            productAccessControlPage.clickOnCreateListButton();
            productAccessControlPage.enterProductAccessControlListName(pacName);
            productAccessControlPage.selectProductAccessControlListContext(context);
            productAccessControlPage.clickDoneButtonForProductAccessControlListCreation();
            productAccessControlPage.clickDoneButtonAfterProductAccessControlList();
            productAccessControlPage.searchProductAccessControlListByName(pacName);
            softAssert.assertTrue(productAccessControlPage.isPACListPresent(pacName));
            actualPACListName = dashboardPage.getText("//span[@class='pacListName']", "Here we are featching PAC list name" );
            softAssert.assertEquals(actualPACListName, pacName);
            productAccessControlPage.clickOnDotsOfProductAccessControlList(pacName);
            productAccessControlPage.clickOnDeleteButtonForProductAccessControlList(pacName);
            productAccessControlPage.clickOnYesButtonForPACDeletation();
            productAccessControlPage.clickOnDoneButtonAfterPACDeletation();
            productAccessControlPage.searchProductAccessControlListByName(pacName);
            softAssert.assertFalse(productAccessControlPage.isPACListPresent(pacName));
            softAssert.assertAll();
        }
        catch (final Error e) {
            captureScreenshot(test);
            throw e;
        } catch (final Exception e) {
            captureScreenshot(test);
            throw e;
        }
    }

}
