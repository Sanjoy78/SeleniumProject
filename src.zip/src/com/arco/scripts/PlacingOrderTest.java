package com.arco.scripts;


import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.BasketPage;
import com.arco.pages.storefront.CheckOutPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.OrderConfirmationPage;
import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;


public class PlacingOrderTest extends ArcoDriverTestCase
{
	
	private String test, userId, passWord, productCode, sku, numberOfItem, expectedMessage, purchaseOrderNumber, country,addressLine1,town, postcode, contactName, contactNumber;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	
	private ProductDetailsPage productDetailsPage;
	private BasketPage basketPage;
	private CheckOutPage checkOutPage;
	private OrderConfirmationPage orderConfirmationPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;

	
	@Test
	public void placingOrderForRegisteredUser() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(15, 1);
			userId = propertyReaderArco.getCellData(2, 2);
			passWord = propertyReaderArco.getCellData(2, 9);
			productCode = propertyReaderArco.getCellData(15, 4);
			sku =propertyReaderArco.getCellData(15, 5);
			numberOfItem =propertyReaderArco.getCellData(15, 6);
			expectedMessage = propertyReaderArco.getCellData(15, 7);
			purchaseOrderNumber = propertyReaderArco.getCellData(15, 8);
			country = propertyReaderArco.getCellData(15, 9);
			addressLine1 = propertyReaderArco.getCellData(15, 10);
			town = propertyReaderArco.getCellData(15, 11);
			postcode = propertyReaderArco.getCellData(15, 12);
			contactName = propertyReaderArco.getCellData(15, 13);
			contactNumber = propertyReaderArco.getCellData(15, 14);
			
			homePage = applicationSetup();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(userId, passWord);
			//dashboardPage.clickOnGotIt();
			dashboardPage.IfGotItElementPresentThenClickOnIt();
			dashboardPage.enterProductNameOrCode(productCode);
			productDetailsPage = dashboardPage.clickOnFindButtonToNavigatePDP();
			//productDetailsPage = categoryListPage.clickOnAProduct(productCode);;
			productDetailsPage.enterQTYForSKU(sku, numberOfItem);
			productDetailsPage.clickOnViewDetails();
			productDetailsPage.clickOnAddToBasketButton();
			basketPage = productDetailsPage.clickOnCheckOutButton();
			//basketPage.enterPurchaseOrderNumber(purchaseOrderNumber);
			//basketPage.clickOnOrderTotalText();
			checkOutPage = basketPage.clickOnCheckOutButton();
			checkOutPage.selectCountry(country);
			//checkOutPage.enteraddressinaddressbox(address);
			checkOutPage.enterAddressL1(addressLine1);
			checkOutPage.enterCityTown(town);
			checkOutPage.enterPostCode(postcode);
			checkOutPage.enterContactName(contactName);
			checkOutPage.enterContactPhoneNumber(contactNumber);
			checkOutPage.clickOnUsethisAddress();
			checkOutPage.clickOnUseTheseDeliveryDetailsButton();
			checkOutPage.clickOnUseThesePaymentDetailsButton();
			
			orderConfirmationPage = checkOutPage.clickOnPlaceOrderButton();
			
			String successMessage = orderConfirmationPage.getText("//p[@class='light-grey']", "Here we are retreving seccess message for verification");
			softAssert.assertEquals(successMessage, expectedMessage);
			softAssert.assertAll();
			
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}
	
}
