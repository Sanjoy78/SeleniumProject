package com.arco.scripts;


import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.PurchaseListPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;


public class CreateEditDeletePurchaseListTest extends ArcoDriverTestCase
{
	private String test, userName, passWord, personalPurchaseListName, accountPurchaseListName, updatedPersonalPurchaseListName, updatedAccountPurchaseListName;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private PurchaseListPage purchaseListPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void createEditDeleteAccountAndPersonalPurchaseList() throws Exception
	{

		try
		{
			propertyReaderArco = new PropertyReaderArco();
			softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(8, 1);
			userName = propertyReaderArco.getCellData(8, 2);
			passWord = propertyReaderArco.getCellData(8, 3);
			
			personalPurchaseListName = propertyReaderArco.getCellData(8, 5);
			accountPurchaseListName = propertyReaderArco.getCellData(8, 6);
			updatedPersonalPurchaseListName = propertyReaderArco.getCellData(8, 7);
			updatedAccountPurchaseListName = propertyReaderArco.getCellData(8, 8);
			
			homePage = applicationSetup();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(userName, passWord);
			purchaseListPage = dashboardPage.clickPurchaseListLink();
			purchaseListPage.clickCreateListButton();
			purchaseListPage.enterPurchaseListName(personalPurchaseListName);
			purchaseListPage.selectPersonalPurchaseListType();
			purchaseListPage.clickDoneButtonForPurchaseListCreation();
			purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
			purchaseListPage.searchPurchaseListByName(personalPurchaseListName);
			softAssert.assertTrue(purchaseListPage.verifyPLNotExist(personalPurchaseListName));
			purchaseListPage.clickCreateListButton();
			purchaseListPage.enterPurchaseListName(accountPurchaseListName);
			purchaseListPage.selectAccountPurchaseListType();
			purchaseListPage.clickDoneButtonForPurchaseListCreation();
			purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
			purchaseListPage.searchPurchaseListByName(accountPurchaseListName);
			softAssert.assertTrue(purchaseListPage.verifyPLNotExist(accountPurchaseListName));
			purchaseListPage.searchPurchaseListByName(personalPurchaseListName);
			purchaseListPage.clickOnDotsOfPersonalPurchaseList();
			purchaseListPage.clickOnEditButtonForPersonalPurchaseList();
			purchaseListPage.enterPurchaseListName(updatedPersonalPurchaseListName);
			purchaseListPage.clickDoneButtonForPurchaseListCreation();
			purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
			purchaseListPage.searchPurchaseListByName(accountPurchaseListName);
			purchaseListPage.clickOnDotsOfAccoutPurchaseList();
			purchaseListPage.clickOnEditButtonForAccountPurchaseList();
			purchaseListPage.enterPurchaseListName(updatedAccountPurchaseListName);
			purchaseListPage.clickDoneButtonForPurchaseListCreation();
			purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
			purchaseListPage.searchPurchaseListByName(updatedPersonalPurchaseListName);
			purchaseListPage.clickOnDotsOfPersonalPurchaseList();
			purchaseListPage.clickOnDeleteButtonForPersonalPurchaseList();
			purchaseListPage.clickOnYesButtonForPLDetetation();
			purchaseListPage.clickOnDoneButtonAfterPLDeletation();
			purchaseListPage.searchPurchaseListByName(updatedAccountPurchaseListName);
			purchaseListPage.clickOnDotsOfPersonalPurchaseList();
			purchaseListPage.clickOnDeleteButtonForPersonalPurchaseList();
			purchaseListPage.clickOnYesButtonForPLDetetation();
			purchaseListPage.clickOnDoneButtonAfterPLDeletation();
			
			
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
