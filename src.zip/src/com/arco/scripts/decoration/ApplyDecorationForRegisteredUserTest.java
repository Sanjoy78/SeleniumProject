package com.arco.scripts.decoration;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.BasketPage;
import com.arco.pages.storefront.CheckOutPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class ApplyDecorationForRegisteredUserTest extends ArcoDriverTestCase
{
	
	private String test, userId, passWord, numberOfItem, actualDecorationAppliedMessage, expectedDecorationAppliedMessage, fontSize, colour, baseProductCode, fontStyle, skuID, position, textData;
    private HomePage homePage;
    private DashboardPage dashboardPage;
    private ProductDetailsPage productDetailsPage;
    private BasketPage basketPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;    
    
    @Test
    public void applyDecorationForRegisteredUserTest() throws Exception
    {
        try
        {
            propertyReaderArco = new PropertyReaderArco();
            softAssert = new SoftAssert();
            test = propertyReaderArco.getCellData(51, 1);
            userId = propertyReaderArco.getCellData(51, 2);
            passWord = propertyReaderArco.getCellData(51, 3);
            baseProductCode = propertyReaderArco.getCellData(51, 4);
            skuID = propertyReaderArco.getCellData(51, 5);
            numberOfItem =propertyReaderArco.getCellData(51, 6);
            textData = propertyReaderArco.getCellData(51, 7);
            expectedDecorationAppliedMessage = propertyReaderArco.getCellData(51, 8);
            position = propertyReaderArco.getCellData(51, 9);
            fontStyle = propertyReaderArco.getCellData(51, 10);
            fontSize = propertyReaderArco.getCellData(51, 11);
            colour = propertyReaderArco.getCellData(51, 12);
            
            homePage = applicationSetup();
            homePage.clickLoginRegister();
            dashboardPage = homePage.login(userId, passWord);
            dashboardPage.enterProductNameOrCode(baseProductCode);
            productDetailsPage = dashboardPage.clickOnFindButtonToNavigatePDP();
            productDetailsPage.enterQTYForSKU(skuID, numberOfItem);
            productDetailsPage.clickOnViewDetails();
            productDetailsPage.clickOnAddToBasketButton();
            basketPage = productDetailsPage.clickOnCheckOutButton();
            basketPage.clickOnApplyDecorationLink(skuID);
            basketPage.clickOnSelectPositionButton();
            basketPage.selectPosition(position);
            basketPage.clickOnSelectDecorationStyleButton();
            basketPage.clickOnEmbroideryTextRadioButton();
            basketPage.clickToSelectFontStyleFromDropdownList(fontStyle);
            basketPage.clickToSelectFontSizeFromDropdownList(fontSize);
            basketPage.clickToSelectColorButton();
            basketPage.selectColour(colour);
            basketPage.enterText(textData);
            basketPage.clickOnSaveAfterDecoration(skuID);
            basketPage.clickOnDoneAfterDecoration();
            actualDecorationAppliedMessage = (String) dashboardPage.getText("//a[@id='decorationLink-"+skuID+"']", "Here we are featching actual decoration applied message").subSequence(0, 41);
            basketPage.clickOnRemoveButtonForASKU(skuID);
            softAssert.assertEquals(actualDecorationAppliedMessage, expectedDecorationAppliedMessage);
            softAssert.assertAll();
            
        } catch (Error e)
        {
            captureScreenshot(test);
            throw e;
        } catch (Exception e)
        {
            captureScreenshot(test);
            throw e;
        }
    }

}
