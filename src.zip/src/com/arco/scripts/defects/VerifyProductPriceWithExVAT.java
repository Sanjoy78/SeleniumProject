package com.arco.scripts.defects;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.CategoryListPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class VerifyProductPriceWithExVAT extends ArcoDriverTestCase
{
	private String test, userId, passWord, productCode, sku, expectedText, productName;
    private HomePage homePage;
    private DashboardPage dashboardPage;
    private CategoryListPage categoryListPage;
    private ProductDetailsPage productDetailsPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;

    @Test
    public void verifyProductPriceWithExVat() throws Exception
    {
        try
        {
            propertyReaderArco = new PropertyReaderArco();
            softAssert = new SoftAssert();
            test = propertyReaderArco.getCellData(49, 1);
            userId = propertyReaderArco.getCellData(49, 2);
            passWord = propertyReaderArco.getCellData(49, 3);
            productName = propertyReaderArco.getCellData(49, 4);
            productCode=propertyReaderArco.getCellData(49, 5);
            expectedText=propertyReaderArco.getCellData(49, 6);
            
            homePage = applicationSetup();
            homePage.clickLoginRegister();
            dashboardPage = homePage.login(userId, passWord);
            dashboardPage.enterProductNameOrCode(productName);
            categoryListPage = dashboardPage.clickOnFindButton();
            productDetailsPage=categoryListPage.clickOnAProduct(productCode);
            String actualText = productDetailsPage.getText("//span[.='(Ex.VAT)']", "Here we are retreving text for verification");
            softAssert.assertEquals(actualText, expectedText);
            
        } catch (Error e)
        {
            captureScreenshot(test);
            throw e;
        } catch (Exception e)
        {
            captureScreenshot(test);
            throw e;
        }
    }
	

}
