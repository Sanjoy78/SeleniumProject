package com.arco.scripts.defects;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.BasketPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.util.ArcoDriverTestCase;

public class VerifyDecorationPositionBehavierAsGuestUserTest extends ArcoDriverTestCase
{
	
	private String test, productCodeOrText, skuID, numberOfItem, fontSize, colour, fontStyle, position, textData, position1, actualText;
	private HomePage homePage;
	private ProductDetailsPage productDetailsPage;
    private BasketPage basketPage;
    private SoftAssert softAssert;
    
    
    @Test
    public void verifyDecorationPositionBehavierAsGuestUserTest() throws Exception
    {
    	try
    	{
    		softAssert = new SoftAssert();
    		test = propertyReader.getCellData(57, 1);
    		productCodeOrText = propertyReader.getCellData(57, 2);
    		skuID = propertyReader.getCellData(57, 3);
    		numberOfItem = propertyReader.getCellData(57, 4);
    		fontSize = propertyReader.getCellData(57, 5);
    		colour = propertyReader.getCellData(57, 6);
    		fontStyle = propertyReader.getCellData(57, 7);
    		position = propertyReader.getCellData(57, 8);
    		textData = propertyReader.getCellData(57, 9);
    		position1 = propertyReader.getCellData(57, 10);
    		
    		homePage = applicationSetup();
    		homePage.enterProductCodeInSearchBox(productCodeOrText);
    		productDetailsPage = homePage.clickOnFindButtonToNavigatePDP();
    		productDetailsPage.enterQTYForSKU(skuID, numberOfItem);
    		productDetailsPage.clickOnViewDetails();
            productDetailsPage.clickOnAddToBasketButton();
            basketPage = productDetailsPage.clickOnCheckOutButton();
            basketPage.clickOnApplyDecorationLink(skuID);
            basketPage.clickOnSelectPositionButton();
            basketPage.selectPosition(position);
            softAssert.assertFalse(basketPage.isSaveButtonEnable());
            basketPage.clickOnSelectDecorationStyleButton();
            basketPage.clickOnEmbroideryTextRadioButton();
            basketPage.clickToSelectFontStyleFromDropdownList(fontStyle);
            basketPage.clickToSelectFontSizeFromDropdownList(fontSize);
            basketPage.clickToSelectColorButton();
            basketPage.selectColour(colour);
            basketPage.enterText(textData);
            basketPage.clickOnSelectPositionButton();
            basketPage.selectPosition(position1);
            actualText = basketPage.getAttribute("//input[@id='previewText']", "value", "We are fetching entered text for verification.");
            softAssert.assertEquals(textData, actualText);
            softAssert.assertAll();
    		
    	} catch(Error e)
    	{
    		captureScreenshot(test);
    		throw e;
    	} catch(Exception e)
    	{
    		captureScreenshot(test);
    		throw e;
    	}
    }
    
	

}
