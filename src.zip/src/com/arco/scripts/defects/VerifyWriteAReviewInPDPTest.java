package com.arco.scripts.defects;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class VerifyWriteAReviewInPDPTest extends ArcoDriverTestCase
{
	private String test, userId, passWord, baseProductCode, reviewTitle, reviewDescription, actualReviewConfirmationMessage,
    expectedReviewConfirmationMessage;
    private HomePage homePage;
    private DashboardPage dashboardPage;
    private ProductDetailsPage productDetailsPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;    
    
    @Test
    public void verifyWriteAReviewInPDPTest() throws Exception
    {
        try
        {
            propertyReaderArco = new PropertyReaderArco();
            softAssert = new SoftAssert();
            test = propertyReaderArco.getCellData(55, 1);
            userId = propertyReaderArco.getCellData(55, 2);
            passWord = propertyReaderArco.getCellData(55, 3);
            baseProductCode = propertyReaderArco.getCellData(55, 4);
            reviewTitle = propertyReaderArco.getCellData(55, 5);
            reviewDescription = propertyReaderArco.getCellData(55, 6);
            expectedReviewConfirmationMessage = propertyReaderArco.getCellData(55, 7);
    
            
            homePage = applicationSetup();
            homePage.clickLoginRegister();
            dashboardPage = homePage.login(userId, passWord);
            dashboardPage.enterProductNameOrCode(baseProductCode);
            productDetailsPage = dashboardPage.clickOnFindButtonToNavigatePDP();
            productDetailsPage.clickOnWriteAReviewButton();
            productDetailsPage.enterReviewTitle(reviewTitle);
            productDetailsPage.enterReviewDescription(reviewDescription);
            productDetailsPage.selectRating();
            productDetailsPage.clickOnSubmitReviewButton();
            actualReviewConfirmationMessage = dashboardPage.getText("//div[@class='alert alert-success alert-dismissible top-space']", "Here we are featching actual review confirmation message");
            softAssert.assertEquals(actualReviewConfirmationMessage, expectedReviewConfirmationMessage);
            softAssert.assertAll();
            
        } catch (Error e)
        {
            captureScreenshot(test);
            throw e;
        } catch (Exception e)
        {
            captureScreenshot(test);
            throw e;
        }
    }

}
