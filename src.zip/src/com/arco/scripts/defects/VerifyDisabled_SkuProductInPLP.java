package com.arco.scripts.defects;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.CategoryListPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class VerifyDisabled_SkuProductInPLP extends ArcoDriverTestCase
{
	
	private String test, userName, passWord, expectedUserName,productName,productCode,skuCode, expectedSkuType,skuActivecode,skuDisablecode;
    private SoftAssert softAssert;
    private HomePage homePage;
    private DashboardPage dashboardPage;
    private PropertyReaderArco propertyReaderArco;
    private CategoryListPage categoryListPage;
    
    @Test
    public void VerifyDisable_SkuProductinPLP() throws Exception
    {
        try
        {
            propertyReaderArco = new PropertyReaderArco();
            test = propertyReaderArco.getCellData(53, 1);
            userName = propertyReaderArco.getCellData(53, 2);
            passWord = propertyReaderArco.getCellData(53, 3);
            expectedUserName = propertyReaderArco.getCellData(53, 4);
            productName = propertyReaderArco.getCellData(53, 5);
            skuActivecode=propertyReaderArco.getCellData(53,7 );
            skuDisablecode=propertyReaderArco.getCellData(53, 8);
            
            
            softAssert = new SoftAssert();
            homePage = applicationSetup();
            homePage.clickOnGotIt();
            homePage.clickLoginRegister();
            dashboardPage = homePage.login(userName, passWord);
            
            String actualLoginUserName = dashboardPage.getText("(//strong)[1]", "We are getting Login User Name for verification.");
            softAssert.assertEquals(actualLoginUserName, expectedUserName);
            dashboardPage.enterProductNameOrCode(productName);
            categoryListPage= dashboardPage.clickOnFindButton();
            String actualPLPTitle=categoryListPage.getText("//h1", "We are getting product Name for verification.");
            softAssert.assertEquals(actualPLPTitle, productName);
            
            categoryListPage.clickOnBuyNowButtonForABaseProduct(productName);
            softAssert.assertTrue(categoryListPage.isSkuActive(skuActivecode));
            softAssert.assertFalse(categoryListPage.isSkuActive(skuDisablecode));

            softAssert.assertAll();
            
            
        
            
            
            
            
            
            
        } catch (final Error e)
        {
            captureScreenshot(test);
            throw e;
        } catch (final Exception e)
        {
            captureScreenshot(test);
            throw e;
        }
    }

}
