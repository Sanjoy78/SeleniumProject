package com.arco.scripts.defects;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.CategoryListPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.MyAccountPage;
import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.pages.storefront.PurchaseListPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class VerifiStockAvailabilityForSameProduct extends ArcoDriverTestCase
{
	
	private String test, userId, passWord, baseProductCode, nameOrCode, purchaseListName, productId;
    private HomePage homePage;
    private DashboardPage dashboardPage;
    private CategoryListPage categoryListPage;
    private ProductDetailsPage productDetailsPage;
    private MyAccountPage myAccountPage;
    private PurchaseListPage purchaseListPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;
    
    @Test
    public void verifyPDPAndPLAvailabilityForSameStockIndicator() throws Exception
    {
        try
        {
            propertyReaderArco = new PropertyReaderArco();
            softAssert = new SoftAssert();
            test = propertyReaderArco.getCellData(36, 1);
            userId = propertyReaderArco.getCellData(36, 2);
            passWord = propertyReaderArco.getCellData(36, 3);
            nameOrCode=propertyReaderArco.getCellData(36, 4);
            purchaseListName=propertyReaderArco.getCellData(36, 5);
            productId=propertyReaderArco.getCellData(36, 6);
            baseProductCode = propertyReaderArco.getCellData(36, 7);
            
            /*
            homePage = applicationSetup();
            homePage.clickLoginRegister();
            dashboardPage = homePage.login(userId, passWord);
            dashboardPage.enterProductNameOrCode(nameOrCode);
            categoryListPage=dashboardPage.clickOnFindButton();
            categoryListPage.clickOnAddToList();
            categoryListPage.clickOnAddToPurchaseList();
            categoryListPage.enterSearchPurchaseList(purchaseListName);
            categoryListPage.clickOnPurchaseListCheckBox();
            categoryListPage.clickOnSelectProductButton();
            categoryListPage.clickOnSelectProductCheckBox(productId);
            categoryListPage.clickOnAddtoPurchaseListButton();
            categoryListPage.clickOnDoneButtonforAddProductInPL();
            categoryListPage.clickUser();
            myAccountPage= categoryListPage.clickAccountOverview();
            purchaseListPage=myAccountPage.clickOnManagePLLink();
            purchaseListPage.searchPurchaseListByName(purchaseListName);
            purchaseListPage.clickOnDotsOfAccoutPurchaseList();
            purchaseListPage.clickOnViewButton();
            purchaseListPage.clickOnListButton();
            String actualStockPLP = purchaseListPage.getText("(//div[@data-skureferencecode='"+productId+"'][1]//following::div[@class='sku-badges purchaseListBadges']/span)[3]", "Here we are fetching the stock availability");
            System.out.println("Actual Stock PLP is " + actualStockPLP);
            purchaseListPage.enterProductNameOrCode(baseProductCode);
            productDetailsPage=purchaseListPage.clickOnFindButton();
            String actualStockPDP = productDetailsPage.getText("(//div[@data-skureferencecode='"+productId+"']//following::div[@class='sku-badges fitlerBadges']/span)[2]", "Here we are fetching the stock availability");
            System.out.println("Actual Stock PDP " + actualStockPDP);
            softAssert.assertEquals(actualStockPLP, actualStockPDP);
            softAssert.assertAll();
            */
     } catch (Error e)
    {
        captureScreenshot(test);
        throw e;
    } catch (Exception e)
    {
        captureScreenshot(test);
        throw e;
    }

}
}
