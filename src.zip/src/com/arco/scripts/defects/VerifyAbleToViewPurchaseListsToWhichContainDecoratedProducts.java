package com.arco.scripts.defects;

import com.arco.util.ArcoDriverTestCase;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.pages.storefront.PurchaseListPage;
import com.arco.util.PropertyReaderArco;

public class VerifyAbleToViewPurchaseListsToWhichContainDecoratedProducts extends ArcoDriverTestCase
{
	
	private String test, userId, passWord, baseProductCode, purchaseList, skuId;
    private HomePage homePage;
    private DashboardPage dashboardPage;
    private ProductDetailsPage productDetailsPage;
    private PurchaseListPage purchaseListPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;    
    
    @Test
    public void verifyAbleToViewPurchaseListsToWhichContainDecoratedProducts() throws Exception
    {
        try
        {
            propertyReaderArco = new PropertyReaderArco();
            softAssert = new SoftAssert();
            test = propertyReaderArco.getCellData(56, 1);
            userId = propertyReaderArco.getCellData(56, 2);
            passWord = propertyReaderArco.getCellData(56, 3);
            baseProductCode = propertyReaderArco.getCellData(56, 4);
            purchaseList = propertyReaderArco.getCellData(56, 5);
            skuId = propertyReaderArco.getCellData(56, 6);
            
    
            
            homePage = applicationSetup();
            homePage.clickLoginRegister();
            dashboardPage = homePage.login(userId, passWord);
            dashboardPage.clickOnGotIt();
            dashboardPage.enterProductNameOrCode(baseProductCode);
            productDetailsPage = dashboardPage.clickOnFindButtonToNavigatePDP();
            productDetailsPage.clickOnAddToListButton();
            productDetailsPage.selectPurchaseListButton();
            productDetailsPage.enterPurchaseListsToSearch(purchaseList);
            productDetailsPage.selectPurchaseListAfterSearch(purchaseList);
            productDetailsPage.clickOnSelectProducts();
            productDetailsPage.selectProductCheckbox(skuId);
            productDetailsPage.clickOnAddToPurchaseListButton();
            productDetailsPage.clickOnDoneButtonAfterProductAdd();
            purchaseListPage = productDetailsPage.clickPurchaseListLink();
            purchaseListPage.enterPurchaseListName(purchaseList);
            purchaseListPage.clickOnDotForAPL(purchaseList);
            purchaseListPage.clickOnViewForAPL(purchaseList);
            softAssert.assertTrue(purchaseListPage.isDecoratedProductPresent(skuId));
            purchaseListPage.clickOnRemoveSKUFromPurchaseList(skuId);
            purchaseListPage.clickOnDoneButtonAfterRemoveSKU();
            softAssert.assertFalse(purchaseListPage.isDecoratedProductPresent(skuId));
            softAssert.assertAll();
            
        } catch (Error e)
        {
            captureScreenshot(test);
            throw e;
        } catch (Exception e)
        {
            captureScreenshot(test);
            throw e;
        }
    }

}
