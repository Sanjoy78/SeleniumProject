package com.arco.scripts;


import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


import com.arco.pages.backoffice.B2BCustomerPage;
import com.arco.pages.backoffice.BackofficeDashboardPage;
import com.arco.pages.backoffice.BackofficeHomePage;
import com.arco.pages.storefront.CreatePasswordPage;

import com.arco.pages.storefront.EnterEmailAddressPage;
import com.arco.pages.storefront.EnterPersonalDetailsPage;
import com.arco.pages.storefront.HaveAccountNumberPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.RegistrationSuccessPage;
import com.arco.pages.storefront.VerifyAccountPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;


public class RegistrationTest extends ArcoDriverTestCase
{
	private String test, emailID, title, name, surname, phoneno, jobtitle, password, expectedmessage, accountno, expectedLastName, expectedUserStateBefore;
	//private PropertyReaderArco propertyReaderArco;
	private HomePage homePage;
	private EnterEmailAddressPage enterEmailAddressPage;
	private HaveAccountNumberPage haveAccountNumberPage;
	private VerifyAccountPage verifyAccountPage;
	private EnterPersonalDetailsPage enterPersonalDetailsPage;
	private CreatePasswordPage createPasswordPage;
	private RegistrationSuccessPage registrationSuccessPage;
	private PropertyReaderArco propertyReaderArco;
	
	private String searchTerm = "B2B Customer";
	private BackofficeHomePage backofficeHomePage;
	private BackofficeDashboardPage backofficeDashboardPage;
	private B2BCustomerPage b2BCustomerPage;
	
	
	@Test(enabled=false)
	public void registrationAsCashUser() throws Exception
	{
		try
		{
		propertyReaderArco = new PropertyReaderArco();
		SoftAssert softassert = new SoftAssert();
		test = propertyReaderArco.getCellData(1, 1);
		emailID = propertyReaderArco.getCellData(1, 2);
		title = propertyReaderArco.getCellData(1, 3);
		name = propertyReaderArco.getCellData(1, 4);
		surname = propertyReaderArco.getCellData(1, 5);
		phoneno = propertyReaderArco.getCellData(1, 6);
		jobtitle = propertyReaderArco.getCellData(1, 7);
		password = propertyReaderArco.getCellData(1, 8);
		expectedmessage = propertyReaderArco.getCellData(1, 9);
		
		homePage = applicationSetup();
		homePage.clickLoginRegister();
		enterEmailAddressPage = homePage.clickRegisterNow();
		enterEmailAddressPage.enterEmailID(emailID);
		haveAccountNumberPage = enterEmailAddressPage.clickContinueButton();
		haveAccountNumberPage.selectNoAccount();
		enterPersonalDetailsPage = haveAccountNumberPage.clickContinueButtonForCash();
		enterPersonalDetailsPage.selectTitle(title);
		enterPersonalDetailsPage.enterFirstName(name);
		enterPersonalDetailsPage.enterSurName(surname);
		enterPersonalDetailsPage.enterPhoneNumber(phoneno);
		enterPersonalDetailsPage.enterJobTitle(jobtitle);
		enterPersonalDetailsPage.selectTCCheckbox();
		enterPersonalDetailsPage.selectMarketingCheckbox();
		createPasswordPage = enterPersonalDetailsPage.clickContinueButton();
		createPasswordPage.enterPassword(password);
		registrationSuccessPage = createPasswordPage.clickRegisterButton();
		String actualmessage = registrationSuccessPage.getText("//h1", "We are retrieving registration success message");
		softassert.assertEquals(actualmessage, expectedmessage);
		
		backofficeHomePage = applicationSetupBackoffice();
		backofficeDashboardPage = backofficeHomePage.login();
		backofficeDashboardPage.ifOkMessageDisplayThenClickOnIt();
		backofficeDashboardPage.enterSearchTermInSearchTreeBox(searchTerm);
		b2BCustomerPage = backofficeDashboardPage.clickOnB2BCustomer();
		b2BCustomerPage.enterValueInSearchBox(emailID);
		b2BCustomerPage.clickOnSearchButton();
		b2BCustomerPage.selectUser();
		b2BCustomerPage.clickOnDeleteButton();
		b2BCustomerPage.clickOnYesButton();
		
		 
		softassert.assertAll();
		} catch (final Error e){
			captureScreenshot(test);
			throw e;
		} catch (final Exception e) {
			captureScreenshot(test);
			throw e;
		}
	}
	
	@Test(enabled=true)
	public void registrationAsAccountUserAccountPay() throws Exception
	{
		try 
		{
			propertyReaderArco = new PropertyReaderArco();
			SoftAssert softassert = new SoftAssert();
			test = propertyReaderArco.getCellData(2, 1);
			emailID = propertyReaderArco.getCellData(2, 2);
			accountno = propertyReaderArco.getCellData(2, 3);
			title = propertyReaderArco.getCellData(2, 4);
			name = propertyReaderArco.getCellData(2, 5);
			surname = propertyReaderArco.getCellData(2, 6);
			phoneno = propertyReaderArco.getCellData(2, 7);
			jobtitle = propertyReaderArco.getCellData(2, 8);
			password = propertyReaderArco.getCellData(2, 9);
			expectedmessage = propertyReaderArco.getCellData(2, 10);
			expectedUserStateBefore = propertyReaderArco.getCellData(2, 11);
			
			
			homePage = applicationSetup();
			homePage.clickLoginRegister();
			enterEmailAddressPage = homePage.clickRegisterNow();
			enterEmailAddressPage.enterEmailID(emailID);
			haveAccountNumberPage = enterEmailAddressPage.clickContinueButton();
			haveAccountNumberPage.selectYesAccount();
			haveAccountNumberPage.enterAccountNumber(accountno);
			verifyAccountPage = haveAccountNumberPage.clickContinueButtonForAccount();
			enterPersonalDetailsPage = verifyAccountPage.clickContinueButton_Acc();
			enterPersonalDetailsPage.selectTitle(title);
			enterPersonalDetailsPage.enterFirstName(name);
			enterPersonalDetailsPage.enterSurName(surname);
			enterPersonalDetailsPage.enterPhoneNumber(phoneno);
			enterPersonalDetailsPage.enterJobTitle(jobtitle);
			enterPersonalDetailsPage.selectTCCheckbox();
			enterPersonalDetailsPage.selectMarketingCheckbox();
			createPasswordPage = enterPersonalDetailsPage.clickContinueButton();
			createPasswordPage.enterPassword(password);
			registrationSuccessPage = createPasswordPage.clickRegisterButton();
			String actualmessage = registrationSuccessPage.getText("//h1", "We are retrieving registration success message");
			softassert.assertEquals(actualmessage, expectedmessage);
			/*
			backofficeHomePage = applicationSetupBackoffice();
			backofficeDashboardPage = backofficeHomePage.login();
			backofficeDashboardPage.ifErrorMessageExistThenClickOnIt();
			backofficeDashboardPage.ifOkMessageDisplayThenClickOnIt();
			backofficeDashboardPage.enterSearchTermInSearchTreeBox(searchTerm);
			b2BCustomerPage = backofficeDashboardPage.clickOnB2BCustomer();
			b2BCustomerPage.enterValueInSearchBox(emailID);
			b2BCustomerPage.clickOnSearchButton();
			b2BCustomerPage.selectUser();
			b2BCustomerPage.clickOnDeleteButton();
			b2BCustomerPage.clickOnYesButton();
			*/
			backofficeHomePage = applicationSetupBackoffice();
	         backofficeDashboardPage = backofficeHomePage.login();
	         backofficeDashboardPage.ifErrorMessageExistThenClickOnIt();
	         backofficeDashboardPage.ifOkMessageDisplayThenClickOnIt();
	         backofficeDashboardPage.enterSearchTermInSearchTreeBox(searchTerm);
	         b2BCustomerPage = backofficeDashboardPage.clickOnB2BCustomer();
	         b2BCustomerPage.enterValueInSearchBox(emailID);
	         b2BCustomerPage.clickOnSearchButton();
	         String actualLastName = b2BCustomerPage.getText("(//div[@class='z-listcell-content'])[4]/span", "Here we are retrieving the last name of the customer for verification");
	         softassert.assertEquals(actualLastName, surname);
	         b2BCustomerPage.selectUser();
	         b2BCustomerPage.clickOnExpandArrowButton();
	         String actualUserState = b2BCustomerPage.getAttribute("(//input[@class='z-combobox-input'])[14]", "value", "Here we are retrieving the user state of the customer for verification");
	         softassert.assertEquals(actualUserState, expectedUserStateBefore);
	         b2BCustomerPage.clickOnDownArrowForUserState();
	         b2BCustomerPage.clickOnAuthorisedButton();
	         b2BCustomerPage.clickOnSaveButton();
			softassert.assertAll();
		} catch (final Error e) {
			captureScreenshot(test);
			throw e;
		} catch (final Exception e) {
			captureScreenshot(test);
			throw e;
		}
	}

}
