package com.arco.scripts.purchaselist;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.PurchaseListPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;


public class CustomerAdminwillremove_multiplePl extends ArcoDriverTestCase
{
	 private String test, userName, passWord,expectedUserName,expectedPLPageTitle,searchforProductCode,plNameOne,plNameTwo, plNameThree;
	    private HomePage homePage;
	    private PropertyReaderArco propertyReaderArco;
	    private DashboardPage dashboardPage;
	    private PurchaseListPage purchaseListPage;

	    private SoftAssert softAssert;
	        @Test
	        public void CustomerAdminwillremove_multiplePls() throws Exception
	        {
	        
	        try
	        {
	            softAssert = new SoftAssert();
	        
	            propertyReaderArco = new PropertyReaderArco();
	                        
	            test = propertyReaderArco.getCellData(54, 1);
	            userName = propertyReaderArco.getCellData(54, 2);
	            passWord = propertyReaderArco.getCellData(54, 3);
	            expectedUserName=propertyReaderArco.getCellData(54, 4);
	            expectedPLPageTitle=propertyReaderArco.getCellData(54, 5);
	            searchforProductCode=propertyReaderArco.getCellData(54, 6);
	            plNameOne=propertyReaderArco.getCellData(54, 7);
	            plNameTwo=propertyReaderArco.getCellData(54, 8);
	            plNameThree = propertyReaderArco.getCellData(54, 9);
	            
	            
	            homePage = applicationSetup();
	            homePage.clickOnGotIt();
	            homePage.clickLoginRegister();
	            dashboardPage = homePage.login(userName,passWord);
	            String actualLoginUserName = dashboardPage.getText("(//strong)[1]", "We are getting Login User Name for verification.");
	            softAssert.assertEquals(actualLoginUserName, expectedUserName);
	            purchaseListPage=    dashboardPage.clickPurchaseListLink();
	            String purchaseListPageTitle = purchaseListPage.getText("//h1", "We are getting PL page title for verification.");
	            softAssert.assertEquals(purchaseListPageTitle, expectedPLPageTitle);
	            
	            purchaseListPage.searchBoxForAProductCode(searchforProductCode);
	            
	            purchaseListPage.clickOnCheckBoxForAPL(plNameOne);
	            
	            purchaseListPage.clickOnCheckBoxForAPL(plNameTwo);
	            
	            purchaseListPage.clickOnselectAnAction();
	            purchaseListPage.clickOnremoveProduct();
	            purchaseListPage.clickOnYesButton();
	            purchaseListPage.clickOnDoneButton();
	            
	            purchaseListPage.searchBoxForAProductCode(searchforProductCode);
	        
	            softAssert.assertFalse(purchaseListPage.verifyPLExist(plNameThree, purchaseListPage.allPL()));
	            
	            softAssert.assertFalse(purchaseListPage.verifyPLExist(plNameTwo, purchaseListPage.allPL()));
	            
	            softAssert.assertAll();
	            
	        }catch(Exception e)
	        {
	            throw e;
	        }catch(Error e)
	        {
	            throw e;
	        }
	        
	    }    

}
