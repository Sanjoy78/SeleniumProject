package com.arco.scripts.purchaselist;

import com.arco.util.ArcoDriverTestCase;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.PurchaseListPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class MargeTwoPersonalPLDeleteExistPLForCashUser extends ArcoDriverTestCase
{
	
	private String test, userName, passWord, expectedUserDetails, pLName1, pLName2, createdPLName;
    private HomePage homePage;
    private DashboardPage dashboardPage;
    private PurchaseListPage purchaseListPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;

   @Test
    public void margeTwoPersonalPLDeleteExistPLForCashUser() throws Exception
    {
        try{
            propertyReaderArco=new PropertyReaderArco();
            softAssert=new SoftAssert();
            test=propertyReaderArco.getCellData(32, 1);
            userName=propertyReader.getCellData(32, 2);
            passWord=propertyReader.getCellData(32,3);
            expectedUserDetails=propertyReader.getCellData(32, 4);
            pLName1=propertyReader.getCellData(32, 6);
            pLName2=propertyReader.getCellData(32, 7);
            createdPLName=propertyReader.getCellData(32, 8);
            
           homePage=applicationSetup();
            homePage.clickLoginRegister();
            dashboardPage=homePage.login(userName, passWord);
            String actualUserDetails=dashboardPage.getText("(//strong)[1]", "We are feathing user details for verification");
            softAssert.assertEquals(actualUserDetails, expectedUserDetails);
            purchaseListPage=dashboardPage.clickPurchaseListLink();
            purchaseListPage.clickCreateListButton();
            purchaseListPage.enterPurchaseListName(pLName1);
            purchaseListPage.clickDoneButtonForPurchaseListCreation();
            purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
            purchaseListPage.clickCreateListButton();
            purchaseListPage.enterPurchaseListName(pLName2);
            purchaseListPage.clickDoneButtonForPurchaseListCreation();
            purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
            purchaseListPage.clickOnCheckBoxForAPL(pLName1);
            purchaseListPage.clickOnCheckBoxForAPL(pLName2);
            purchaseListPage.clickOnSelectAnActionButton();
            purchaseListPage.clickOnMergePurchaseList();
            purchaseListPage.clickOnMergeDeleteActionRadioButton();
            purchaseListPage.clickOnSelectButton();
            purchaseListPage.clickOnYesButtonForConfirmation();
            purchaseListPage.enterPurchaseListName(createdPLName);
            purchaseListPage.clickDoneButtonForPurchaseListCreation();
            purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
            purchaseListPage.searchPurchaseListByName(pLName1);
            softAssert.assertFalse(purchaseListPage.verifyPLNotExist(pLName1));
            purchaseListPage.searchPurchaseListByName(pLName2);
            softAssert.assertFalse(purchaseListPage.verifyPLNotExist(pLName2));
            purchaseListPage.searchPurchaseListByName(createdPLName);
            softAssert.assertTrue(purchaseListPage.verifyExistPLName(createdPLName));
            purchaseListPage.clickOnDotForAPL(createdPLName);
            purchaseListPage.clickOnDeleteForAPL(createdPLName);
            purchaseListPage.clickOnYesButtonForPLDetetation();
            purchaseListPage.clickOnDoneButtonAfterPLDeletation();
            softAssert.assertAll();
            
        
       }catch(Error e)
        {
            throw e;
        }catch(Exception e){
        throw e;
    }
        }

}
