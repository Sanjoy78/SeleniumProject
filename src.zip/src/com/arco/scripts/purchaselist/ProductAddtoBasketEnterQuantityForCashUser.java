package com.arco.scripts.purchaselist;

import com.arco.util.ArcoDriverTestCase;

import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.PurchaseListPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class ProductAddtoBasketEnterQuantityForCashUser extends ArcoDriverTestCase
{
	
	private String test, userName, passWord, expectedUserDetails, expectedPLPageTitle, expectedPLCreatePopupTitle;
    private String existingPLName, expectedErrorMessage, personalPurchaseListName, updatedPersonalPurchaseListName, expectedPLName,expectedSearchPLName;
    private String expectedProductDiscription, expectedBaseProductcode, expectedBaseProductFromPrice, expectedSKUdetailsPopup, qtyNumber, expectedErrormessageForQty;
    private HomePage homePage;
    private DashboardPage dashboardPage;
    private PurchaseListPage purchaseListPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;
    
    @Test
    public void productAddtoBasketEnterQuantityForCashUser() throws Exception
    {
        try {
            propertyReaderArco = new PropertyReaderArco();
        softAssert= new SoftAssert();
        test =propertyReaderArco.getCellData(33, 1);
        userName =propertyReaderArco.getCellData(33, 2);
        passWord =propertyReaderArco.getCellData(33, 3);
        expectedUserDetails = propertyReaderArco.getCellData(33, 4);
        expectedPLName= propertyReaderArco.getCellData(33, 6);
        expectedSearchPLName=propertyReaderArco.getCellData(33, 7);
        expectedProductDiscription=propertyReaderArco.getCellData(33, 8);
        expectedBaseProductcode=propertyReaderArco.getCellData(33, 9);
        expectedBaseProductFromPrice=propertyReaderArco.getCellData(33, 10);
        expectedSKUdetailsPopup=propertyReaderArco.getCellData(33, 11);
        qtyNumber=propertyReaderArco.getCellData(33, 12);
        expectedErrormessageForQty=propertyReaderArco.getCellData(33, 13);
        
        homePage = applicationSetup();
        homePage.clickLoginRegister();
        dashboardPage = homePage.login(userName, passWord);
        
        String actualUserDetails = dashboardPage.getText("(//strong)[1]", "We are feathing user details for verification");
        softAssert.assertEquals(actualUserDetails, expectedUserDetails);
        purchaseListPage= dashboardPage.clickPurchaseListLink();
        
        purchaseListPage.searchPurchaseListByName(expectedPLName);
        purchaseListPage.clickOnDotForAPL(expectedPLName);
        purchaseListPage.clickOnViewForAPL(expectedPLName);
        String actualPLName=purchaseListPage.getText("//span[@class='pplTitleName']", "We are feathing the purchase list name for verification");
        softAssert.assertEquals(actualPLName, expectedPLName);
        
        purchaseListPage.clickOnPurchaseListDropDown();
        
        purchaseListPage.clickOnPurchaseListDropDown();
    
        String actualBaseProductcode=purchaseListPage.getText("//p[@class='gridViewTitle badgeProdTitle']", "We are feathing product discription");
        softAssert.assertEquals(actualBaseProductcode, expectedBaseProductcode);
        
        String actualProductDiscription=purchaseListPage.getText("//p[@class='gridViewTitle badgeProdTitle']", "We are feathing product discription");
        softAssert.assertEquals(actualProductDiscription, expectedProductDiscription);
    
        String actualBaseProductFromPrice=purchaseListPage.getText("//div[@class='sku-badges purchaseListBadges gridPurchaseListBadges']/p[1]", "We are feathing product from price");
        softAssert.assertEquals(actualBaseProductFromPrice, expectedBaseProductFromPrice);
        softAssert.assertTrue(purchaseListPage.isbuyNowButtonpresent());
        purchaseListPage.clickOnBuyNowButton();
        String actualSKUdetailsPopup=purchaseListPage.getText("(//h4[@id='myModalLabel'])[7]", "We are feathing SKU Popup details");
        softAssert.assertEquals(actualSKUdetailsPopup,expectedSKUdetailsPopup );
        
        
         purchaseListPage.enterQtyInSkupopupinGridview(qtyNumber);
         purchaseListPage.clickOnIncreaseQtybuttonInGridview();
         String actualErrormessageForQty=purchaseListPage.getText("//span[@id='msg-pplGrid-111700']", "We are feathing error message from SKU Qty popup");
         softAssert.assertEquals(actualErrormessageForQty, expectedErrormessageForQty);
        
         softAssert.assertFalse(purchaseListPage.isAddtobasketbuttonEnable());
         softAssert.assertAll();
        }catch(Error e)
        {
        	captureScreenshot(test);
            throw e;
        }
            
        catch(Exception e)
        {
        	captureScreenshot(test);
            throw e;
        }
    }
}
