package com.arco.scripts.purchaselist;

import com.arco.util.ArcoDriverTestCase;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.PurchaseListPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class CreateEditPurchaseListForCashUser extends ArcoDriverTestCase
{
	
	private String test, userName, passWord, expectedUserDetails, expectedPLPageTitle, expectedPLCreatePopupTitle;
    private String existingPLName, expectedErrorMessage, personalPurchaseListName, updatedPersonalPurchaseListName;
    private HomePage homePage;
    private DashboardPage dashboardPage;
    private PurchaseListPage purchaseListPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;
    
    @Test
    public void createEditPurchaseListForCashUser() throws Exception
    {
        try {
            propertyReaderArco = new PropertyReaderArco();
        softAssert= new SoftAssert();
        test =propertyReaderArco.getCellData(31, 1);
        userName =propertyReaderArco.getCellData(31, 2);
        passWord =propertyReaderArco.getCellData(31, 3);
        expectedUserDetails = propertyReaderArco.getCellData(31, 4);
        expectedPLPageTitle = propertyReaderArco.getCellData(31, 5);
        expectedPLCreatePopupTitle = propertyReaderArco.getCellData(31, 6);
        existingPLName = propertyReaderArco.getCellData(31, 7);
        expectedErrorMessage = propertyReaderArco.getCellData(31, 8);
        personalPurchaseListName = propertyReaderArco.getCellData(31, 9);
        updatedPersonalPurchaseListName = propertyReaderArco.getCellData(31, 10);
        
        homePage = applicationSetup();
        homePage.clickLoginRegister();
        dashboardPage = homePage.login(userName, passWord);
        String actualUserDetails = dashboardPage.getText("(//strong)[1]", "We are feathing user details for verification");
        softAssert.assertEquals(actualUserDetails, expectedUserDetails);
        purchaseListPage= dashboardPage.clickPurchaseListLink();
        String actualPLPageTitle = purchaseListPage.getText("//h1", "We are feathing PL page title for verification");
        softAssert.assertEquals(actualPLPageTitle, expectedPLPageTitle);
        
        purchaseListPage.clickCreateListButton();
        String actualPLCreatePopupTitle = purchaseListPage.getText("//h4[@class='modal-title pplModalTitle']", "We are fatching pop-up title for verification");
        softAssert.assertEquals(actualPLCreatePopupTitle, expectedPLCreatePopupTitle);
        softAssert.assertFalse(purchaseListPage.isPLTypeEnable());
        purchaseListPage.enterPurchaseListName(existingPLName);
        purchaseListPage.clickDoneButtonForPurchaseListCreation();
        String actualErrorMessage = purchaseListPage.getText("//span[@id='name.errors']", "We are fatching error message for verification");
        softAssert.assertEquals(actualErrorMessage, expectedErrorMessage);
        purchaseListPage.enterPurchaseListName(personalPurchaseListName);
        purchaseListPage.clickDoneButtonForPurchaseListCreation();
        purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
        purchaseListPage.searchPurchaseListByName(personalPurchaseListName);
        softAssert.assertTrue(purchaseListPage.verifyPLExist(personalPurchaseListName));
        purchaseListPage.clickOnDotForAPL(personalPurchaseListName);
        purchaseListPage.clickOnEditForAPL(personalPurchaseListName);
        purchaseListPage.enterPurchaseListName(updatedPersonalPurchaseListName);
        purchaseListPage.clickDoneButtonForPurchaseListCreation();
        purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
        softAssert.assertTrue(purchaseListPage.verifyPLExist(updatedPersonalPurchaseListName));
        softAssert.assertAll();
        
        
        } catch (Error e)
        {
            throw e;
        } catch (Exception e)
        {
            throw e;
        }
        
    }

}
