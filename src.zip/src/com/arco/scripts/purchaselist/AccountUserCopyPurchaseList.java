package com.arco.scripts.purchaselist;

import com.arco.util.ArcoDriverTestCase;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.PurchaseListPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class AccountUserCopyPurchaseList extends ArcoDriverTestCase
{
	
	private String test, userName, passWord, expectedUserDetails, plName, plNameCopy;
    private HomePage homePage;
    private DashboardPage dashboardPage;
    private PurchaseListPage purchaseListPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;

   @Test
    public void accountUserCopyPurchaseList() throws Exception
    {
        try{
            propertyReaderArco=new PropertyReaderArco();
            softAssert=new SoftAssert();
            test=propertyReaderArco.getCellData(30, 1);
            userName=propertyReader.getCellData(30, 2);
            passWord=propertyReader.getCellData(30,3);
            expectedUserDetails=propertyReader.getCellData(30, 4);
            plName=propertyReader.getCellData(30, 5);
            plNameCopy=propertyReader.getCellData(30, 6);
            
           homePage=applicationSetup();
            homePage.clickLoginRegister();
            dashboardPage=homePage.login(userName, passWord);
            String actualUserDetails=dashboardPage.getText("(//strong)[1]", "We are feathing user details for verification");
            softAssert.assertEquals(actualUserDetails, expectedUserDetails);
            purchaseListPage=dashboardPage.clickPurchaseListLink();
            purchaseListPage.searchPurchaseListByName(plName);
            purchaseListPage.clickOnDotForAPL(plName);
            purchaseListPage.clickOnCopyForAPL(plName);
            purchaseListPage.enterPurchaseListName(plName+plNameCopy);
            purchaseListPage.selectAccountPurchaseListType();
            purchaseListPage.clickDoneButtonForPurchaseListCreation();
            purchaseListPage.clickDoneButtonAfterPurchaseListCreation();
            purchaseListPage.searchPurchaseListByName(plName+plNameCopy);
            purchaseListPage.searchPurchaseListByName(plName+plNameCopy);
            softAssert.assertTrue(purchaseListPage.verifyExistPLName(plName+plNameCopy));
            softAssert.assertAll();
       
       
    }catch(Error e)
    {
        throw e;
    }catch(Exception e){
    throw e;
}
    
   }

}
