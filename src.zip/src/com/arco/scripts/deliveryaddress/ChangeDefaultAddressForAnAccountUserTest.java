package com.arco.scripts.deliveryaddress;

import com.arco.util.ArcoDriverTestCase;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.BasketPage;
import com.arco.pages.storefront.CategoryListPage;
import com.arco.pages.storefront.CheckOutPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.OrderConfirmationPage;
import com.arco.pages.storefront.ProductDetailsPage;

import com.arco.util.PropertyReaderArco;


public class ChangeDefaultAddressForAnAccountUserTest extends ArcoDriverTestCase
{
	
	private String test, userId, passWord,  country, numberOfItem, purchaseOrderNumber, productCodeOrText, baseProductCode, 
	expectedMessage, skuID, expectedUserDetails, expectedPostcodeBeforeChange, expectedPostcodeAfterChange, deliveryInstructions;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private CategoryListPage categoryListPage;
	private ProductDetailsPage productDetailsPage;
	private BasketPage basketPage;
	private CheckOutPage checkOutPage;
	private OrderConfirmationPage orderConfirmationPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;



@Test
public void placingOrderForRegisteredUser() throws Exception
{
	try
	{
		propertyReaderArco = new PropertyReaderArco();
		softAssert = new SoftAssert();
		test = propertyReaderArco.getCellData(26, 1);
		userId = propertyReaderArco.getCellData(26, 2);
		passWord = propertyReaderArco.getCellData(26, 3);
		productCodeOrText = propertyReaderArco.getCellData(26, 4);
		numberOfItem =propertyReaderArco.getCellData(26, 5);
		skuID = propertyReaderArco.getCellData(26, 6);
		expectedUserDetails = propertyReaderArco.getCellData(26, 7);
		expectedMessage = propertyReaderArco.getCellData(26, 8);
		expectedPostcodeBeforeChange = propertyReaderArco.getCellData(26, 9);
		expectedPostcodeAfterChange = propertyReaderArco.getCellData(26, 10);
		baseProductCode = propertyReaderArco.getCellData(26, 11);
		country = propertyReaderArco.getCellData(26, 12);
		purchaseOrderNumber = propertyReaderArco.getCellData(26, 13); 
		deliveryInstructions = propertyReaderArco.getCellData(26, 14); 
		
		homePage = applicationSetup();
		homePage.clickLoginRegister();
		dashboardPage = homePage.login(userId, passWord);
		String actualUserDetails = dashboardPage.getText("(//strong)[1]", "Here we are featching user details");
		softAssert.assertEquals(actualUserDetails, expectedUserDetails);
		dashboardPage.enterProductNameOrCode(productCodeOrText);
		categoryListPage = dashboardPage.clickOnFindButton();
		productDetailsPage = categoryListPage.clickOnAProduct(baseProductCode);
		productDetailsPage.enterQTYForSKU(skuID, numberOfItem);
		productDetailsPage.clickOnAddToBasketButton();
		basketPage = productDetailsPage.clickOnCheckOutButton();
		basketPage.enterPurchaseOrderNumber(purchaseOrderNumber);
		basketPage.clickOnVATText();
		checkOutPage = basketPage.clickOnCheckOutButton();
		String actualPostcodeBeforeChange = checkOutPage.getText("//span[@id='cartDeliveryPostalCode']", "We are featching current postcode for verification");
		softAssert.assertEquals(actualPostcodeBeforeChange, expectedPostcodeBeforeChange);
		checkOutPage.clickOnChange();
		actualPostcodeBeforeChange = checkOutPage.getText("//span[@id='postCodeDeliveryAddr']", "We are featching current postcode for verification");
		softAssert.assertEquals(actualPostcodeBeforeChange, expectedPostcodeBeforeChange);
		checkOutPage.clickOnUseDifferentAddress();
		checkOutPage.searchAddressesBox(expectedPostcodeAfterChange);
		checkOutPage.clickOnSearchCheckBox();
		checkOutPage.clickOnSelectUpdateUserAddress();
		checkOutPage.enterDeliveryInstructions(deliveryInstructions);
		checkOutPage.clickOnUsetheseDeliveryDetails();
		String actualPostcodeAfterChange = checkOutPage.getText("//span[@id='cartDeliveryPostalCode']", "We are featching current postcode for verification");
		softAssert.assertEquals(actualPostcodeAfterChange, expectedPostcodeAfterChange);
		checkOutPage.clickOnChange();
		checkOutPage.clickOnEditAddress();
		checkOutPage.selectCountry(country);
		checkOutPage.clickOnMakeDefaultAddress();
		checkOutPage.clickOnUsethisAddress();
		actualPostcodeAfterChange = checkOutPage.getText("//span[@id='cartDeliveryPostalCode']", "We are featching current postcode for verification");
		softAssert.assertEquals(actualPostcodeAfterChange, expectedPostcodeAfterChange);
		checkOutPage.clickOnUseThesePaymentDetailsButton();
		orderConfirmationPage = checkOutPage.clickOnPlaceOrderButton();
		String successMessage = orderConfirmationPage.getText("//p[@class='light-grey']", "Here we are retrieving success message for verification");
		softAssert.assertEquals(successMessage, expectedMessage);
		orderConfirmationPage.clickOnUserName();
		homePage = orderConfirmationPage.clickOnLogOutButton();
		softAssert.assertAll();
		
		
		
		
	} catch (Error e)
	{
		captureScreenshot(test);
		throw e;
	} catch (Exception e)
	{
		captureScreenshot(test);
		throw e;
	}
}

}
