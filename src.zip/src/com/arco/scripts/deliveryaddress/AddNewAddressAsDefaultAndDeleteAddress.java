package com.arco.scripts.deliveryaddress;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.AddEditAddressPage;
import com.arco.pages.storefront.AddressBookPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.MyAccountPage;
import com.arco.util.ArcoDriverTestCase;

public class AddNewAddressAsDefaultAndDeleteAddress extends ArcoDriverTestCase
{
	
	private String test, userId, passWord, addressL1, city,postCode, contactName, contactNumber, expectedText, contactNumberOfExistingAddress;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private MyAccountPage myAccountPage;
	private AddressBookPage addressBookPage;
	private AddEditAddressPage addEditAddressPage;
	
	@Test
	public void addNewAddressAsDefaultAndDeleteAddress() throws Exception
	{
		try
		{
			SoftAssert softassert = new SoftAssert();
			test = propertyReader.getCellData(41, 1);
			userId = propertyReader.getCellData(41, 2);
			passWord = propertyReader.getCellData(41, 3);
			addressL1 = propertyReader.getCellData(41, 4);
			city = propertyReader.getCellData(41, 5);
			postCode = propertyReader.getCellData(41, 6);
			contactName = propertyReader.getCellData(41, 7);
			contactNumber = propertyReader.getCellData(41, 8);
			expectedText = propertyReader.getCellData(41, 9);
			contactNumberOfExistingAddress = propertyReader.getCellData(41, 10);
			
			homePage = applicationSetup();
			homePage.clickOnGotIt();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(userId, passWord);
			dashboardPage.clickUserName();
			myAccountPage = dashboardPage.clickAccountOverview();
			addressBookPage = myAccountPage.clickOnManageAddress();
			String defaultAddressText = addressBookPage.getText("//span[text()='Address1']/following::span/b", "We are fatching default address text for verification" );
			softassert.assertEquals(defaultAddressText, expectedText);
			addEditAddressPage = addressBookPage.clickOnAddNewAddressButton();
			addEditAddressPage.enterAddressL1(addressL1);
			addEditAddressPage.enterCityTown(city);
			addEditAddressPage.enterPostCode(postCode);
			addEditAddressPage.enterContactName(contactName);
			addEditAddressPage.enterContactNumber(contactNumber);
			addEditAddressPage.selectDefaultAddressCheckBox();
			addressBookPage = addEditAddressPage.clickOnSaveAddressButton();
			String defaultAddressText1 = addressBookPage.getText("//span[text()='Address2']/following::span/b", "We are fatching default address text for verification" );
			softassert.assertEquals(defaultAddressText1, expectedText);
			addressBookPage.clickOnDotsForAnAddress(contactNumberOfExistingAddress);
			addEditAddressPage = addressBookPage.clickOnEditForAnAddress(contactNumberOfExistingAddress);
			addEditAddressPage.selectDefaultAddressCheckBox();
			addressBookPage = addEditAddressPage.clickOnSaveAddressButton();
			addressBookPage.clickOnDotsForAnAddress(contactName);
			addressBookPage.clickOnDeleteForAnAddress(contactName);
			softassert.assertAll();
			
			
			
			
			
		} catch(Exception e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
