package com.arco.scripts.deliveryaddress;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.BasketPage;
import com.arco.pages.storefront.CategoryListPage;
import com.arco.pages.storefront.CheckOutPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.MyAccountPage;
import com.arco.pages.storefront.OrderConfirmationPage;
import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class AddingEditingNewDeliveryAddressWithOutSavingToAddressBook extends ArcoDriverTestCase
{
	
	private String test, userId, passWord, userDetails, productCode, skuID, numberOfItem; 
	private String country, address, townCity, postCode, contactName, contactNumber, purchaseOrderNumber;
	private SoftAssert softAssert;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private CategoryListPage categoryListPage;
	private ProductDetailsPage productDetailsPage;
	private BasketPage basketPage;
	private CheckOutPage checkOutPage;
	private OrderConfirmationPage orderConfirmationPage;
	private MyAccountPage myAccountPage;
	
	@Test
	public void addingEditingNewDeliveryAddressWithOutSavingToAddressBook() throws Exception
	{
		try
		{
			softAssert = new SoftAssert();
			test = propertyReader.getCellData(26, 1);
			userId = propertyReader.getCellData(26, 2);
			passWord = propertyReader.getCellData(26, 3);
			userDetails = propertyReader.getCellData(26, 4);
			productCode = propertyReader.getCellData(26, 5);
			skuID = propertyReader.getCellData(26, 6);
			numberOfItem = propertyReader.getCellData(26, 7);
			country = propertyReader.getCellData(26, 8);
			address = propertyReader.getCellData(26, 9);
			townCity = propertyReader.getCellData(26, 10);
			postCode = propertyReader.getCellData(26, 11);
			contactName = propertyReader.getCellData(26, 12);
			contactNumber = propertyReader.getCellData(26, 13);
			purchaseOrderNumber = propertyReader.getCellData(26, 15);
			
			
			homePage = applicationSetup();
			
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(userId, passWord);
			dashboardPage.clickOnGotIt();
			dashboardPage.enterProductNameOrCode(productCode);
			productDetailsPage = dashboardPage.clickOnFindButtonToNavigatePDP();
			//productDetailsPage = categoryListPage.clickOnAProduct(productCode);
			productDetailsPage.enterQTYForSKU(skuID, numberOfItem);
			productDetailsPage.clickOnViewDetails();
			productDetailsPage.clickOnAddToBasketButton();
			basketPage = productDetailsPage.clickOnCheckOutButton();
			basketPage.enterPurchaseOrderNumber(purchaseOrderNumber);
			basketPage.clickOnVATText();
			checkOutPage = basketPage.clickOnCheckOutButton();
			checkOutPage.selectCountry(country);
			checkOutPage.enterAddressL1(address);
			checkOutPage.enterCityTown(townCity);
			checkOutPage.enterPostCode(postCode);
			checkOutPage.enterContactName(contactName);
			checkOutPage.enterContactName(contactNumber);
			checkOutPage.clickOnUsethisAddress();
			checkOutPage.clickOnUseThesePaymentDetailsButton();
			orderConfirmationPage = checkOutPage.clickOnPlaceOrderButton();
			dashboardPage = orderConfirmationPage.clickOnHomePageLogo();
			dashboardPage.clickUserName();
			myAccountPage = dashboardPage.clickAccountOverview();
			
			softAssert.assertAll();
			
		}catch(Exception e)
		{
			captureScreenshot(test);
			throw e;
		}catch(Error e)
		{
			captureScreenshot(test);
			throw e;
		}
		
	}

}
