package com.arco.scripts.deliveryaddress;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.BasketPage;
import com.arco.pages.storefront.CategoryListPage;
import com.arco.pages.storefront.CheckOutPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.MyAccountPage;
import com.arco.pages.storefront.OrderConfirmationPage;
import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.util.ArcoDriverTestCase;

public class AddingEditingNewDeliveryAddressBySavingToAddressBook extends ArcoDriverTestCase
{
	private String test, userId, passWord, userDetails, productCode, skuID, numberOfItem; 
	private String country, address, townCity, postCode, contactName, contactNumber;
	private SoftAssert softAssert;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private CategoryListPage categoryListPage;
	private ProductDetailsPage productDetailsPage;
	private BasketPage basketPage;
	private CheckOutPage checkOutPage;
	private OrderConfirmationPage orderConfirmationPage;
	private MyAccountPage myAccountPage;
	
	@Test
	public void addingEditingNewDeliveryAddressBySavingToAddressBook() throws Exception
	{
		try
		{
			softAssert = new SoftAssert();
			test = propertyReader.getCellData(27, 1);
			userId = propertyReader.getCellData(27, 2);
			passWord = propertyReader.getCellData(27, 3);
			userDetails = propertyReader.getCellData(27, 4);
			productCode = propertyReader.getCellData(27, 5);
			skuID = propertyReader.getCellData(27, 6);
			numberOfItem = propertyReader.getCellData(27, 7);
			country = propertyReader.getCellData(27, 8);
			address = propertyReader.getCellData(27, 9);
			townCity = propertyReader.getCellData(27, 10);
			postCode = propertyReader.getCellData(27, 11);
			contactName = propertyReader.getCellData(27, 12);
			contactNumber = propertyReader.getCellData(27, 13);
			
			
			homePage = applicationSetup();
			homePage.clickOnGotIt();
			homePage.clickLoginRegister();
			dashboardPage = homePage.login(userId, passWord);
			dashboardPage.enterProductNameOrCode(productCode);
			categoryListPage = dashboardPage.clickOnFindButton();
			productDetailsPage = categoryListPage.clickOnAProduct(productCode);
			productDetailsPage.enterQTYForSKU(skuID, numberOfItem);
			productDetailsPage.clickOnAddToBasketButton();
			basketPage = productDetailsPage.clickOnCheckOutButton();
			checkOutPage = basketPage.clickOnCheckOutButton();
			checkOutPage.selectCountry(country);
			checkOutPage.enterAddressL1(address);
			checkOutPage.enterCityTown(townCity);
			checkOutPage.enterPostCode(postCode);
			checkOutPage.enterContactName(contactName);
			checkOutPage.enterContactName(contactNumber);
			checkOutPage.clickOnUsethisAddress();
			checkOutPage.clickOnUseThesePaymentDetailsButton();
			orderConfirmationPage = checkOutPage.clickOnPlaceOrderButton();
			dashboardPage = orderConfirmationPage.clickOnHomePageLogo();
			dashboardPage.clickUserName();
			myAccountPage = dashboardPage.clickAccountOverview();
			
			softAssert.assertAll();
			
		}catch(Exception e)
		{
			captureScreenshot(test);
			throw e;
		}catch(Error e)
		{
			captureScreenshot(test);
			throw e;
		}
		
	}

}
