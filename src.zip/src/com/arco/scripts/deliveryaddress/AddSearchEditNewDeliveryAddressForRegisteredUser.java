package com.arco.scripts.deliveryaddress;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.AddEditAddressPage;
import com.arco.pages.storefront.AddressBookPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.MyAccountPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;
public class AddSearchEditNewDeliveryAddressForRegisteredUser extends ArcoDriverTestCase

{
	
	private String test, userId, passWord, actualUserDetails, expectedUserDetails, address, name, number, deliveryInstructions, 
	actualSuccessMessage, expectedSuccessMessage, invalidAddressName, actualNoSearchResult, expectedNoSearchResult, validAddressName, 
	actualContactName, companyName, expectedSuccessMessageUpdate, actualErrorMessage, expectedErrorMessage, actualTitleSearchAddressBox, searchAddress;
	private HomePage homePage;
	private DashboardPage dashboardPage;
	private MyAccountPage myAccountPage;
	private AddressBookPage addressBookPage;
	private AddEditAddressPage addEditAddressPage;
	private SoftAssert softAssert;
	private PropertyReaderArco propertyReaderArco;
	
	@Test
	public void addSearchEditNewDeliveryAddressForRegisteredUser() throws Exception
	{
		try 
		{
			propertyReaderArco = new PropertyReaderArco();
			softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(44, 1);
			userId = propertyReaderArco.getCellData(44, 2);
			passWord = propertyReaderArco.getCellData(44, 3);
			expectedUserDetails = propertyReaderArco.getCellData(44, 4);
			address = propertyReaderArco.getCellData(44, 5);
			name = propertyReaderArco.getCellData(44, 6);
			number = propertyReaderArco.getCellData(44, 7);
			deliveryInstructions= propertyReaderArco.getCellData(44, 8);
			expectedSuccessMessage = propertyReaderArco.getCellData(44, 9);
			invalidAddressName = propertyReaderArco.getCellData(44, 10);
			expectedNoSearchResult = propertyReaderArco.getCellData(44, 11);
			validAddressName = propertyReaderArco.getCellData(44, 12);
			actualContactName = propertyReaderArco.getCellData(44, 7);
			companyName = propertyReaderArco.getCellData(44, 13);
			expectedSuccessMessageUpdate = propertyReaderArco.getCellData(44, 14);
			expectedErrorMessage = propertyReaderArco.getCellData(44, 15); 
			searchAddress = propertyReaderArco.getCellData(44, 16);
			
			homePage = applicationSetup();
            homePage.clickLoginRegister();
            dashboardPage = homePage.login(userId, passWord);
            actualUserDetails = dashboardPage.getText("(//strong)[1]", "Here we are featching user details");
            softAssert.assertEquals(actualUserDetails, expectedUserDetails);
            dashboardPage.clickUserName();
            myAccountPage = dashboardPage.clickAccountOverview();
            addressBookPage = myAccountPage.clickManageAddressesButton();
            actualTitleSearchAddressBox = dashboardPage.getText("//label[@for = 'searchusers']", "Here we are verifying the title on the search box");
            softAssert.assertEquals(actualTitleSearchAddressBox, searchAddress);
            addEditAddressPage = addressBookPage.clickAddNewAddressButton();
            addEditAddressPage.enterAddressToBeSearch(address);
            addEditAddressPage.clickToSelectAddress();
            addEditAddressPage.enterContactName(name);
            addEditAddressPage.enterContactNumber(number);
            addEditAddressPage.enterDeliveryInstructions(deliveryInstructions);
            addressBookPage = addEditAddressPage.clickSaveAddressButton();
            actualSuccessMessage = dashboardPage.getText("//div[@class='alert alert-success alert-dismissible top-space']", "Here we are verifying the success message");
            softAssert.assertEquals(actualSuccessMessage, expectedSuccessMessage);
            softAssert.assertTrue(addressBookPage.isDefaultAddressIndicator());
            addressBookPage.enterAddressToBeSearch(invalidAddressName);
            actualNoSearchResult = dashboardPage.getText("//div[@class='noResultsFound']", "Here we are verifying the not found result");
            softAssert.assertEquals(actualNoSearchResult, expectedNoSearchResult);
            addressBookPage.enterAddressToBeSearch(validAddressName);
            actualContactName = dashboardPage.getText("//span[@class='LetterCapitalize']", "Here we are verifying the valid contact name");
            softAssert.assertEquals(actualContactName, name);
            addressBookPage.clickOnThreeDotForAnAddress();
            addEditAddressPage = addressBookPage.clickOnEditButton();
            addEditAddressPage.enterCompanyName(companyName);
            softAssert.assertFalse(addEditAddressPage.isMakeDefaultAddressIndicator());
            addressBookPage = addEditAddressPage.clickSaveAddressButton();
            actualSuccessMessage = dashboardPage.getText("//div[@class='alert alert-success alert-dismissible top-space']", "Here we are verifying the success message after updation");
            softAssert.assertEquals(actualSuccessMessage, expectedSuccessMessageUpdate);
            addressBookPage.clickOnThreeDotForAnAddress();
            addressBookPage.clickOnDeleteButton();
            actualErrorMessage = dashboardPage.getText("//div[@class='alert alert-danger alert-dismissible top-space']", "Here we are verifying the error message after delete");
            softAssert.assertEquals(actualErrorMessage, expectedErrorMessage);
            softAssert.assertAll();
		} 
		catch (final Error e) {
			captureScreenshot(test);
			throw e;
		} catch (final Exception e) {
			captureScreenshot(test);
			throw e;
		}
	}
	

}
