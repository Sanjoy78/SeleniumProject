package com.arco.scripts.deliveryaddress;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.arco.pages.storefront.EmailConfirmationPage;
import com.arco.pages.storefront.BasketPage;
import com.arco.pages.storefront.CategoryListPage;
import com.arco.pages.storefront.CheckOutCardPaymentPage;
import com.arco.pages.storefront.CheckOutPage;
import com.arco.pages.storefront.HomePage;
import com.arco.pages.storefront.OrderConfirmationPage;
import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.util.ArcoDriverTestCase;
import com.arco.util.PropertyReaderArco;

public class AddingDeliveryAddressAndDeliveryInstractionForGuestUser extends ArcoDriverTestCase
{
	
	private String test, anonymousUserId, productCode, skuID, numberOfItem, expectedMessage, address, contactname, contactnumber, country, cardnumber, securitycode, month, year; 
    private String expectedErrorMessage;
    private HomePage homePage;
    private CategoryListPage categoryListPage;
	private ProductDetailsPage productDetailsPage;
	private BasketPage basketPage;
	private CheckOutPage checkOutPage;
	private OrderConfirmationPage orderConfirmationPage;
    private SoftAssert softAssert;
    private PropertyReaderArco propertyReaderArco;
	private EmailConfirmationPage anonymousconfirmemailPage;
	private CheckOutCardPaymentPage checkOutCardPaymentPage;
	
    
    @Test
	public void placingOrderForAnonymousUser() throws Exception
	{
		try
		{
			propertyReaderArco = new PropertyReaderArco();
			softAssert = new SoftAssert();
			test = propertyReaderArco.getCellData(25, 1);
            productCode = propertyReaderArco.getCellData(25, 2);
            numberOfItem =propertyReaderArco.getCellData(25, 3);
            skuID = propertyReaderArco.getCellData(25, 4);
            anonymousUserId = propertyReaderArco.getCellData(25, 5);
            address = propertyReaderArco.getCellData(25, 6);
            contactname = propertyReaderArco.getCellData(25, 7);
            contactnumber = propertyReaderArco.getCellData(25, 8);
            country = propertyReaderArco.getCellData(25, 9);
            cardnumber = propertyReaderArco.getCellData(25, 10);
            securitycode = propertyReaderArco.getCellData(25, 11);
            month = propertyReaderArco.getCellData(25, 12);
            year = propertyReaderArco.getCellData(25, 13);
            expectedMessage = propertyReaderArco.getCellData(25, 14);
			
			homePage = applicationSetup();
			homePage.enterProductCodeInSearchBox(productCode);
			categoryListPage = homePage.clickOnFindButton();
			productDetailsPage = categoryListPage.clickOnAProduct(productCode);
			productDetailsPage.enterQTYForSKU(skuID, numberOfItem);
			productDetailsPage.clickOnAddToBasketButton();
			basketPage = productDetailsPage.clickOnCheckOutButton();
			anonymousconfirmemailPage = basketPage.clickOnCheckOutButtonforAnonymousUser();
			anonymousconfirmemailPage.enterguestEmailIdinemailBox(anonymousUserId);
			anonymousconfirmemailPage.enterguestEmailIdinconfirmemailbox(anonymousUserId);
			//checkOutPage = anonymousconfirmemailPage.clickoncheckoutasaguestbutton();
			checkOutPage.selectCountry(country);
			//checkOutPage.enteraddressinaddressbox(address);
			checkOutPage.enterAddressL1("Gfss");
			checkOutPage.enterCityTown("London");
			checkOutPage.enterPostCode("HU7 4XU");
			checkOutPage.enterContactName(contactname);
			checkOutPage.enterContactPhoneNumber(contactnumber);
			checkOutPage.clickOnUsethisAddress();
			checkOutPage.clickOnUseThesePaymentDetailsButton();
			checkOutPage.clickOnCheckBoxForTC();
			checkOutCardPaymentPage = checkOutPage.clickOnPlaceOrderButtonforAnonymous();
			//checkOutCardPaymentPage.switchToFrame1();
			checkOutCardPaymentPage.enterCardNumber("4012");
			Thread.sleep(2000);
			checkOutCardPaymentPage.enterCardNumber("0010");
			Thread.sleep(2000);
			checkOutCardPaymentPage.enterCardNumber("3627");
			Thread.sleep(2000);
			checkOutCardPaymentPage.enterCardNumber("5556");
			Thread.sleep(2000);
			checkOutCardPaymentPage.enterSecurityCode(securitycode);
			checkOutCardPaymentPage.selectMonthlist(month);
			checkOutCardPaymentPage.selectYearlist(year);
			
			
			
			
			//orderConfirmationPage = checkOutPage.clickOnPlaceOrderButton();
			//String successMessage = orderConfirmationPage.getText("//p[@class='light-grey']", "Here we are retreiving success message for verification");
			//softAssert.assertEquals(successMessage, expectedMessage);
			
			
			} catch (Error e)
		{
			captureScreenshot(test);
			throw e;
		} catch (Exception e)
		{
			captureScreenshot(test);
			throw e;
		}
	}

}
