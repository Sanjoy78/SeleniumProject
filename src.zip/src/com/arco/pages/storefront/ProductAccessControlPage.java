package com.arco.pages.storefront;

import com.arco.util.ArcoDriverHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class ProductAccessControlPage extends ArcoDriverHelper
{
	

	@FindBy(how=How.XPATH, using="//div[@id='productAccessControlList']/a")
	private WebElement createListButton;
	
	@FindBy(how=How.XPATH, using="//input[@id='prdAccListName']")
	private WebElement productAccessControlListName;
	
	@FindBy(how=How.XPATH, using="//select[@id='prodAccessControlListType']")
	private WebElement productAccessControlListContext;
	
	@FindBy(how=How.XPATH, using="//button[@id='accPrdListCreate']")
	private WebElement doneButtonForProductAccessControlListCreation;
	
	@FindBy(how=How.XPATH, using="//button[@id='pacListSuccessBtn']")
	private WebElement doneButtonAfterProductAccessControlListCreation;
	
	@FindBy(how=How.XPATH, using="//input[@id='pac-search']")
	private WebElement searchBoxForProductAccessControl;
	
	@FindBy(how=How.XPATH, using="//span[@id='dropdownMenu1']")
	private WebElement dotsOfProductAccessControlList;
	
	@FindBy(how=How.XPATH, using="(//a[text() = 'Delete'])[1]")
	private WebElement deleteButtonForProductAccessControlList;
	
	@FindBy(how=How.XPATH, using="//button[@id='pacConfirmationBtn']")
	private WebElement yesButtonForPACDeletation;
	
	@FindBy(how=How.XPATH, using="//button[@id='multiDeleteConfrimBtn']")
	private WebElement doneButtonAfterProductAccessControlListDeletation;
	
	public ProductAccessControlPage(WebDriver webdriver) 
	{
		super(webdriver);
		
	}
	
	public ProductAccessControlPage clickOnDotsOfProductAccessControlList(String pacname)
    {
        String locator = "//a[@title='"+pacname+"']/following::span[@id='dropdownMenu1']";
        waitForElementPresent(locator, getTimeOut());
        driver.findElement(byLocator(locator)).click();
        return PageFactory.initElements(driver, ProductAccessControlPage.class);
    }
	
	public ProductAccessControlPage clickOnDeleteButtonForProductAccessControlList(String pacname)
    {
        String locator = "(//a[@title='"+pacname+"']/following::a[@title='Delete'])[1]";
        waitForElementPresent(locator, getTimeOut());
        driver.findElement(byLocator(locator)).click();
        return PageFactory.initElements(driver, ProductAccessControlPage.class);
    }
	
	public Boolean isPACListPresent(String pacname)
	{
		String locator = "//span[text() = '"+pacname+"']";
		
	    //return isElementPresent(driver.findElement(byLocator(locator)));
	    return isElementPresent(locator);
	}
	
	public ProductAccessControlPage clickOnCreateListButton()
	{
		waitForWebElementPresent(createListButton, getTimeOut());
		Assert.assertTrue(createListButton.isDisplayed());
		createListButton.click();
		return PageFactory.initElements(driver, ProductAccessControlPage.class);
	}
	
	public ProductAccessControlPage enterProductAccessControlListName(String name)
	{
		waitForWebElementPresent(productAccessControlListName, getTimeOut());
		Assert.assertTrue(productAccessControlListName.isDisplayed());
		productAccessControlListName.clear();
		productAccessControlListName.sendKeys(name);
		return PageFactory.initElements(driver, ProductAccessControlPage.class);
	}
	
	public ProductAccessControlPage selectProductAccessControlListContext(String context)
	{
		waitForWebElementPresent(productAccessControlListContext, getTimeOut());
		Assert.assertTrue(productAccessControlListContext.isDisplayed());
		selectDropDown(productAccessControlListContext, context);
		return PageFactory.initElements(driver, ProductAccessControlPage.class);
	}
	
	public ProductAccessControlPage clickDoneButtonForProductAccessControlListCreation()
	{
		waitForWebElementPresent(doneButtonForProductAccessControlListCreation, getTimeOut());
		Assert.assertTrue(doneButtonForProductAccessControlListCreation.isDisplayed());
		doneButtonForProductAccessControlListCreation.click();
		return PageFactory.initElements(driver, ProductAccessControlPage.class);
	}
	
	public ProductAccessControlPage clickDoneButtonAfterProductAccessControlList()
	{
		waitForWebElementPresent(doneButtonAfterProductAccessControlListCreation, getTimeOut());
		Assert.assertTrue(doneButtonAfterProductAccessControlListCreation.isDisplayed());
		doneButtonAfterProductAccessControlListCreation.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ProductAccessControlPage.class);
	}
	
	public ProductAccessControlPage searchProductAccessControlListByName(String pacName)
	{
		waitForWebElementPresent(searchBoxForProductAccessControl, getTimeOut());
		Assert.assertTrue(searchBoxForProductAccessControl.isDisplayed());
		searchBoxForProductAccessControl.click();
		searchBoxForProductAccessControl.clear();
		searchBoxForProductAccessControl.sendKeys(pacName);
		return PageFactory.initElements(driver, ProductAccessControlPage.class);
	}
	
	public ProductAccessControlPage clickOnDotsOfProductAccessControlList()
	{
		waitForWebElementPresent(dotsOfProductAccessControlList, getTimeOut());
		Assert.assertTrue(dotsOfProductAccessControlList.isDisplayed());
		dotsOfProductAccessControlList.click();
		return PageFactory.initElements(driver, ProductAccessControlPage.class);
	}
	
	public ProductAccessControlPage clickOnDeleteButtonForProductAccessControlList()
	{
		waitForWebElementPresent(deleteButtonForProductAccessControlList, getTimeOut());
		Assert.assertTrue(deleteButtonForProductAccessControlList.isDisplayed());
		deleteButtonForProductAccessControlList.click();
		return PageFactory.initElements(driver, ProductAccessControlPage.class);
	}
	
	public ProductAccessControlPage clickOnYesButtonForPACDeletation()
	{
		waitForWebElementPresent(yesButtonForPACDeletation, getTimeOut());
		Assert.assertTrue(yesButtonForPACDeletation.isDisplayed());
		yesButtonForPACDeletation.click();
		return PageFactory.initElements(driver, ProductAccessControlPage.class);
	}
	
	public ProductAccessControlPage clickOnDoneButtonAfterPACDeletation()
	{
		waitForWebElementPresent(doneButtonAfterProductAccessControlListDeletation, getTimeOut());
		Assert.assertTrue(doneButtonAfterProductAccessControlListDeletation.isDisplayed());
		doneButtonAfterProductAccessControlListDeletation.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ProductAccessControlPage.class);
	}

}
