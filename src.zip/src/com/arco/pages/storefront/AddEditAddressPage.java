package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class AddEditAddressPage extends ArcoDriverHelper
{
	
	@FindBy(how=How.XPATH, using="//input[@id='addressLine1']")
    private WebElement addressL1;
	
	@FindBy(how=How.XPATH, using="//input[@id='city']")
    private WebElement cityTown;
    
    @FindBy(how=How.XPATH, using="//input[@id='postcode']")
    private WebElement postCode;
    
    @FindBy(how=How.XPATH, using="//input[@id='contactName']")
    private WebElement contactName;
    
    @FindBy(how=How.XPATH, using="//input[@id='phone']")
    private WebElement contactNumber;
    
    @FindBy(how=How.XPATH, using="//input[@id='Make this my default address']")
    private WebElement defaultAddressCheckBox;
    
    @FindBy(how=How.XPATH, using="//button[@class='btn btn-primary createAddressFormBtn']")
    private WebElement saveAddressButton;
    
    @FindBy(how=How.XPATH, using="//input[@placeholder='Start typing an address']")
    private WebElement enterAddressToBeSearch;
    
    @FindBy(how=How.XPATH, using="//input[@id='remarks']")
    private WebElement enterDeliveryInstructions;
    
    @FindBy(how=How.XPATH, using="//button[contains(@class,'btn btn-primary createAddressFormBtn')]")
    private WebElement clickSaveAddress;
    
    @FindBy(how=How.XPATH, using="//input[@id='companyName']")
    private WebElement companyName;
	
	public AddEditAddressPage (final WebDriver driver)
	{
		super(driver);
	}
	
	public Boolean isMakeDefaultAddressIndicator()
    {
        return isElementPresent("//input[@id='Make this my default address']");
    }
	
	public AddEditAddressPage enterCompanyName(String company)
    {
      waitForWebElementPresent(companyName, getTimeOut());
      Assert.assertTrue(companyName.isDisplayed());
      companyName.click();
      companyName.clear();
      companyName.sendKeys(company);
      return PageFactory.initElements(driver, AddEditAddressPage.class);
    }
	
	public AddressBookPage clickSaveAddressButton()
    {
        waitForWebElementNotPresent(clickSaveAddress, getTimeOut());
        Assert.assertTrue(clickSaveAddress.isDisplayed());
        _clickUsingJavaScript(clickSaveAddress);
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, AddressBookPage.class);
    }
	
	public AddEditAddressPage enterDeliveryInstructions(String instructions)
    {
      waitForWebElementPresent(enterDeliveryInstructions, getTimeOut());
      Assert.assertTrue(enterDeliveryInstructions.isDisplayed());
      enterDeliveryInstructions.click();
      enterDeliveryInstructions.clear();
      enterDeliveryInstructions.sendKeys(instructions);
      return PageFactory.initElements(driver, AddEditAddressPage.class);
    }
	
	public AddEditAddressPage clickToSelectAddress()
    {
        String xpath = "//font[text() = 'Bradford, BD9 4NP']";
        WebElement ele = driver.findElement(byLocator(xpath));
        waitForWebElementPresent(ele, getTimeOut());
        Assert.assertTrue(ele.isDisplayed());
        ele.click();
        _waitForPageLoad(driver);
        //_waitForJStoLoad();
        return PageFactory.initElements(driver, AddEditAddressPage.class);
    }
	
	public AddEditAddressPage enterAddressToBeSearch(String address)
    {
      waitForWebElementPresent(enterAddressToBeSearch, getTimeOut());
      Assert.assertTrue(enterAddressToBeSearch.isDisplayed());
      enterAddressToBeSearch.click();
      enterAddressToBeSearch.clear();
      enterAddressToBeSearch.sendKeys(address);
      _waitForPageLoad(driver);
      return PageFactory.initElements(driver, AddEditAddressPage.class);
    }
	
	public AddressBookPage clickOnSaveAddressButton()
	{
		waitForWebElementPresent(saveAddressButton, getTimeOut());
		Assert.assertTrue(saveAddressButton.isDisplayed());
		saveAddressButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, AddressBookPage.class);
	}
	
	public AddEditAddressPage selectDefaultAddressCheckBox()
	{
		waitForWebElementPresent(defaultAddressCheckBox, getTimeOut());
		Assert.assertTrue(defaultAddressCheckBox.isDisplayed());
		defaultAddressCheckBox.click();
		return PageFactory.initElements(driver, AddEditAddressPage.class);
	}
	
	public AddEditAddressPage enterContactNumber(String value)
	{
		waitForWebElementPresent(contactNumber, getTimeOut());
		scrollToElementView(contactNumber);
		Assert.assertTrue(contactNumber.isDisplayed());
		contactNumber.clear();
		contactNumber.sendKeys(value);
		return PageFactory.initElements(driver, AddEditAddressPage.class);
	}
	
	public AddEditAddressPage enterContactName(String value)
	{
		waitForWebElementPresent(contactName, getTimeOut());
		scrollToElementView(contactName);
		Assert.assertTrue(contactName.isDisplayed());
		contactName.clear();
		contactName.sendKeys(value);
		return PageFactory.initElements(driver, AddEditAddressPage.class);
	}
	
	public AddEditAddressPage enterPostCode(String value)
    {
        waitForWebElementPresent(postCode, getTimeOut());
        scrollToElementView(postCode);
        Assert.assertTrue(postCode.isDisplayed());
        postCode.clear();
        postCode.sendKeys(value);
        return PageFactory.initElements(driver, AddEditAddressPage.class);
    }
    
    public AddEditAddressPage enterCityTown(String value)
    {
        waitForWebElementPresent(cityTown, getTimeOut());
        scrollToElementView(cityTown);
        Assert.assertTrue(cityTown.isDisplayed());
        cityTown.clear();
        cityTown.sendKeys(value);
        return PageFactory.initElements(driver, AddEditAddressPage.class);
    }
    
    public AddEditAddressPage enterAddressL1(String address)
    {
    	
        waitForWebElementPresent(addressL1, getTimeOut());
        scrollToElementView(addressL1);
        Assert.assertTrue(addressL1.isDisplayed());
        addressL1.clear();
        addressL1.sendKeys(address);
        return PageFactory.initElements(driver, AddEditAddressPage.class);
    }

}
