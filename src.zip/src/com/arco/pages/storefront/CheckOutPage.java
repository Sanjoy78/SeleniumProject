package com.arco.pages.storefront;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class CheckOutPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//button[@id='savePaymentInfoCart']")
	private WebElement useThesePaymentDetailsButton;
	
	@FindBy(how=How.XPATH, using="//a[contains(@href,'checkout')]")
	private WebElement placeOrderButton;
	
	@FindBy(how=How.XPATH, using="//*[@class='btn btn-primary checkoutBasket']")
    private WebElement placeOrderButtonForAnonymousUser;
	
	@FindBy(how=How.XPATH, using="//select[@id='country']")
    private WebElement selectcountry;
    
    @FindBy(how=How.XPATH, using="//input[@id='searchAddress']")
    private WebElement enteraddressbox;
    
    @FindBy(how=How.XPATH, using="//input[@id='contactName']")
    private WebElement entercontactname;
    
    @FindBy(how=How.XPATH, using="//input[@id='phone']")
    private WebElement entercontactnumber;
    
    @FindBy(how=How.XPATH, using="//input[contains(@name,'terms')]")
    private WebElement checkBoxForTC;
    
    @FindBy(how=How.XPATH, using="//input[@id='addressLine1']")
    private WebElement addressL1;
    
    @FindBy(how=How.XPATH, using="//input[@id='city']")
    private WebElement cityTown;
    
    @FindBy(how=How.XPATH, using="//input[@id='postcode']")
    private WebElement postCode;
    
    @FindBy(how=How.XPATH, using="//a[@class='changeBtn deliveryChange']")
    private WebElement clickOnChangeButton;
    
    @FindBy(how=How.XPATH, using="//a[@id='useAddressBtn']")
    private WebElement clickOnUseDifferentAddressButton;
    
    @FindBy(how=How.XPATH, using="//a[@id='allData']")
    private WebElement clickOnEditAddressButton;
    
    @FindBy(how=How.XPATH, using="//*[text()='John Medley']")
    private WebElement clickOnSearchAddressCheckBox;
    
    @FindBy(how=How.XPATH, using="//button[@id='updateUserAddressBtn']")
    private WebElement clickOnSelectupdateUserAddressButton;
    
    @FindBy(how=How.XPATH, using="//input[@id='Set as default address']")
    private WebElement clickOnMakeThisDefaultCheckBox;
    
    @FindBy(how=How.XPATH, using="//textarea[@id='descriptionDeliveryAddr']")
    private WebElement enterDeliveryInstructionsBox;
    
    @FindBy(how=How.XPATH, using="//button[text()='Use these delivery details']")
    private WebElement clickOnUsetheseDeliveryDetailsButton;
    
    @FindBy(how=How.XPATH, using="//button[text()='Use this Address']")
    private WebElement useThisAddressButton;
    
    @FindBy(how=How.XPATH, using="//input[@id='searchUserRoleList']")
    private WebElement enterSearchAddressesBox;
    
    @FindBy(how=How.XPATH, using="//a[@class='addNewAdd ']")
    private WebElement addNewAddressButton;
    
    @FindBy(how=How.XPATH, using="//button[text()='Use these delivery details']")
    private WebElement useTheseDeliveryDetailsButton;
    
    public CheckOutPage(final WebDriver driver)
	{
		super(driver);
	}
    
    public CheckOutPage clickOnUseTheseDeliveryDetailsButton() throws Exception
    {
    	waitForWebElementPresent(useTheseDeliveryDetailsButton, getTimeOut());
    	scrollToElementView(useTheseDeliveryDetailsButton);
    	useTheseDeliveryDetailsButton.click();
    	Thread.sleep(10000);
    	return PageFactory.initElements(driver, CheckOutPage.class);
    }
    
    public CheckOutPage clickOnAddNewAddressButton()
    {
    	waitForWebElementPresent(addNewAddressButton, getTimeOut());
    	Assert.assertTrue(addNewAddressButton.isDisplayed());
    	addNewAddressButton.click();

    	return PageFactory.initElements(driver, CheckOutPage.class);
    }
    
    public CheckOutPage clickOnSearchedAddress(String addressName)
    {
    	String xpath = "//*[text()='"+addressName+"']";
    	WebElement ele = driver.findElement(byLocator(xpath));
    	waitForWebElementPresent(ele, getTimeOut());
    	
    	Assert.assertTrue(ele.isDisplayed());
    	ele.click();

    	return PageFactory.initElements(driver, CheckOutPage.class);
    	
    }
    
	
	public CheckOutPage clickOnUsetheseDeliveryDetails()
    {
        waitForWebElementPresent(clickOnUsetheseDeliveryDetailsButton, getTimeOut());
        scrollToElementView(clickOnUsetheseDeliveryDetailsButton);
        Assert.assertTrue(clickOnUsetheseDeliveryDetailsButton.isDisplayed());
        clickOnUsetheseDeliveryDetailsButton.click();

        return PageFactory.initElements(driver, CheckOutPage.class);
    }
	
	public CheckOutCardPaymentPage clickOnPlaceOrderButtonforAnonymous()
    {
       waitForWebElementPresent(placeOrderButtonForAnonymousUser, getTimeOut());
       waitForElementToBeClickable(placeOrderButtonForAnonymousUser, getTimeOut());
      scrollToElementView(placeOrderButtonForAnonymousUser);
       Assert.assertTrue(placeOrderButtonForAnonymousUser.isDisplayed());
       placeOrderButtonForAnonymousUser.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);
    }
	
	public CheckOutPage clickOnUseThesePaymentDetailsButton() throws Exception
	{
		waitForWebElementPresent(useThesePaymentDetailsButton, getTimeOut());
		scrollToElementView(useThesePaymentDetailsButton);
		Assert.assertTrue(useThesePaymentDetailsButton.isDisplayed());
		useThesePaymentDetailsButton.click();
		Thread.sleep(10000);
		return PageFactory.initElements(driver, CheckOutPage.class);
	}
	

	
	public OrderConfirmationPage clickOnPlaceOrderButton()
	{
		waitForWebElementPresent(placeOrderButton, getTimeOut());
		scrollToElementView(placeOrderButton);
		Assert.assertTrue(placeOrderButton.isDisplayed());
		placeOrderButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, OrderConfirmationPage.class);
	}
	
	public CheckOutPage enterPostCode(String value)
    {
        waitForWebElementPresent(postCode, getTimeOut());
        scrollToElementView(postCode);
        Assert.assertTrue(postCode.isDisplayed());
        postCode.clear();
        postCode.sendKeys(value);

        return PageFactory.initElements(driver, CheckOutPage.class);
    }
    
    public CheckOutPage enterCityTown(String value)
    {
        waitForWebElementPresent(cityTown, getTimeOut());
        scrollToElementView(cityTown);
        Assert.assertTrue(cityTown.isDisplayed());
        cityTown.clear();
        cityTown.sendKeys(value);
        
        return PageFactory.initElements(driver, CheckOutPage.class);
    }
    
    public CheckOutPage enterAddressL1(String address)
    {
        waitForWebElementPresent(addressL1, getTimeOut());
        scrollToElementView(addressL1);
        Assert.assertTrue(addressL1.isDisplayed());
        addressL1.clear();
        addressL1.sendKeys(address);

        return PageFactory.initElements(driver, CheckOutPage.class);
    }
    
    public CheckOutPage clickOnCheckBoxForTC()
    {
        
       //waitForWebElementPresent(checkBoxForTC, getTimeOut());
        //Assert.assertTrue(checkBoxForTC.isDisplayed());
    	scrollToElementView(checkBoxForTC);
       // Actions builder = new Actions(driver);
        //builder.moveToElement(checkBoxForTC).click().build().perform();
    	checkBoxForTC.click();
        _waitForJStoLoad();
        return PageFactory.initElements(driver, CheckOutPage.class);
    }
    
    
  public CheckOutPage selectCountry(String value)
   {
       waitForWebElementPresent(selectcountry, getTimeOut());
       scrollToElementView(selectcountry);
       Assert.assertTrue(selectcountry.isDisplayed());
       Select sel1 = new Select(selectcountry);
       sel1.selectByValue(value);
       return PageFactory.initElements(driver, CheckOutPage.class);
      
   }
    
 
   public CheckOutPage enteraddressinaddressbox(String address)
   {
       waitForWebElementPresent(enteraddressbox, getTimeOut());
       Assert.assertTrue(enteraddressbox.isDisplayed());
       enteraddressbox.clear();
       enteraddressbox.sendKeys(address);
       return PageFactory.initElements(driver, CheckOutPage.class);
    }
  
   public CheckOutPage enterContactName(String contactname)
   {
       waitForWebElementPresent(entercontactname, getTimeOut());
       scrollToElementView(entercontactname);
       Assert.assertTrue(entercontactname.isDisplayed());
       entercontactname.sendKeys(contactname);
       return PageFactory.initElements(driver, CheckOutPage.class);
    }
  
   public CheckOutPage enterContactPhoneNumber(String contactnumber)
   {
       waitForWebElementPresent(entercontactnumber, getTimeOut());
       scrollToElementView(entercontactnumber);
       Assert.assertTrue(entercontactnumber.isDisplayed());
       entercontactnumber.sendKeys(contactnumber);
       return PageFactory.initElements(driver, CheckOutPage.class);
    }
   
   public CheckOutPage clickOnUsethisAddress() throws Exception
   {
       waitForWebElementPresent(useThisAddressButton, getTimeOut());
       scrollToElementView(useThisAddressButton);
       Assert.assertTrue(useThisAddressButton.isDisplayed());
       
       useThisAddressButton.click();
       Thread.sleep(10000);
       return PageFactory.initElements(driver, CheckOutPage.class);
   }

   public CheckOutPage clickOnChange()
   {
       waitForWebElementPresent(clickOnChangeButton, getTimeOut());
       scrollToElementView(clickOnChangeButton);
       Assert.assertTrue(clickOnChangeButton.isDisplayed());
       clickOnChangeButton.click();
       return PageFactory.initElements(driver, CheckOutPage.class);
   }
   
   public CheckOutPage clickOnUseDifferentAddress()
   {
       waitForWebElementPresent(clickOnUseDifferentAddressButton, getTimeOut());
       scrollToElementView(clickOnUseDifferentAddressButton);
       Assert.assertTrue(clickOnUseDifferentAddressButton.isDisplayed());
       clickOnUseDifferentAddressButton.click();
      
       return PageFactory.initElements(driver, CheckOutPage.class);
   }

   public CheckOutPage clickOnEditAddress()
   {
       waitForWebElementPresent(clickOnEditAddressButton, getTimeOut());
       scrollToElementView(clickOnEditAddressButton);
       Assert.assertTrue(clickOnEditAddressButton.isDisplayed());
       clickOnEditAddressButton.click();

       return PageFactory.initElements(driver, CheckOutPage.class);
   }
   
   public CheckOutPage searchAddressesBox(String address)
   {
          waitForWebElementPresent(enterSearchAddressesBox, getTimeOut());
          Assert.assertTrue(enterSearchAddressesBox.isDisplayed());
          enterSearchAddressesBox.click();
          enterSearchAddressesBox.clear();
          enterSearchAddressesBox.sendKeys(address);
          return PageFactory.initElements(driver, CheckOutPage.class);
   }
     
   public CheckOutPage clickOnSearchCheckBox()
   {
       //waitForWebElementPresent(clickOnSearchAddressCheckBox, getTimeOut());
       //Assert.assertTrue(clickOnSearchAddressCheckBox.isDisplayed());
       _clickUsingJavaScript(clickOnSearchAddressCheckBox);

       return PageFactory.initElements(driver, CheckOutPage.class);
   }
   
   public CheckOutPage clickOnSelectUpdateUserAddress()
   {
       waitForWebElementPresent(clickOnSelectupdateUserAddressButton, getTimeOut());
       scrollToElementView(clickOnSelectupdateUserAddressButton);
       Assert.assertTrue(clickOnSelectupdateUserAddressButton.isDisplayed());
       clickOnSelectupdateUserAddressButton.click();

       return PageFactory.initElements(driver, CheckOutPage.class);
   }
   
   public CheckOutPage clickOnMakeDefaultAddress()
   {
       //waitForWebElementPresent(clickOnSearchAddressCheckBox, getTimeOut());
       //Assert.assertTrue(clickOnSearchAddressCheckBox.isDisplayed());
       _clickUsingJavaScript(clickOnMakeThisDefaultCheckBox);

        return PageFactory.initElements(driver, CheckOutPage.class);
    }
   
   public CheckOutPage enterDeliveryInstructions(String instructions)
   {
          waitForWebElementPresent(enterDeliveryInstructionsBox, getTimeOut());
          Assert.assertTrue(enterDeliveryInstructionsBox.isDisplayed());
          enterDeliveryInstructionsBox.click();
          enterDeliveryInstructionsBox.clear();
          enterDeliveryInstructionsBox.sendKeys(instructions);
          return PageFactory.initElements(driver, CheckOutPage.class);
   }
}
