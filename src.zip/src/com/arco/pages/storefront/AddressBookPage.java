package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;



public class AddressBookPage extends ArcoDriverHelper
{
	
	@FindBy(how=How.XPATH, using="//a[@href='add-address']")
	private WebElement addNewAddressButton;
	
	@FindBy(how=How.XPATH, using="//a[contains(@class,'btn btn-primary addAddressButton')]")
    private WebElement clickAddNewAddress;
	
	@FindBy(how=How.XPATH, using="//input[@id='searchAddressBookListView']")
    private WebElement enterAddressToBeSearch;
	
	@FindBy(how=How.XPATH, using="//span[@id='dropdownMenu1']")
    private WebElement clickOnThreeDot;
	
	@FindBy(how=How.XPATH, using="//a[text() = 'Edit']")
    private WebElement clickOnEdit;
	
	@FindBy(how=How.XPATH, using="//a[text() = 'Delete']")
    private WebElement clickOnDelete;
	
	public AddressBookPage (final WebDriver driver)
	{
		super(driver);
	}
	
	public AddEditAddressPage clickOnDeleteButton()
    {
        waitForWebElementNotPresent(clickOnDelete, getTimeOut());
        Assert.assertTrue(clickOnDelete.isDisplayed());
        clickOnDelete.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, AddEditAddressPage.class);
    }
	
	public AddEditAddressPage clickOnEditButton()
    {
        waitForWebElementNotPresent(clickOnEdit, getTimeOut());
        Assert.assertTrue(clickOnEdit.isDisplayed());
        clickOnEdit.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, AddEditAddressPage.class);
        
    }
	
	public AddressBookPage clickOnThreeDotForAnAddress()
    {
        waitForWebElementNotPresent(clickOnThreeDot, getTimeOut());
        Assert.assertTrue(clickOnThreeDot.isDisplayed());
        clickOnThreeDot.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, AddressBookPage.class);
    }
	
	public Boolean isDefaultAddressIndicator()
    {
        return isElementPresent("//b[text() = '(Default address)']");
    }
	
	public AddressBookPage enterAddressToBeSearch(String address)
    {
        waitForWebElementNotPresent(enterAddressToBeSearch, getTimeOut());
        Assert.assertTrue(enterAddressToBeSearch.isDisplayed());
        enterAddressToBeSearch.click();
        enterAddressToBeSearch.clear();
        enterAddressToBeSearch.sendKeys(address);
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, AddressBookPage.class);
    }
	
	public AddEditAddressPage clickAddNewAddressButton()
    {
        waitForWebElementNotPresent(clickAddNewAddress, getTimeOut());
        Assert.assertTrue(clickAddNewAddress.isDisplayed());
        clickAddNewAddress.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, AddEditAddressPage.class);
    }
	
	public AddressBookPage clickOnDotsForAnAddress(String addressName)
	{
		String locator = "//span[text()='"+addressName+"']/following::span[@id='dropdownMenu1']";
		waitForElementPresent(locator, getTimeOut());
		scrollToElementView(driver.findElement(byLocator(locator)));
		Assert.assertTrue(driver.findElement(byLocator(locator)).isDisplayed());
		driver.findElement(byLocator(locator)).click();
		return PageFactory.initElements(driver, AddressBookPage.class);
	}
	
	public AddEditAddressPage clickOnEditForAnAddress(String addressName)
	{
		String locator = "//span[text()='"+addressName+"']/following::a[@title='Edit']";
		waitForElementPresent(locator, getTimeOut());
		scrollToElementView(driver.findElement(byLocator(locator)));
		Assert.assertTrue(driver.findElement(byLocator(locator)).isDisplayed());
		driver.findElement(byLocator(locator)).click();
		return PageFactory.initElements(driver, AddEditAddressPage.class);
		
	}
	
	public AddEditAddressPage clickOnDeleteForAnAddress(String addressName)
	{
		String locator = "//span[text()='"+addressName+"']/following::a[contains(@href,'remove-address')][2]";
		waitForElementPresent(locator, getTimeOut());
		scrollToElementView(driver.findElement(byLocator(locator)));
		Assert.assertTrue(driver.findElement(byLocator(locator)).isDisplayed());
		driver.findElement(byLocator(locator)).click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, AddEditAddressPage.class);
		
	}
	
	public AddEditAddressPage clickOnAddNewAddressButton()
	{
		waitForWebElementPresent(addNewAddressButton, getTimeOut());
		Assert.assertTrue(addNewAddressButton.isDisplayed());
		addNewAddressButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, AddEditAddressPage.class);
	}

}
