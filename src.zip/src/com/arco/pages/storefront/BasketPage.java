package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class BasketPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="(//button[@data-checkout-url='/cart/checkout'])[1]")
	private WebElement checkOutButton;
	
	@FindBy(how=How.XPATH, using="//input[contains(@class,'purchaseOrderNumber')]")
	private WebElement purchaseOrderNumberBox;
	
	@FindBy(how=How.XPATH, using="//span[text()='VAT:']")
	private WebElement vatButton;
	
	@FindBy(how=How.XPATH, using="//a[@title='Select position']")
    private WebElement selectPosition;
	
	@FindBy(how=How.XPATH, using="//input[@id='RIGHT COLLAR']")
    private WebElement rightCollarPosition;
	
	@FindBy(how=How.XPATH, using="//a[@title='Select decoration style']")
    private WebElement selectDecorationStyle;
	
	@FindBy(how=How.XPATH, using="//input[@id='TEXT']")
    private WebElement embroideryTextRadioButton;
	
	@FindBy(how=How.XPATH, using="//select[@id='fontStyle']")
    private WebElement selectFontStyle;
	
	@FindBy(how=How.XPATH, using="//select[@id='fontSize']")
    private WebElement selectFontSize;
	
	@FindBy(how=How.XPATH, using="//span[text() = 'Select colour']")
    private WebElement selectColor;
	
	@FindBy(how=How.XPATH, using="//input[@id='textDeco']")
    private WebElement text;
	
	@FindBy(how=How.XPATH, using="//a[@id='closeDecoration']")
    private WebElement doneCloseDecoration;
	
	@FindBy(how=How.XPATH, using="//button[@class='btn btn-primary saveDecoration ']")
	private WebElement saveButton;
	
	@FindBy(how=How.XPATH, using="(//span[text()='Order total:'])[1]")
	private WebElement orderTotalText;
	
	String xpathForOrderTotalText = "//span[text() = 'Order total:']";
	
	public BasketPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public BasketPage clickOnOrderTotalText()
	{
		waitForWebElementPresent(orderTotalText, getTimeOut());
		scrollToElementView(orderTotalText);
		Assert.assertTrue(orderTotalText.isDisplayed());
		orderTotalText.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, BasketPage.class);
	}
	
	public Boolean isSaveButtonEnable()
	{
		boolean result;
		System.out.println(saveButton.isEnabled());
		if(saveButton.isEnabled())
		{
			result = true;
		} else
		{
			result = false;
		}
		return result;
	}
	
	public BasketPage clickOnRemoveButtonForASKU(String skuId)
	{
		String locator = "//a[@title='product.item.text.remove.item' and @id='"+skuId+"']";
		WebElement ele = driver.findElement(byLocator(locator));
		scrollToElementView(ele);
		Assert.assertTrue(ele.isDisplayed());
		ele.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, BasketPage.class);
	}
	
	public BasketPage clickOnDoneAfterDecoration()
    {
        waitForWebElementPresent(doneCloseDecoration, getTimeOut());
        Assert.assertTrue(doneCloseDecoration.isDisplayed());
        doneCloseDecoration.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, BasketPage.class);
    }
	
	public BasketPage clickOnSaveAfterDecoration(String skuId)
    {
        String locator = "(//button[@data-productcode = '"+skuId+"'])[3]";
        waitForElementPresent(locator, getTimeOut());
        driver.findElement(byLocator(locator)).click();
        return PageFactory.initElements(driver, BasketPage.class);
    }
	
	public BasketPage enterText(String textData)
    {
        waitForWebElementPresent(text, getTimeOut());
        Assert.assertTrue(text.isDisplayed());
        text.click();
        text.clear();
        text.sendKeys(textData);
        return PageFactory.initElements(driver, BasketPage.class);
    }
	
	public BasketPage selectColour(String colour)
    {
        String locator = "//li[@id='"+colour+"']/span";
        waitForElementPresent(locator, getTimeOut());
        driver.findElement(byLocator(locator)).click();
        return PageFactory.initElements(driver, BasketPage.class);
    }
	
	public BasketPage clickToSelectFontSizeFromDropdownList(String fontSize)
    {
        waitForWebElementPresent(selectFontSize, getTimeOut());
        Assert.assertTrue(selectFontSize.isDisplayed());
        selectDropDown(selectFontSize, fontSize);
        return PageFactory.initElements(driver, BasketPage.class);
    }
	
	public BasketPage clickToSelectColorButton()
    {
        waitForWebElementPresent(selectColor, getTimeOut());
        Assert.assertTrue(selectColor.isDisplayed());
        selectColor.click();
        return PageFactory.initElements(driver, BasketPage.class);
    }
	
	public BasketPage clickToSelectFontStyleFromDropdownList(String fontStyle)
    {
        waitForWebElementPresent(selectFontStyle, getTimeOut());
        Assert.assertTrue(selectFontStyle.isDisplayed());
        selectDropDown(selectFontStyle, fontStyle);
        return PageFactory.initElements(driver, BasketPage.class);
    }
	
	public BasketPage clickOnEmbroideryTextRadioButton()
    {
        waitForWebElementPresent(embroideryTextRadioButton, getTimeOut());
        Assert.assertTrue(embroideryTextRadioButton.isDisplayed());
        embroideryTextRadioButton.click();
        return PageFactory.initElements(driver, BasketPage.class);
    }
	
	public BasketPage selectPosition(String position)
    {
        String locator = "//input[@id='"+position+"']";
        waitForElementPresent(locator, getTimeOut());
        driver.findElement(byLocator(locator)).click();
        return PageFactory.initElements(driver, BasketPage.class);
    }
	
	public BasketPage clickOnSelectDecorationStyleButton()
    {
        waitForWebElementPresent(selectDecorationStyle, getTimeOut());
        Assert.assertTrue(selectDecorationStyle.isDisplayed());
        selectDecorationStyle.click();
        return PageFactory.initElements(driver, BasketPage.class);
    }
	
	public BasketPage selectRightCollarPosition()
    {
        waitForWebElementPresent(rightCollarPosition, getTimeOut());
        Assert.assertTrue(rightCollarPosition.isDisplayed());
        rightCollarPosition.click();
        return PageFactory.initElements(driver, BasketPage.class);
    }
	
	public BasketPage clickOnApplyDecorationLink(String skuId)
    {
        String locator = "//a[@id='decorationLink-"+skuId+"']";
        scrollToElementView(driver.findElement(byLocator(locator)));
        waitForElementPresent(locator, getTimeOut());
        driver.findElement(byLocator(locator)).click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, BasketPage.class);
    }
	
	public BasketPage clickOnSelectPositionButton()
    {
        waitForWebElementPresent(selectPosition, getTimeOut());
        Assert.assertTrue(selectPosition.isDisplayed());
        selectPosition.click();
        return PageFactory.initElements(driver, BasketPage.class);
    }
	
	public BasketPage clickOnVATText()
	{
		waitForWebElementPresent(vatButton, getTimeOut());
		Assert.assertTrue(vatButton.isDisplayed());
		vatButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, BasketPage.class);
	}
	
	
	
	public BasketPage enterPurchaseOrderNumber(String oredrNumber)
	{
		
		waitForWebElementPresent(purchaseOrderNumberBox, getTimeOut());
		scrollToElementView(purchaseOrderNumberBox);
		Assert.assertTrue(purchaseOrderNumberBox.isDisplayed());
		purchaseOrderNumberBox.clear();
		purchaseOrderNumberBox.sendKeys(oredrNumber);
		return PageFactory.initElements(driver, BasketPage.class);
	}
	
	public CheckOutPage clickOnCheckOutButton()
	{
		waitForWebElementPresent(checkOutButton, getTimeOut());
		scrollToElementView(checkOutButton);
		Assert.assertTrue(checkOutButton.isDisplayed());
		checkOutButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, CheckOutPage.class);
	}
	
	public EmailConfirmationPage clickOnCheckOutButtonforAnonymousUser()
    {
		
        waitForWebElementPresent(checkOutButton, getTimeOut());
        scrollToElementView(checkOutButton);
        Assert.assertTrue(checkOutButton.isDisplayed());
        checkOutButton.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, EmailConfirmationPage.class);
        
        
    }

}
