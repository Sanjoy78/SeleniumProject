package com.arco.pages.storefront;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.arco.util.ArcoDriverHelper;

public class UserManagementPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//button[text()='Create User']")
	private WebElement createUserButton;
	
	@FindBy(how=How.ID, using="titleCode")
	private WebElement title;
	
	@FindBy(how=How.ID, using="firstName")
	private WebElement firstName;
	
	@FindBy(how=How.ID, using="lastName")
	private WebElement lastName;
	
	@FindBy(how=How.ID, using="email")
	private WebElement emailID;
	
	@FindBy(how=How.ID, using="phoneNumber")
	private WebElement phoneNumber;
	
	@FindBy(how=How.ID, using="jobTitle")
	private WebElement jobTitle;
	
	@FindBy(how=How.ID, using="userAccountNumber")
	private WebElement orgUnit;
	
	@FindBy(how=How.ID, using="userRole")
	private WebElement userRole;
	
	@FindBy(how=How.XPATH, using="//label[@for='issueRegistrationEmailImmediatelyYes']")
	private WebElement nowRadioButton;
	
	@FindBy(how=How.XPATH, using="//button[@id='createAccountBtn']")
	private WebElement createButton;
	
	@FindBy(how=How.XPATH, using="//input[@id='searchusers']")
	private WebElement searchUserBox;
	
	@FindBy(how=How.XPATH, using="//a[contains(@href,'/my-account/user-management/user')]")
	private WebElement user;
	
	@FindBy(how=How.XPATH, using="(//input[@name='searchusers'])[1]")
    private WebElement searchUsersBox;
	
	@FindBy(how=How.XPATH, using="//button[text()='Send reminder']")
    private WebElement sendReminderButton;
	
	@FindBy(how=How.XPATH, using="//a[@id='editCrmNumber']")
    private WebElement editCRMSyncButton;
	
	@FindBy(how=How.XPATH, using="//input[@id='crmContactNumber']")
    private WebElement enterCRMContactIDBox;
	
	@FindBy(how=How.XPATH, using="//button[@id='editSaveCrm']")
    private WebElement clickOnSaveButtonInEditCRMSync;
	
	public UserManagementPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public UserManagementPage clickOnCreateButton()
	{
		waitForWebElementPresent(createButton, getTimeOut());
		scrollToElementView(createButton);
		Assert.assertTrue(createButton.isDisplayed());
		createButton.click();
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage clickOnSaveButtonInEditCRMSync()
    {
        waitForWebElementPresent(clickOnSaveButtonInEditCRMSync, getTimeOut());
        Assert.assertTrue(clickOnSaveButtonInEditCRMSync.isDisplayed());
        clickOnSaveButtonInEditCRMSync.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, UserManagementPage.class);
    }
	
	public UserManagementPage enterCRMContactID(String crmContactID)
    {
        waitForWebElementPresent(enterCRMContactIDBox, getTimeOut());
        Assert.assertTrue(enterCRMContactIDBox.isDisplayed());
        enterCRMContactIDBox.clear();
        enterCRMContactIDBox.sendKeys(crmContactID);
        return PageFactory.initElements(driver, UserManagementPage.class);
    }
	
	public Boolean isUserStatusIndicator(String userId)
    {
        return isElementPresent("//span[@id='"+userId+"']");
    }
	
	public UserManagementPage clickOnEditCRMSyncButton()
    {
		scrollToElementView(editCRMSyncButton);
        waitForWebElementPresent(editCRMSyncButton, getTimeOut());
        Assert.assertTrue(editCRMSyncButton.isDisplayed());
        editCRMSyncButton.click();
        return PageFactory.initElements(driver, UserManagementPage.class);
    }
	
	public UserManagementPage clickOnUser(String accountID)
    {
        String xpath = "//li[@data-id='"+accountID+"']/div[1]/div[2]/a";
        WebElement ele = driver.findElement(byLocator(xpath));
        waitForWebElementPresent(ele, getTimeOut());
        Assert.assertTrue(ele.isDisplayed());
        ele.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, UserManagementPage.class);
    }
    
    public UserManagementPage clickOnSendReminderButton()
    {
    	scrollToElementView(sendReminderButton);
        waitForWebElementPresent(sendReminderButton, getTimeOut());
        Assert.assertTrue(sendReminderButton.isDisplayed());
        sendReminderButton.click();
        return PageFactory.initElements(driver, UserManagementPage.class);
    }
    
	public UserManagementPage clickOnDeauthoriseToPurchaseButton(String accountID)
    {
        String xpath = "//a[@data-user='"+accountID+"']";
        WebElement ele = driver.findElement(byLocator(xpath));
        waitForWebElementPresent(ele, getTimeOut());
        scrollToElementView(ele);
        Assert.assertTrue(ele.isDisplayed());
        ele.click();
        return PageFactory.initElements(driver, UserManagementPage.class);
    }
	
	public UserManagementPage clickOnAuthoriseToPurchaseButton(String accountID)
    {
        String xpath = "//a[@data-user='"+accountID+"']";
        WebElement ele = driver.findElement(byLocator(xpath));
        waitForWebElementPresent(ele, getTimeOut());
        Assert.assertTrue(ele.isDisplayed());
        ele.click();
        return PageFactory.initElements(driver, UserManagementPage.class);
    }
	
	public UserManagementPage clickOndotButtonForUser(String accountID)
    {
        String xpath = "//li[@data-id='"+accountID+"']/div[2]/div/span";
        WebElement ele = driver.findElement(byLocator(xpath));
        waitForWebElementPresent(ele, getTimeOut());
        scrollToElementView(ele);
        Assert.assertTrue(ele.isDisplayed());
        ele.click();
        return PageFactory.initElements(driver, UserManagementPage.class);
    }
	
	public UserManagementPage enterSearchUsersBox(String custAdminID)
    {
        waitForWebElementPresent(searchUsersBox, getTimeOut());
        Assert.assertTrue(searchUsersBox.isDisplayed());
        searchUsersBox.clear();
        searchUsersBox.sendKeys(custAdminID);
        return PageFactory.initElements(driver, UserManagementPage.class);
    }
	
	public UserManagementPage enterUserDetailsInSearchBox(String userDetails)
    {
        waitForWebElementPresent(searchUsersBox, getTimeOut());
        scrollToElementView(searchUsersBox);
        Assert.assertTrue(searchUsersBox.isDisplayed());
        searchUsersBox.clear();
        searchUsersBox.sendKeys(userDetails);
        return PageFactory.initElements(driver, UserManagementPage.class);
    }
	
	public UserDetailsPage clickOnUser()
	{
		waitForWebElementPresent(user, getTimeOut());
		Assert.assertTrue(user.isDisplayed());
		user.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, UserDetailsPage.class);
	}
	
	public UserManagementPage searchUser(String user)
	{
		waitForWebElementPresent(searchUserBox, getTimeOut());
		Assert.assertTrue(searchUserBox.isDisplayed());
		searchUserBox.clear();
		searchUserBox.sendKeys(user);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage selectNowRadioButton()
	{
		waitForWebElementPresent(nowRadioButton, getTimeOut());
		Assert.assertTrue(nowRadioButton.isDisplayed());
		nowRadioButton.click();
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage enterJobTitle(String title)
	{
		waitForWebElementPresent(jobTitle, getTimeOut());
		Assert.assertTrue(jobTitle.isDisplayed());
		jobTitle.clear();
		jobTitle.sendKeys(title);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage enterPhoneNumber(String number)
	{
		waitForWebElementPresent(phoneNumber, getTimeOut());
		Assert.assertTrue(phoneNumber.isDisplayed());
		phoneNumber.clear();
		phoneNumber.sendKeys(number);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage enterEmailAddress(String emailAddress)
	{
		waitForWebElementPresent(emailID, getTimeOut());
		Assert.assertTrue(emailID.isDisplayed());
		emailID.clear();
		emailID.sendKeys(emailAddress);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage enterFirstName(String name)
	{
		waitForWebElementPresent(firstName, getTimeOut());
		Assert.assertTrue(firstName.isDisplayed());
		firstName.clear();
		firstName.sendKeys(name);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage enterSurname(String surname)
	{
		waitForWebElementPresent(lastName, getTimeOut());
		Assert.assertTrue(lastName.isDisplayed());
		lastName.clear();
		lastName.sendKeys(surname);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage clickOnCreateUserButton()
	{
		waitForWebElementPresent(createUserButton, getTimeOut());
		scrollToWebElement(createUserButton);
		Assert.assertTrue(createUserButton.isDisplayed());
		createUserButton.click();
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage selectOrgUnit(String value)
	{
		scrollToElementView(orgUnit);
		selectDropDown(orgUnit, value);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage selectUserRole(String vaule)
	{
		scrollToElementView(userRole);
		selectDropDown(userRole, vaule);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}
	
	public UserManagementPage selectTitle(String value)
	{
		selectDropDown(title, value);
		return PageFactory.initElements(driver, UserManagementPage.class);
	}

}
