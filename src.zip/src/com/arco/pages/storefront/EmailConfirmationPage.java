package com.arco.pages.storefront;

import com.arco.util.ArcoDriverHelper;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;



public class EmailConfirmationPage extends ArcoDriverHelper
{
	 @FindBy(how=How.XPATH, using="//input[@id='email']")
	    private WebElement emailBox;
	    
	    @FindBy(how=How.XPATH, using="//input[@id='confirmEmail']") 
	    private WebElement confirmemailBox;
	    
	    @FindBy(how=How.XPATH, using="//button[@id='guestUserLogin']")
	    private WebElement checkoutasaguestbutton;
	    
	    
	    public EmailConfirmationPage(final WebDriver driver) {
	        super(driver);
	        }

	    public CheckOutPage clickOnCheckoutAsaGuestButton()
	    {
	        waitForWebElementPresent(checkoutasaguestbutton, getTimeOut());
	        scrollToElementView(checkoutasaguestbutton);
	        Assert.assertTrue(checkoutasaguestbutton.isDisplayed());
	        checkoutasaguestbutton.click();
	        _waitForPageLoad(driver);
	        return PageFactory.initElements(driver, CheckOutPage.class);
	    }
	    
	    public EmailConfirmationPage enterguestEmailIdinemailBox(String emailId)
	    {
	        waitForWebElementPresent(emailBox, getTimeOut());
	        scrollToElementView(emailBox);
	        Assert.assertTrue(emailBox.isDisplayed());
	        emailBox.sendKeys(emailId);
	        return PageFactory.initElements(driver, EmailConfirmationPage.class);
	    }
	    
	    public EmailConfirmationPage enterguestEmailIdinconfirmemailbox(String confirmemailId)
	    {
	        waitForWebElementPresent(confirmemailBox, getTimeOut());
	        scrollToElementView(confirmemailBox);
	        Assert.assertTrue(confirmemailBox.isDisplayed());
	        confirmemailBox.sendKeys(confirmemailId);
	        return PageFactory.initElements(driver, EmailConfirmationPage.class);
	    }

}
