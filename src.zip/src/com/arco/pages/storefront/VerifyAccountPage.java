package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class VerifyAccountPage extends ArcoDriverHelper
{
	@FindBy(how=How.ID, using="arco.b2b.register.postCode")
	private WebElement postCode;
	
	@FindBy(how=How.XPATH, using="//button[@class='btn btn-primary btn-block-user m-b col-sm-4 col-md-4 col-lg-4']")
	private WebElement continueButton_imi;
	
	@FindBy(how=How.XPATH, using="//button[contains(@class,'btn btn-primary full-width m-b col-sm')]")
	private WebElement continueButton_acc;
	
	public VerifyAccountPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public VerifyAccountPage enterPostCode(String postcode)
	{
		waitForWebElementPresent(postCode, getTimeOut());
		Assert.assertTrue(postCode.isDisplayed());
		postCode.sendKeys(postcode);
		return PageFactory.initElements(driver, VerifyAccountPage.class);
	}
	
	public EnterPersonalDetailsPage clickContinueButton_Acc()
	{
		waitForWebElementPresent(continueButton_acc, getTimeOut());
		Assert.assertTrue(continueButton_acc.isDisplayed());
		continueButton_acc.click();
		return PageFactory.initElements(driver, EnterPersonalDetailsPage.class);
	}
	
	public EnterPersonalDetailsPage clickContinueButton_Imi()
	{
		waitForWebElementPresent(continueButton_imi, getTimeOut());
		Assert.assertTrue(continueButton_imi.isDisplayed());
		continueButton_imi.click();
		return PageFactory.initElements(driver, EnterPersonalDetailsPage.class);
	}

}
