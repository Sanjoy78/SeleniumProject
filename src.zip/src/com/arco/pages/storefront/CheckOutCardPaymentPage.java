package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class CheckOutCardPaymentPage extends ArcoDriverHelper
{
	
	@FindBy(how=How.XPATH, using="//input[@title='Your card number']")
    private WebElement enterCardNumberBox;
    
   @FindBy(how=How.XPATH, using="//input[@placeholder='Security Code']")
       private WebElement enterSecurityCodeBox;
    
   @FindBy(how=How.XPATH, using="//input[@id='paymentTCchkBx']")
    private WebElement checkBoxForTC;
    
   @FindBy(how=How.XPATH, using="//iFrame[@name='AFX_POST_101_iframe']")
    private WebElement frame1;
    
   @FindBy(how=How.XPATH, using="//select[@id='edExpMonth']")
    private WebElement selectMonth;
    
   @FindBy(how=How.XPATH, using="//select[@id='edExpYear']")
       private WebElement selectYear;
    
   @FindBy(how=How.XPATH, using="//input[@id='btPayNow']")
       private WebElement selectPaybyCard;
   
   public CheckOutCardPaymentPage(final WebDriver driver) 
   {
       super(driver);
       
   }
   
   public CheckOutCardPaymentPage switchToiFrame()
   {
       switchFrameByFrameIndex(0);
       return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);

  }
   
   public OrderConfirmationPage clickOnSelectPayByCard()
   
   {
        waitForWebElementPresent(selectPaybyCard, getTimeOut());
        scrollToElementView(selectPaybyCard);
        Assert.assertTrue(selectPaybyCard.isDisplayed());
        _clickUsingJavaScript(selectPaybyCard);
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, OrderConfirmationPage .class);
        
    }
    
   
   
   public CheckOutCardPaymentPage enterCardNumber(String cardNumber) throws Exception
    {
        waitForWebElementPresent(enterCardNumberBox, getTimeOut());
        Assert.assertTrue(enterCardNumberBox.isDisplayed());
        enterCardNumberBox.clear();
        enterCardNumberBox.sendKeys(cardNumber);
        Thread.sleep(3000);
        _waitForJStoLoad();
        return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);
    }
    
   public CheckOutCardPaymentPage switchToFrame1()
    {
        waitForWebElementPresent(enterCardNumberBox, getTimeOut());
        Assert.assertTrue(enterCardNumberBox.isDisplayed());
        driver.switchTo().frame(enterCardNumberBox);
        return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);
    }

   public CheckOutCardPaymentPage enterSecurityCode(String securitycode) throws Exception
       {
           waitForWebElementPresent(enterSecurityCodeBox, getTimeOut());
           Assert.assertTrue(enterSecurityCodeBox.isDisplayed());
           enterSecurityCodeBox.clear();
           enterSecurityCodeBox.sendKeys(securitycode);
           Thread.sleep(3000);
           _waitForJStoLoad();
           return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);
       }
    
   public CheckOutCardPaymentPage selectMonthlist(String month) throws Exception
    {
        waitForWebElementPresent(selectMonth, getTimeOut());
        Assert.assertTrue(selectMonth.isDisplayed());
        Select sel1 = new Select(selectMonth);
        sel1.selectByValue(month);
        Thread.sleep(3000);
        _waitForJStoLoad();
        return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);
       
    }
    
   public CheckOutCardPaymentPage selectYearlist(String year) throws Exception
    {
        waitForWebElementPresent(selectYear, getTimeOut());
        Assert.assertTrue(selectYear.isDisplayed());
        Select sel1 = new Select(selectYear);
        sel1.selectByValue(year);
        Thread.sleep(3000);
        _waitForJStoLoad();
        return PageFactory.initElements(driver, CheckOutCardPaymentPage.class);
       
    }

}
