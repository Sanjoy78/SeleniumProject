package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class ProductDetailsPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//input[@name='items[111700]']/following::span[@class='qtyPlus'][1]")
	private WebElement increaseQuantityButton;
	
	@FindBy(how=How.XPATH, using="(//button[@id='addToBasketPdpPage'])[1]")
	private WebElement addToBasketButton;
	
	@FindBy(how=How.XPATH, using="(//a[@href='/cart'])[1]")
	private WebElement checkOutButton;
	
	@FindBy(how=How.XPATH, using="(//span[@class='sku-badgesMsg'])[1]")
	private WebElement skuOf111700;
	
	@FindBy(how=How.XPATH, using="//input[@name='items[111700]']")
	private WebElement quantityBox;
	
	@FindBy(how=How.XPATH, using="//a[contains(@class,'pdp')]")
	private WebElement viewDetails;
	
	@FindBy(how=How.XPATH, using="//button[contains(@class,'btn btn-default js-review-write-toggle')]")
    private WebElement writeAReviewButton;
	
	@FindBy(how=How.XPATH, using="//input[@id='review.headline']")
    private WebElement reviewTitleBox;
	
	@FindBy(how=How.XPATH, using="//textarea[@id='review.comment']")
    private WebElement reviewDescriptionBox;
	
	@FindBy(how=How.XPATH, using="//span[contains(@class,'js-rationIconSet glyphicon glyphicon-star')][10]")
    private WebElement yourRating;
	
	@FindBy(how=How.XPATH, using="//button[text()='Submit Review']")
    private WebElement submitReviewButton;
	
	@FindBy(how=How.XPATH, using="//button[(contains(@class,'btn btn-default addToListBtn btn-block'))]")
    private WebElement addToListButton;
	
	@FindBy(how=How.XPATH, using="//a[text()='Purchase list']")
    private WebElement purchaseListButton;
	
	@FindBy(how=How.XPATH, using="//input[@placeholder='search purchase lists']")
    private WebElement searchPurchaseLists;
	
	@FindBy(how=How.XPATH, using="//button[contains(text(),'Select Products')]")
    private WebElement selectProductsButton;
	
	@FindBy(how=How.XPATH, using="//button[text()='Add to Purchase List']")
    private WebElement addToPurchaseListButton;
	
	@FindBy(how=How.XPATH, using="//button[@id='purchaseListSuccessBtn']")
    private WebElement doneButton;
	
	@FindBy(how=How.XPATH, using="//a[@title='PurchasingList']")
    private WebElement purchaseListLink;

	public ProductDetailsPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public PurchaseListPage clickPurchaseListLink()
    {
        waitForWebElementPresent(purchaseListLink, getTimeOut());
        Assert.assertTrue(purchaseListLink.isDisplayed());
        purchaseListLink.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, PurchaseListPage.class);
    }
	
	public ProductDetailsPage clickOnDoneButtonAfterProductAdd()
    {
        waitForWebElementPresent(doneButton, getTimeOut());
        Assert.assertTrue(doneButton.isDisplayed());
        doneButton.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public ProductDetailsPage clickOnAddToPurchaseListButton()
    {
        waitForWebElementPresent(addToPurchaseListButton, getTimeOut());
        Assert.assertTrue(addToPurchaseListButton.isDisplayed());
        addToPurchaseListButton.click();
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public ProductDetailsPage selectProductCheckbox(String skuId)
    {
        String locator="//input[@value='"+skuId+"']";
        waitForElementPresent(locator, getTimeOut());
        WebElement ele = driver.findElement(byLocator(locator));
        scrollToElementView(ele);
        ele.click();
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public ProductDetailsPage clickOnSelectProducts()
    {
        waitForWebElementPresent(selectProductsButton, getTimeOut());
        Assert.assertTrue(selectProductsButton.isDisplayed());
        selectProductsButton.click();
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public ProductDetailsPage selectPurchaseListAfterSearch(String purchaseList)
    {
        String locator="//input[(contains(@value,'"+purchaseList+"'))]";
        waitForElementPresent(locator, getTimeOut());
        WebElement ele = driver.findElement(byLocator(locator));
        _clickUsingJavaScript(ele);
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public ProductDetailsPage enterPurchaseListsToSearch(String purchaseList)
    {
        waitForWebElementPresent(searchPurchaseLists, getTimeOut());
        Assert.assertTrue(searchPurchaseLists.isDisplayed());
        searchPurchaseLists.clear();
        searchPurchaseLists.sendKeys(purchaseList);
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public ProductDetailsPage selectPurchaseListButton()
    {
        waitForWebElementPresent(purchaseListButton, getTimeOut());
        Assert.assertTrue(purchaseListButton.isDisplayed());
        scrollToElementView(purchaseListButton);
        purchaseListButton.click();
        //_waitForPageLoad(driver);
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public ProductDetailsPage clickOnAddToListButton()
    {
        waitForWebElementPresent(addToListButton, getTimeOut());
        Assert.assertTrue(addToListButton.isDisplayed());
        addToListButton.click();
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public ProductDetailsPage clickOnSubmitReviewButton()
    {
        waitForWebElementPresent(submitReviewButton, getTimeOut());
        Assert.assertTrue(submitReviewButton.isDisplayed());
        submitReviewButton.click();
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public ProductDetailsPage selectRating()
    {
        waitForWebElementPresent(yourRating, getTimeOut());
        Assert.assertTrue(yourRating.isDisplayed());
        yourRating.click();
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public ProductDetailsPage enterReviewDescription(String reviewDescription)
    {
        waitForWebElementPresent(reviewDescriptionBox, getTimeOut());
        Assert.assertTrue(reviewDescriptionBox.isDisplayed());
        reviewDescriptionBox.clear();
        reviewDescriptionBox.sendKeys(reviewDescription);
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public ProductDetailsPage enterReviewTitle(String reviewTitle)
    {
        waitForWebElementPresent(reviewTitleBox, getTimeOut());
        Assert.assertTrue(reviewTitleBox.isDisplayed());
        reviewTitleBox.clear();
        reviewTitleBox.sendKeys(reviewTitle);
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public ProductDetailsPage clickOnWriteAReviewButton()
    {
        waitForWebElementPresent(writeAReviewButton, getTimeOut());
        Assert.assertTrue(writeAReviewButton.isDisplayed());
        scrollToElementView(writeAReviewButton);
        writeAReviewButton.click();
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public boolean isQtyBoxPresent(String productCode)
    {
        
        return isElementPresent("//input[@name='items["+productCode+"]']");
        
    }
	
	public ProductDetailsPage clickOnViewDetails()
	{
		waitForWebElementPresent(viewDetails, getTimeOut());
		Assert.assertTrue(viewDetails.isDisplayed());
		scrollToElementView(viewDetails);
		viewDetails.click();
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public ProductDetailsPage scrollToSKU()
	{
		waitForWebElementPresent(skuOf111700, getTimeOut());
		Assert.assertTrue(skuOf111700.isDisplayed());
		scrollToElementView(skuOf111700);
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public ProductDetailsPage enterQTYForSKU(String skuId, String qty)
    {
        String locator = "//input[@name='items["+skuId+"]']";
        waitForWebElementPresent(driver.findElement(byLocator(locator)), getTimeOut());
        scrollToElementView(driver.findElement(byLocator(locator)));
        driver.findElement(byLocator(locator)).clear();
        driver.findElement(byLocator(locator)).sendKeys(qty);
        return PageFactory.initElements(driver, ProductDetailsPage.class);
    }
	
	public BasketPage clickOnCheckOutButton()
	{
		waitForWebElementPresent(checkOutButton, getTimeOut());
		scrollToElementView(checkOutButton);
		Assert.assertTrue(checkOutButton.isDisplayed());
		checkOutButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, BasketPage.class);
	}
	
	
	public ProductDetailsPage clickOnIncreaseQuantityButton(String number, String comment)
	{
		waitForWebElementPresent(increaseQuantityButton, getTimeOut());
		Assert.assertTrue(increaseQuantityButton.isDisplayed());
		for(int i=1; i<=Integer.parseInt(number); i++)
		{
			increaseQuantityButton.click();
		}
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public ProductDetailsPage enterQuantity(String numberOfProduct)
	{
		waitForWebElementPresent(quantityBox, getTimeOut());
		Assert.assertTrue(quantityBox.isDisplayed());
		quantityBox.clear();
		quantityBox.sendKeys(numberOfProduct);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public ProductDetailsPage clickOnAddToBasketButton()
	{
		waitForWebElementPresent(addToBasketButton, getTimeOut());
		scrollToElementView(addToBasketButton);
		Assert.assertTrue(addToBasketButton.isDisplayed());
		addToBasketButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}

}
