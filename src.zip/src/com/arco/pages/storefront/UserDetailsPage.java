package com.arco.pages.storefront;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.arco.util.ArcoDriverHelper;

public class UserDetailsPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//button[@id='sendreminder']")
	private WebElement sendReminderLink;
	
	public UserDetailsPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public UserDetailsPage clickOSendReminderLink()
	{
		scrollToElementView(sendReminderLink);
		waitForWebElementPresent(sendReminderLink, getTimeOut());
		Assert.assertTrue(sendReminderLink.isDisplayed());
		sendReminderLink.click();
		return PageFactory.initElements(driver, UserDetailsPage.class);
	}

}
