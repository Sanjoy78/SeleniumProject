package com.arco.pages.storefront;

import java.util.NoSuchElementException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class DashboardPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="(//strong)[1]")
	private WebElement userName;
	
	@FindBy(how=How.XPATH, using="//span[@title='header.link.b2b.account']")
	private WebElement accountDetails;
	
	@FindBy(how=How.XPATH, using="//a[@href='/my-account']")
	private WebElement accountOverview;
	
	@FindBy(how=How.XPATH, using="//a[@href='/logout']")
	private WebElement logOut;
	
	@FindBy(how=How.XPATH, using="//label[@class='org-unit-display']")
	private WebElement changeAccount;
	
	@FindBy(how=How.XPATH, using="//span[@class='glyphicon pull-right']")
	private WebElement changeAccountArrowDown;
	
	@FindBy(how=How.CLASS_NAME, using="glyphicon pull-right arrowUp")
	private WebElement changeAccountArrowUp;
	
	@FindBy(how=How.XPATH, using="(//input[@placeholder='Enter product name or code...'])[1]")
	private WebElement searchBox;
	
	@FindBy(how=How.XPATH, using="(//button[@class='glyphicon glyphicon-search'])[1]")
	private WebElement findButton;
	
	@FindBy(how=How.XPATH, using="//span[@class='nav-icon-text quickOrder']")
	private WebElement quickOrderButton;
	
	@FindBy(how=How.XPATH, using="//a[@class='btn btn-primary btn-block']")
	private WebElement signOutButton;
	
	@FindBy(how=How.XPATH, using="//a[@title='PurchasingList']")
	private WebElement purchaseListLink;
	
	@FindBy(how=How.XPATH, using="//input[@name='productCodes[0]']")
	private WebElement inputProductBox1;
	
	@FindBy(how=How.XPATH, using="//input[@name='productQtys[0]']")
	private WebElement inputQtyBox1;
	
	@FindBy(how=How.XPATH, using="(//button[contains(text(),'to Basket')])[1]")
	private WebElement addToBasketButton;
	
	@FindBy(how=How.XPATH, using="//a[text()='Checkout Now']")
	private WebElement checkOutButton;
	
	@FindBy(how=How.XPATH, using="//a[text()='Got it ']")
	private WebElement gotIt;
	
	@FindBy(how=How.XPATH, using="//a[@href='#copy-paste']")
	private WebElement copyPestLink;
	
	@FindBy(how=How.XPATH, using="//textarea[@id='quickOrderCSVData']")
	private WebElement quickOrderDataBox;
	
	@FindBy(how=How.XPATH, using="//input[@id='searchOrgUnit']")
    private WebElement enterOrgUnitInSearchBox;
	
	@FindBy(how=How.XPATH, using="//button[@id='confirmOrgUnitchange']")
    private WebElement clickOnDone;
	
	
	public DashboardPage (final WebDriver driver)
	{
		super(driver);
	}
	
	public DashboardPage IfGotItElementPresentThenClickOnIt()
    {
        //String locator= "//a[text()='Got it ']";
        //waitForElementPresent(locator, getTimeOut());
        //driver.manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
        boolean exists = driver.findElements( byLocator("//a[text()='Got it ']")).size() > 0;
        //driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        if(exists) {
        driver.findElement(byLocator("//a[text()='Got it ']")).click();
        }
      return PageFactory.initElements(driver, DashboardPage.class);
    }
	
	public DashboardPage clickOnDoneAfterAccountChanged()
    {
        waitForWebElementPresent(clickOnDone, getTimeOut());
        Assert.assertTrue(clickOnDone.isDisplayed());
        clickOnDone.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, DashboardPage.class);
    }
	
	public DashboardPage clickToSelectOrgUnit(String orgUnit)
    {
        String xpath = "//div[@id = '"+orgUnit+"']";
        WebElement ele = driver.findElement(byLocator(xpath));
        waitForWebElementPresent(ele, getTimeOut());
        Assert.assertTrue(ele.isDisplayed());
        ele.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, DashboardPage.class);
    }
	
	public DashboardPage enterOrgUnitToBeSearch(String orgUnit)
    {
        waitForWebElementPresent(enterOrgUnitInSearchBox, getTimeOut());
        Assert.assertTrue(enterOrgUnitInSearchBox.isDisplayed());
        enterOrgUnitInSearchBox.click();
        enterOrgUnitInSearchBox.clear();
        enterOrgUnitInSearchBox.sendKeys(orgUnit);
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, DashboardPage.class);
    }
	
	public DashboardPage clickOnchangeAccountButton()
    {
        waitForWebElementPresent(changeAccount, getTimeOut());
        Assert.assertTrue(changeAccount.isDisplayed());
        changeAccount.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, DashboardPage.class);
    }
	
	public DashboardPage enterDataInQuickOrderDataBox(String data)
	{
		waitForWebElementPresent(quickOrderDataBox, getTimeOut());
		scrollToElementView(quickOrderDataBox);
		Assert.assertTrue(quickOrderDataBox.isDisplayed());
		quickOrderDataBox.clear();
		quickOrderDataBox.sendKeys(data);
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public DashboardPage clickOnCopyPestLink()
	{
		waitForWebElementPresent(copyPestLink, getTimeOut());
		scrollToElementView(copyPestLink);
		Assert.assertTrue(copyPestLink.isDisplayed());
		copyPestLink.click();
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	
	public DashboardPage clickOnGotIt()
	{
		try
		{
			gotIt.click();
		} catch(NoSuchElementException ignored)
		{
			
		}
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public BasketPage clickOnCheckOutButton()
	{
		waitForWebElementPresent(checkOutButton, getTimeOut());
		Assert.assertTrue(checkOutButton.isDisplayed());
		checkOutButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, BasketPage.class);
	}
	
	public DashboardPage clickOnAddToBasketButton()
	{
		waitForWebElementPresent(addToBasketButton, getTimeOut());
		scrollToElementView(addToBasketButton);
		Assert.assertTrue(addToBasketButton.isDisplayed());
		addToBasketButton.click();
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public DashboardPage enterProductID(String productID)
	{
		waitForWebElementPresent(inputProductBox1, getTimeOut());
		Assert.assertTrue(inputProductBox1.isDisplayed());
		inputProductBox1.clear();
		inputProductBox1.sendKeys(productID);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public DashboardPage enterProductQty(String qty)
	{
		waitForWebElementPresent(inputQtyBox1, getTimeOut());
		Assert.assertTrue(inputQtyBox1.isDisplayed());
		inputQtyBox1.clear();
		inputQtyBox1.sendKeys(qty);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public PurchaseListPage clickPurchaseListLink()
	{
		waitForWebElementPresent(purchaseListLink, getTimeOut());
		Assert.assertTrue(purchaseListLink.isDisplayed());
		purchaseListLink.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public boolean quickOrderButtonIsDisplayed()
	{
		waitForWebElementPresent(quickOrderButton, getTimeOut());
		boolean result = false;
		if(quickOrderButton.isDisplayed())
		{
			result=true;
		} else
		{
			result = false;
		}
		return result;
	}
	
	public DashboardPage clickOnQuickOrderButton()
	{
		waitForWebElementPresent(quickOrderButton, getTimeOut());
		scrollToElementView(quickOrderButton);
		Assert.assertTrue(quickOrderButton.isDisplayed());
		quickOrderButton.click();
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public DashboardPage enterProductNameOrCode(String nameOrCode)
	{
		waitForWebElementPresent(searchBox, getTimeOut());
		scrollToElementView(searchBox);
		Assert.assertTrue(searchBox.isDisplayed());
		searchBox.clear();
		searchBox.sendKeys(nameOrCode);
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public CategoryListPage clickOnFindButton()
	{
		waitForWebElementPresent(findButton, getTimeOut());
		Assert.assertTrue(findButton.isDisplayed());
		findButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, CategoryListPage.class);
	}
	
	public ProductDetailsPage clickOnFindButtonToNavigatePDP()
	{
		waitForWebElementPresent(findButton, getTimeOut());
		scrollToElementView(findButton);
		Assert.assertTrue(findButton.isDisplayed());
		findButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public MyAccountPage clickAccountOverview()
	{
		waitForWebElementPresent(accountOverview, getTimeOut());
		Assert.assertTrue(accountOverview.isDisplayed());
		accountOverview.click();
		return PageFactory.initElements(driver, MyAccountPage.class);
	}
	
	public DashboardPage clickUserName()
	{
		waitForWebElementPresent(userName, getTimeOut());
		Assert.assertTrue(userName.isDisplayed());
		userName.click();
		return PageFactory.initElements(driver, DashboardPage.class);
	}
	
	public HomePage clickSignOutButton()
	{
		waitForWebElementPresent(signOutButton, getTimeOut());
		Assert.assertTrue(signOutButton.isDisplayed());
		signOutButton.click();
		return PageFactory.initElements(driver, HomePage.class);
	}

}
