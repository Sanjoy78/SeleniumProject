package com.arco.pages.storefront;

import java.util.Iterator;
import java.util.List;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class PurchaseListPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//a[@href='purchasingList/createEdit']")
	private WebElement createListButton;
	
	@FindBy(how=How.XPATH, using="//span[@id='slectAction']")
    private WebElement selectAnActionButton;

    @FindBy(how=How.XPATH, using="//a[.='Merge']")
    private WebElement mergePurchaseList;
    
    @FindBy(how=How.XPATH, using="//label[@for='plMergeDelete']")
    private WebElement selectMergeDeleteActionRadioButton;
    
    @FindBy(how=How.XPATH, using="//button[@id='plSelectBtn']")
    private WebElement selectMergeActionButton;
    
    @FindBy(how=How.XPATH, using="//span[@class='dropdown-toggle sort-toggle']")
    private WebElement purchaseListDropDown;
    
    
    @FindBy(how=How.XPATH, using="//button[@id='continueMerge']")
    private WebElement deletePLConfirmationYesButton;
	
	@FindBy(how=How.XPATH, using="//input[@id='purchaseNameTest']")
	private WebElement purchaseListName;
	
	@FindBy(how=How.XPATH, using="//select[@id='purchasingListType']")
	private WebElement purchaseListType;
	
	@FindBy(how=How.XPATH, using="//button[@class='purchaseFormButton disablePurchaseButton']")
	private WebElement doneButtonForPurchaseListCreation;
	
	@FindBy(how=How.XPATH, using="//button[@class='purchaseListDone']")
	private WebElement doneButtonAfterPurchaseListCreation;
	
	@FindBy(how=How.XPATH, using="//i[@class='fa fa-ellipsis-v dropdownBar-icon dropdown-toggle']")
	private WebElement dotsOfPersonalPurchaseList;
	
	@FindBy(how=How.XPATH, using="//i[@class='fa fa-ellipsis-v dropdownBar-icon dropdown-toggle']")
	private WebElement dotsOfAccountPurchaseList;
	
	@FindBy(how=How.XPATH, using="//a[@title='Edit']")
	private WebElement editButtonForPersonalPurchaseList;
	
	@FindBy(how=How.XPATH, using="//a[@title='Edit']")
	private WebElement editButtonForAccountPurchaseList;
	
	@FindBy(how=How.XPATH, using="(//a[@title='Delete'])[1]")
	private WebElement deleteButtonForAccountPurchaseList;
	
	@FindBy(how=How.XPATH, using="(//a[@title='Delete'])[1]")
	private WebElement deleteButtonForPersonalPurchaseList;
	
	@FindBy(how=How.XPATH, using="//input[@id='searchUserPurchageListInput']")
	private WebElement searchBoxForPurchaseList;
	
	@FindBy(how=How.XPATH, using="(//button[@class='purchaseFormButton'])[2]")
	private WebElement yesButtonForPLDeletation;
	
	@FindBy(how=How.XPATH, using="(//button[@class='purchaseListDone'])[2]")
	private WebElement doneButtonAfterPurchaseListDeletation;
	
	@FindBy(how=How.XPATH, using="(//a[@title='Edit'])[1]")
	private WebElement editButton;
	
	@FindBy(how=How.XPATH, using="//span[@id='slectAction']")
	private WebElement selectActionButton;
	
	@FindBy(how=How.XPATH, using="//a[@title='Merge']")
	private WebElement mergeButton;
	
	@FindBy(how=How.XPATH, using="//label[@for='plMergeKeep']")
	private WebElement mergeAndKeepEP;
	
	@FindBy(how=How.XPATH, using="//button[@id='plSelectBtn']")
	private WebElement selectButton;
	
	@FindBy(how=How.XPATH,using="//button[@class='purchaseListProdButton']")
    private WebElement buyNowButton;
	
	@FindBy(how=How.XPATH,using="(//input[@name='purchaseModalItems'])[1]")
    private WebElement qtyCheckboxForSKUpoupInGridViewPersonalPL;
	
	@FindBy(how=How.XPATH,using="(//span[@class='purchaseListModalPlusQuantity pplGrid'])[1]")
    private WebElement qutIncreaseButtonInGridView;
	
	@FindBy(how=How.XPATH,using="(//div[@class='col-sm-6 footerSkuButtons']/button[@type='button'])[3]")
    private WebElement addtoBasketButtonInGridview;
	
	@FindBy(how=How.XPATH, using="//input[@id='searchUserPurchageListInput']")
    private WebElement searchBoxForProductCode;
	
	@FindBy(how=How.XPATH, using="//span[@id='slectAction']")
    private WebElement selectAnAction;
	
	@FindBy(how=How.XPATH, using="//a[@class='removeproduct removeProductFromPL']")
    private WebElement removeProduct;
	
	@FindBy(how=How.XPATH, using="//button[@id='removeProductFromPLButton']")
    private WebElement yesButton;
	
	@FindBy(how=How.XPATH, using="(//div[@class='text-right paddingx2 top-space-large']/button)[2]")
    private WebElement doneButton;
	
	@FindBy(how=How.XPATH, using="//button[@class='btn btn-primary skuSingleAddToBasket pplDoneButton']")
    private WebElement doneButtonAfterRemoveSKU;
	
	String allPLXpath = "//a[@class='name purchaseListName plName']";
	
	String pllPageXpath = "//a[@class='page']";
	
	
	
	public PurchaseListPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public PurchaseListPage clickOnDoneButtonAfterRemoveSKU()
    {
        waitForWebElementPresent(doneButtonAfterRemoveSKU, getTimeOut());
        Assert.assertTrue(doneButtonAfterRemoveSKU.isDisplayed());
        doneButtonAfterRemoveSKU.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, PurchaseListPage.class);
    }
	
	public PurchaseListPage clickOnRemoveSKUFromPurchaseList(String skuId)
    {
        String locator = "(//div[@data-skureferencecode='"+skuId+"']/following::a[@title='Remove'])[1]";
        waitForElementPresent(locator, getTimeOut());
        clickOn(locator, skuId+"Clicking on remove button for specific sku");
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, PurchaseListPage.class);
    }
	
	public Boolean isDecoratedProductPresent(String skuId)
    {
        return isElementPresent("//input[@value='"+skuId+"']/following::span[text()='"+skuId+"']");
        
    }
	
	public PurchaseListPage clickOnDoneButton()
    {
        waitForWebElementPresent(doneButton, getTimeOut());
        Assert.assertTrue(doneButton.isDisplayed());
        doneButton.click();
        _waitForPageLoad(driver);

        return PageFactory.initElements(driver, PurchaseListPage.class);
    }
	
	public PurchaseListPage clickOnYesButton()
    {
        waitForWebElementPresent(yesButton, getTimeOut());
        Assert.assertTrue(yesButton.isDisplayed());
        yesButton.click();
        return PageFactory.initElements(driver, PurchaseListPage.class);
    }
	
	public PurchaseListPage clickOnremoveProduct()
    {
        waitForWebElementPresent(removeProduct, getTimeOut());
        waitForElementToBeClickable(removeProduct, getTimeOut());
        Assert.assertTrue(removeProduct.isDisplayed());
        removeProduct.click();
        
        return PageFactory.initElements(driver, PurchaseListPage.class);
    }
	
	public PurchaseListPage clickOnselectAnAction()
	{
	    waitForWebElementPresent(selectAnAction, getTimeOut());
	    waitForElementToBeClickable(selectAnAction, getTimeOut());
	    Assert.assertTrue(selectAnAction.isDisplayed());
	    selectAnAction.click();

	    return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage searchBoxForAProductCode(String plName)
    {
        waitForWebElementPresent(searchBoxForProductCode, getTimeOut());
        Assert.assertTrue(searchBoxForProductCode.isDisplayed());
        searchBoxForProductCode.clear();
        searchBoxForProductCode.sendKeys(plName);
        
        return PageFactory.initElements(driver, PurchaseListPage.class);
    }
	
	public Boolean isAddtobasketbuttonEnable()
    {
        boolean result = false;
        try
        {
        waitForWebElementPresent(addtoBasketButtonInGridview, getTimeOut());
        if(addtoBasketButtonInGridview.isEnabled())
        {
        	result = true;
        	
        }
        
        } catch (Exception ex)
        {
            
        }
        return result;
    }
	
	public PurchaseListPage clickOnIncreaseQtybuttonInGridview()
    {
        waitForWebElementPresent(qutIncreaseButtonInGridView, getTimeOut());
        Assert.assertTrue(qutIncreaseButtonInGridView.isDisplayed());
        qutIncreaseButtonInGridView.click();
        return PageFactory.initElements(driver, PurchaseListPage.class);
        
    }
	
	public PurchaseListPage enterQtyInSkupopupinGridview(String qtyNumber)
    {
        waitForWebElementPresent(qtyCheckboxForSKUpoupInGridViewPersonalPL, getTimeOut());
        Assert.assertTrue(qtyCheckboxForSKUpoupInGridViewPersonalPL.isDisplayed());
        qtyCheckboxForSKUpoupInGridViewPersonalPL.clear();
        qtyCheckboxForSKUpoupInGridViewPersonalPL.sendKeys(qtyNumber);
        return PageFactory.initElements(driver, PurchaseListPage.class);
        
    }
	
	public PurchaseListPage clickOnBuyNowButton()
	  {
		  scrollToElementView(buyNowButton);
	      waitForWebElementPresent(buyNowButton, getTimeOut());
	      Assert.assertTrue(buyNowButton.isDisplayed());
	      buyNowButton.click();
	      return PageFactory.initElements(driver, PurchaseListPage.class);
	  }
	
	public Boolean isbuyNowButtonpresent()
    {
        boolean result = false;
        try
        {
        waitForWebElementPresent(buyNowButton, getTimeOut());
        buyNowButton.isDisplayed();
        result = true;
        } catch (Exception ex)
        {
            
        }
        return result;
    }
	
	public PurchaseListPage clickOnPurchaseListDropDown()
    {
        waitForWebElementPresent(purchaseListDropDown, getTimeOut());
        Assert.assertTrue(purchaseListDropDown.isDisplayed());
        purchaseListDropDown.click();
        return PageFactory.initElements(driver, PurchaseListPage.class);
    }
	
	public PurchaseListPage clickOnSelectAnActionButton()
    {
        waitForWebElementPresent(selectAnActionButton, getTimeOut());
        Assert.assertTrue(selectAnActionButton.isDisplayed());
        selectAnActionButton.click();
        return PageFactory.initElements(driver, PurchaseListPage.class);
    }

public PurchaseListPage clickOnMergePurchaseList()
    {
    waitForWebElementPresent(mergePurchaseList, getTimeOut());
    Assert.assertTrue(mergePurchaseList.isDisplayed());
    mergePurchaseList.click();
    return PageFactory.initElements(driver, PurchaseListPage.class);
    }
public PurchaseListPage clickOnMergeDeleteActionRadioButton()
    {
        waitForWebElementPresent(selectMergeDeleteActionRadioButton, getTimeOut());
        Assert.assertTrue(selectMergeDeleteActionRadioButton.isDisplayed());
        selectMergeDeleteActionRadioButton.click();
        return PageFactory.initElements(driver, PurchaseListPage.class);
    }
public PurchaseListPage clickOnSelectButton()
    {
        waitForWebElementPresent(selectMergeActionButton, getTimeOut());
        Assert.assertTrue(selectMergeActionButton.isDisplayed());
        selectMergeActionButton.click();
        return PageFactory.initElements(driver, PurchaseListPage.class);
    }
public PurchaseListPage clickOnYesButtonForConfirmation()
    {
        waitForWebElementPresent(deletePLConfirmationYesButton, getTimeOut());
        Assert.assertTrue(deletePLConfirmationYesButton.isDisplayed());
        deletePLConfirmationYesButton.click();
        return PageFactory.initElements(driver, PurchaseListPage.class);
    }
public Boolean verifyPLNotExist(String plName)
{
    boolean result = false;
    String locator = "//a[@title='"+plName+"']";
    waitForElementNotPresent(locator, getTimeOut());
    try
    {
        driver.findElement(byLocator(locator)).isDisplayed();
        result = true;
    } catch (Exception e)
    {
        System.out.println(e.getMessage());
    }
    return result;
}

public Boolean verifyPLExist(String plName)
{
	boolean result = false;
    String locator = "//a[@title='"+plName+"']";
    waitForElementPresent(locator, getTimeOut());
    try
    {
    	driver.findElement(byLocator(locator)).isDisplayed();
        result = true;
    }catch (Exception e)
    {
        System.out.println(e.getMessage());
    }
    return result;
}
	
	public Boolean verifyPLExist(String plName, List<WebElement> allPL)
    {
        boolean result = false;
        Iterator<WebElement> itr = allPL.iterator();
        while(itr.hasNext())
        {
            WebElement currentWE = itr.next();
            String currentWEName = currentWE.getText();
            if(currentWEName.equalsIgnoreCase(plName))
            {
                result = true;
                break;
            }
        }
        return result;
    }
	
	/*
	public List<WebElement> allPage()
	{
		return allWebElement(pllPageXpath);
	}
	
	public void movePage(List<WebElement> allPage)
	{
		Iterator<WebElement> itr = allPage.iterator();
		while(itr.hasNext())
		{
			WebElement currentPage = itr.next();
			waitForWebElementPresent(currentPage, getTimeOut());
			Assert.assertTrue(currentPage.isDisplayed());
			currentPage.click();
		}
	}
	*/
	public PurchaseListPage clickSelectButton()
	{
		waitForWebElementPresent(selectButton, getTimeOut());
		Assert.assertTrue(selectButton.isDisplayed());
		selectButton.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickMergeButton()
	{
		waitForWebElementPresent(mergeButton, getTimeOut());
		Assert.assertTrue(mergeButton.isDisplayed());
		mergeButton.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public Boolean verifyExistPLName(String plName)

	   {
	        boolean result = false;
	        String locator = "//a[@title='"+plName+"']";
	        waitForElementPresent(locator, getTimeOut());
	        try
	        {
	            driver.findElement(byLocator(locator)).isDisplayed();
	            result = true;
	        } catch (Exception e)
	        {
	            System.out.println(e.getMessage());
	        }

	       return result;

	   }
	
	public PurchaseListPage clickOnCopyForAPL(String plName)
	  {
	      String locator = "//input[@value='"+plName+"']/following::a[@title='Copy']";
	      waitForElementPresent(locator, getTimeOut());
	      clickOn(locator, plName+" Clicking on copy button for specific PL");
	      return PageFactory.initElements(driver, PurchaseListPage.class);
	  }
	
	public PurchaseListPage clickMergeAndKeepEP()
	{
		waitForWebElementPresent(mergeAndKeepEP, getTimeOut());
		Assert.assertTrue(mergeAndKeepEP.isDisplayed());
		mergeAndKeepEP.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickSelectActionButton()
	{
		waitForWebElementPresent(selectActionButton, getTimeOut());
		Assert.assertTrue(selectActionButton.isDisplayed());
		selectActionButton.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	public List<WebElement> allPL()
	{
		return allWebElement(allPLXpath);
	}
	
	public Boolean searchPLExist(String plName, List<WebElement> allPL)
	{
		boolean result = false;
		Iterator<WebElement> itr = allPL.iterator();
		while(itr.hasNext())
		{
			WebElement currentWE = itr.next();
			String currentWEName = currentWE.getText();
			if(currentWEName.equalsIgnoreCase(plName))
			{
				result = true;
				break;
			}
		}
		return result;
	}
	/*
	public Boolean searchPLExistInAllPage(String plName, List<WebElement> allPL, List<WebElement> allPage)
	{
		//boolean result = false;
		boolean result = searchPLExist(plName, allPL);
		while(result==false)
		{
			movePage(allPage);
			result = searchPLExist(plName, allPL);
		}
		return result;
		
	}
	*/
	public PurchaseListPage clickOnEditButton()
	{
		waitForWebElementPresent(editButton, getTimeOut());
		Assert.assertTrue(editButton.isDisplayed());
		editButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnCheckBoxForAPL(String plName)
	{
		String locator = "//input[@value='"+plName+"']";
		waitForElementPresent(locator, getTimeOut());
		WebElement ele = driver.findElement(byLocator(locator));
		scrollToElementView(ele);
		Actions builder = new Actions(driver);
		builder.moveToElement(ele).click().build().perform();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnDotForAPL(String plName)
	{
		String locator = "//input[@value='"+plName+"']/following::i[1]";
		waitForElementPresent(locator, getTimeOut());
		scrollToElementView(driver.findElement(byLocator(locator)));
		clickOn(locator, plName+" clicking on three dots for specific PL");
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnEditForAPL(String plName)
	{
		String locator = "//input[@value='"+plName+"']/following::a[@title='Edit']";
		waitForElementPresent(locator, getTimeOut());
		clickOn(locator, plName+" Clicking on edit button for specific PL");
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnDeleteForAPL(String plName)
	{
		String locator = "//input[@value='"+plName+"']/following::a[@title='Delete']";
		waitForElementPresent(locator, getTimeOut());
		clickOn(locator, plName+" Clicking on delete button for specific PL");
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnViewForAPL(String plName)
	{
		String locator = "//input[@value='"+plName+"']/following::a[@title='View']";
		waitForElementPresent(locator, getTimeOut());
		clickOn(locator, plName+" Clicking on edit button for specific PL");
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnDoneButtonAfterPLDeletation()
	{
		waitForWebElementPresent(doneButtonAfterPurchaseListDeletation, getTimeOut());
		Assert.assertTrue(doneButtonAfterPurchaseListDeletation.isDisplayed());
		doneButtonAfterPurchaseListDeletation.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnYesButtonForPLDetetation()
	{
		waitForWebElementPresent(yesButtonForPLDeletation, getTimeOut());
		Assert.assertTrue(yesButtonForPLDeletation.isDisplayed());
		yesButtonForPLDeletation.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnDeleteButtonForPersonalPurchaseList()
	{
		waitForWebElementPresent(deleteButtonForPersonalPurchaseList, getTimeOut());
		Assert.assertTrue(deleteButtonForPersonalPurchaseList.isDisplayed());
		deleteButtonForPersonalPurchaseList.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnDeleteButtonForAccountPurchaseList()
	{
		waitForWebElementPresent(deleteButtonForAccountPurchaseList, getTimeOut());
		Assert.assertTrue(deleteButtonForAccountPurchaseList.isDisplayed());
		deleteButtonForAccountPurchaseList.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnEditButtonForPersonalPurchaseList()
	{
		waitForWebElementPresent(editButtonForPersonalPurchaseList, getTimeOut());
		Assert.assertTrue(editButtonForPersonalPurchaseList.isDisplayed());
		editButtonForPersonalPurchaseList.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnEditButtonForAccountPurchaseList()
	{
		waitForWebElementPresent(editButtonForAccountPurchaseList, getTimeOut());
		Assert.assertTrue(editButtonForAccountPurchaseList.isDisplayed());
		editButtonForAccountPurchaseList.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnDotsOfAccoutPurchaseList()
	{
		waitForWebElementPresent(dotsOfAccountPurchaseList, getTimeOut());
		Assert.assertTrue(dotsOfAccountPurchaseList.isDisplayed());
		dotsOfAccountPurchaseList.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickOnDotsOfPersonalPurchaseList()
	{
		waitForWebElementPresent(dotsOfPersonalPurchaseList, getTimeOut());
		Assert.assertTrue(dotsOfPersonalPurchaseList.isDisplayed());
		dotsOfPersonalPurchaseList.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage searchPurchaseListByName(String plName)
	{
		waitForWebElementPresent(searchBoxForPurchaseList, getTimeOut());
		Assert.assertTrue(searchBoxForPurchaseList.isDisplayed());
		searchBoxForPurchaseList.clear();
		searchBoxForPurchaseList.sendKeys(plName);
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickCreateListButton()
	{
		waitForWebElementPresent(createListButton, getTimeOut());
		Assert.assertTrue(createListButton.isDisplayed());
		createListButton.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage enterPurchaseListName(String name)
	{
		waitForWebElementPresent(searchBoxForProductCode, getTimeOut());
		Assert.assertTrue(searchBoxForProductCode.isDisplayed());
		searchBoxForProductCode.clear();
		searchBoxForProductCode.sendKeys(name);
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage selectPersonalPurchaseListType()
	{
		waitForWebElementPresent(purchaseListType, getTimeOut());
		Assert.assertTrue(purchaseListType.isDisplayed());
		selectDropDown(purchaseListType, "Personal");
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage selectAccountPurchaseListType()
	{
		waitForWebElementPresent(purchaseListType, getTimeOut());
		Assert.assertTrue(purchaseListType.isDisplayed());
		selectDropDown(purchaseListType, "Account");
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickDoneButtonForPurchaseListCreation()
	{
		waitForWebElementPresent(doneButtonForPurchaseListCreation, getTimeOut());
		Assert.assertTrue(doneButtonForPurchaseListCreation.isDisplayed());
		doneButtonForPurchaseListCreation.click();
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public PurchaseListPage clickDoneButtonAfterPurchaseListCreation()
	{
		waitForWebElementPresent(doneButtonAfterPurchaseListCreation, getTimeOut());
		waitForElementToBeClickable(doneButtonAfterPurchaseListCreation, getTimeOut());
		Assert.assertTrue(doneButtonAfterPurchaseListCreation.isDisplayed());
		doneButtonAfterPurchaseListCreation.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, PurchaseListPage.class);
	}
	
	public Boolean isPLTypeEnable()
	{
		boolean result = false;
		try
		{
		waitForWebElementPresent(purchaseListType, getTimeOut());
		purchaseListType.isEnabled();
		result = true;
		} catch (Exception ex)
		{
			
		}
		return result;
	}
	

}
