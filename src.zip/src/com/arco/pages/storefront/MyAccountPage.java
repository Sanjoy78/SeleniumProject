package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;



public class MyAccountPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//h2[text()='Roles, Groups and Org Units']/following::a[text()='Manage'][1]")
	private WebElement manageRoleGroupsAndORGUnitsButton;
	
	@FindBy(how=How.XPATH, using="//a[@href='/my-account/user-management']")
	private WebElement userManagementLink;
	
	@FindBy(how=How.XPATH, using="(//a[@href='/my-account/address-book'])[1]")
	private WebElement manageAddress;
	
	@FindBy(how=How.XPATH, using="(//a[@href='/my-account/address-book'])[1]")
    private WebElement manageAddresses;
	
	@FindBy(how=How.XPATH, using="//a[@href='/my-account/productAccessControlList'][1]")
    private WebElement manageProductAccessControl;
	
	public MyAccountPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public ProductAccessControlPage clickOnManageProductAccessControlButton()
    {
        waitForWebElementPresent(manageProductAccessControl, getTimeOut());
        Assert.assertTrue(manageProductAccessControl.isDisplayed());
        manageProductAccessControl.click();
        return PageFactory.initElements(driver, ProductAccessControlPage.class);
    }
	
	public AddressBookPage clickManageAddressesButton()
    {
        waitForWebElementPresent(manageAddresses, getTimeOut());
        Assert.assertTrue(manageAddresses.isDisplayed());
        manageAddresses.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, AddressBookPage.class);
    }
	
	public RolesGroupsAndOrgUnitsPage clickManageRoleGroupsAndORGUnitsButton()
	{
		waitForWebElementNotPresent(manageRoleGroupsAndORGUnitsButton, getTimeOut());
		Assert.assertTrue(manageRoleGroupsAndORGUnitsButton.isDisplayed());
		manageRoleGroupsAndORGUnitsButton.click();
		return PageFactory.initElements(driver, RolesGroupsAndOrgUnitsPage.class);
	}
	
	public AddressBookPage clickOnManageAddress()
	{
		waitForWebElementPresent(manageAddress, getTimeOut());
		Assert.assertTrue(manageAddress.isDisplayed());
		manageAddress.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, AddressBookPage.class);
	}
	
	public UserManagementPage clickOnUserManagementLink()
	{
		waitForWebElementPresent(userManagementLink, getTimeOut());
		Assert.assertTrue(userManagementLink.isDisplayed());
		userManagementLink.click();
		return PageFactory.initElements(driver, UserManagementPage.class);
	}

}
