package com.arco.pages.storefront;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.arco.util.ArcoDriverHelper;

public class HaveAccountNumberPage extends ArcoDriverHelper
{
	@FindBy(how=How.ID, using="actNo")
	private WebElement noAccountNumber;
	
	@FindBy(how=How.ID, using="actYes")
	private WebElement yesAccountNumber;
	
	@FindBy(how=How.XPATH, using="//button[@class='btn btn-primary btn-block-user m-b col-sm-4 col-md-4 col-lg-4']")
	private WebElement continueButton;
	
	@FindBy(how=How.ID, using="b2bRegister.accountNumber")
	private WebElement accountNumber;
			
	public HaveAccountNumberPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public HaveAccountNumberPage selectNoAccount()
	{
		waitForWebElementPresent(noAccountNumber, getTimeOut());
		Assert.assertTrue(noAccountNumber.isDisplayed());
		noAccountNumber.click();
		return PageFactory.initElements(driver, HaveAccountNumberPage.class);
	}
	
	public HaveAccountNumberPage selectYesAccount()
	{
		waitForWebElementPresent(yesAccountNumber, getTimeOut());
		Assert.assertTrue(yesAccountNumber.isDisplayed());
		yesAccountNumber.click();
		return PageFactory.initElements(driver, HaveAccountNumberPage.class);
	}
	
	public HaveAccountNumberPage enterAccountNumber(String account)
	{
		waitForWebElementPresent(accountNumber, getTimeOut());
		Assert.assertTrue(accountNumber.isDisplayed());
		accountNumber.sendKeys(account);
		return PageFactory.initElements(driver, HaveAccountNumberPage.class);
	}
	
	public VerifyAccountPage clickContinueButtonForAccount()
	{
		waitForWebElementPresent(continueButton, getTimeOut());
		Assert.assertTrue(continueButton.isDisplayed());
		continueButton.click();
		return PageFactory.initElements(driver, VerifyAccountPage.class);
	}

	public EnterPersonalDetailsPage clickContinueButtonForCash()
	{
		waitForWebElementPresent(continueButton, getTimeOut());
		Assert.assertTrue(continueButton.isDisplayed());
		continueButton.click();
		return PageFactory.initElements(driver, EnterPersonalDetailsPage.class);
	}
}
