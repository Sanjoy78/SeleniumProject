package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class RegistrationSuccessPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//h1")
	private WebElement successMessage;
	
	@FindBy(how=How.XPATH, using="//img[@alt='Arco Home Page']")
	private WebElement homePageLogo;
	
	public RegistrationSuccessPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public HomePage clickOnHomePageLogo()
	{
		waitForWebElementPresent(homePageLogo, getTimeOut());
		Assert.assertTrue(homePageLogo.isDisplayed());
		homePageLogo.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, HomePage.class);
	}

}
