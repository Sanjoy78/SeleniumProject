package com.arco.pages.storefront;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class CategoryListPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="(//button[@id='buynow1'])[1]")
	private WebElement buyNowButton;
	
	@FindBy(how=How.XPATH, using="(//span[@class='plpQtyPlus'])[2]")
	private WebElement increaseQuantityButton;
	
	@FindBy(how=How.XPATH, using="(//button[text()='Add to Basket'])[3]")
	private WebElement addToBasketButton;
	
	@FindBy(how=How.XPATH, using="//a[contains(@href,'/p/PIM2606000')]")
	private WebElement productPIM2606000;
	
	@FindBy(how=How.XPATH, using="(//button[@class='btn btn-default addToListBtn btn-block dropdown-toggle'])[1]")
    private WebElement addToList;
	
	@FindBy(how=How.XPATH, using="(//a[@class='addToPurchasingList'])[1]")
    private WebElement addToPurchasingList;
	
	@FindBy(how=How.XPATH, using="//input[@id='profilesearchpurchaselists']")
    private WebElement searchPurchaseList;
	
	@FindBy(how=How.XPATH, using="//button[@id='modelPurchaseListAddProductsBtn']")
    private WebElement selectProductButton;
	
	
	public CategoryListPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public CategoryListPage clickOnSelectProductCheckBox(String productId)
    {
        String locator="//input[@name='items["+productId+"]'and @value='"+productId+"']";
        waitForElementPresent(locator, getTimeOut());
        clickOn(locator,"Here click on checkbox to select product's sku");
        return PageFactory.initElements(driver, CategoryListPage.class);
    }
	
	public CategoryListPage clickOnSelectProductButton()
    {
        waitForWebElementPresent(selectProductButton, getTimeOut());
        Assert.assertTrue(selectProductButton.isDisplayed());
        selectProductButton.click();
        return PageFactory.initElements(driver, CategoryListPage.class);
    }
	
	public CategoryListPage enterSearchPurchaseList(String purchaseListName)
    {
        waitForWebElementPresent(searchPurchaseList, getTimeOut());
        Assert.assertTrue(searchPurchaseList.isDisplayed());
        searchPurchaseList.sendKeys(purchaseListName);
        return PageFactory.initElements(driver, CategoryListPage.class);
    }
	
	public CategoryListPage clickOnAddToPurchaseList()
    {
        waitForWebElementPresent(addToPurchasingList, getTimeOut());
        Assert.assertTrue(addToPurchasingList.isDisplayed());
        addToPurchasingList.click();
        return PageFactory.initElements(driver, CategoryListPage.class);
    }
	
	public CategoryListPage clickOnAddToList()
    {
        waitForWebElementPresent(addToList, getTimeOut());
        Assert.assertTrue(addToList.isDisplayed());
        addToList.click();
        return PageFactory.initElements(driver, CategoryListPage.class);
    }
	
	public Boolean isSkuActive(String skuCode)
    {
        
        return isElementPresent("//div[@id='skuSection-"+skuCode+"']");
        
    }
	
	public CategoryListPage clickOnBuyNowButtonForABaseProduct(String productName)
    {
    
        String locator = "//a[contains(@title,'"+productName+"')]/following::button[contains(@class,'plpBuyNow')][1]";
        waitForElementPresent(locator, getTimeOut());
        scrollToElementView(driver.findElement(byLocator(locator)));
        driver.findElement(byLocator(locator)).click();
        waitForElementVisible("//h4[text()='"+productName+"']", getTimeOut());
        
        return PageFactory.initElements(driver, CategoryListPage.class);
    }
	
	public CategoryListPage clickOnACategory(String value)
	{
		String locator = "(//span[text()='"+value+"'])[1]";
		WebElement ele = driver.findElement(byLocator(locator));
		scrollToElementView(ele);
		ele.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, CategoryListPage.class);
	}
	
	public ProductDetailsPage clickOnProductPIM2606000()
	{
		waitForWebElementPresent(productPIM2606000, getTimeOut());
		Assert.assertTrue(productPIM2606000.isDisplayed());
		productPIM2606000.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, ProductDetailsPage.class);
	}
	
	public CategoryListPage clickOnBuyNowButton()
	{
		waitForWebElementPresent(buyNowButton, getTimeOut());
		Assert.assertTrue(buyNowButton.isDisplayed());
		buyNowButton.click();
		return PageFactory.initElements(driver, CategoryListPage.class);
	}
	
	public CategoryListPage clickOnincreaseQuantityButton(String number, String comment)
	{
		waitForWebElementPresent(increaseQuantityButton, getTimeOut());
		Assert.assertTrue(increaseQuantityButton.isDisplayed());
		for(int i=1; i<=Integer.parseInt(number);i++)
		{
			increaseQuantityButton.click();
		}
		return PageFactory.initElements(driver, CategoryListPage.class);
	}
	
	public CategoryListPage clickOnAddToBasketButton()
	{
		waitForWebElementPresent(addToBasketButton, getTimeOut());
		Assert.assertTrue(addToBasketButton.isDisplayed());
		addToBasketButton.click();
		return PageFactory.initElements(driver, CategoryListPage.class);
	}

}
