package com.arco.pages.backoffice;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.arco.util.ArcoDriverHelper;

public class B2BCustomerPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//button[@title='Switch search mode']")
	private WebElement switchSearchMode;
	
	@FindBy(how=How.XPATH, using="(//span[@class='ye-com_hybris_cockpitng_editor_defaultenum z-combobox z-combobox-readonly'])[3]")
	private WebElement userState;
	
	@FindBy(how=How.XPATH, using="//span[text() = 'AUTHORISED']")
    private WebElement authorisedButton;
	
	@FindBy(how=How.XPATH, using="//span[contains(text(),'VERIFIED')]")
	private WebElement verifiedButton;
	
	@FindBy(how=How.XPATH, using="//button[text()='Search']")
	private WebElement searchButton;
	
	@FindBy(how=How.XPATH, using="//img[@title='Export List View To CSV Action']")
	private WebElement csvExportIcon;
	
	@FindBy(how=How.XPATH, using="//input[@class='z-bandbox-input z-bandbox-rightedge']")
	private WebElement searchBox;
	
	@FindBy(how=How.XPATH, using="(//span[@class='yw-listview-cell-label z-label'])[2]")
	private WebElement user;
	
	@FindBy(how=How.XPATH, using="//img[@title='Delete Action [Delete]']")
	private WebElement deleteButton;
	
	@FindBy(how=How.XPATH, using="//button[text()='Yes']")
	private WebElement yesButton;
	
	@FindBy(how=How.XPATH, using="(//button[@class='yw-expandCollapse z-button'])[1]")
    private WebElement clickOnExpandArrow;

   @FindBy(how=How.XPATH, using="//span[text()='Administration']")
    private WebElement clickOnAdministartion;
   
   @FindBy(how=How.XPATH, using="//button[text()='Save']")
   private WebElement saveButton;
   
   @FindBy(how=How.XPATH, using="(//input[@class='ye-input-text ye-com_hybris_cockpitng_editor_defaulttext z-textbox'])[21]")
   private WebElement enterSAPContactID;
	
	public B2BCustomerPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public B2BCustomerPage enterSAPContactIDInTextBox(String contactID)
    {
        waitForWebElementPresent(enterSAPContactID, getTimeOut());
        Assert.assertTrue(enterSAPContactID.isDisplayed());
        scrollToElementView(enterSAPContactID);
        enterSAPContactID.click();
        enterSAPContactID.clear();
        enterSAPContactID.sendKeys(contactID);
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, B2BCustomerPage.class);
    }
	
	public B2BCustomerPage clickOnSaveButton()
	{
		waitForWebElementPresent(saveButton, getTimeOut());
		waitForElementToBeClickable(saveButton, getTimeOut());
		Assert.assertTrue(saveButton.isDisplayed());
		saveButton.click();
		waitForElementPresent("//div[@class='yw-notification-message success z-div']", getTimeOut());
		return PageFactory.initElements(driver, B2BCustomerPage.class);
	}
	
	public B2BCustomerPage clickOnExpandArrowButton()
    {
        waitForWebElementPresent(clickOnExpandArrow, getTimeOut());
        Assert.assertTrue(clickOnExpandArrow.isDisplayed());
        clickOnExpandArrow.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, B2BCustomerPage.class);
    }
public B2BCustomerPage clickOnAdministrationTab()
    {
        waitForWebElementPresent(clickOnAdministartion, getTimeOut());
        Assert.assertTrue(clickOnAdministartion.isDisplayed());
        clickOnAdministartion.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, B2BCustomerPage.class);
    }
	
	public B2BCustomerPage clickOnYesButton()
	{
		waitForWebElementPresent(yesButton, getTimeOut());
		Assert.assertTrue(yesButton.isDisplayed());
		yesButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, B2BCustomerPage.class);
	}
	
	public B2BCustomerPage clickOnDeleteButton()
	{
		waitForWebElementPresent(deleteButton, getTimeOut());
		Assert.assertTrue(deleteButton.isDisplayed());
		deleteButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, B2BCustomerPage.class);
	}
	
	public B2BCustomerPage selectUser()
	{
		waitForWebElementPresent(user, getTimeOut());
		Assert.assertTrue(user.isDisplayed());
		user.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, B2BCustomerPage.class);
	}
	
	public B2BCustomerPage enterValueInSearchBox(String value)
	{
		waitForWebElementPresent(searchBox, getTimeOut());
		Assert.assertTrue(searchBox.isDisplayed());
		searchBox.clear();
		searchBox.sendKeys(value);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, B2BCustomerPage.class);
	}
	
	public B2BCustomerPage clickcsvExportIcon()
	{
		waitForWebElementPresent(csvExportIcon, getTimeOut());
		Assert.assertTrue(csvExportIcon.isDisplayed());
		csvExportIcon.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, B2BCustomerPage.class);
	}
	
	public B2BCustomerPage clickOnSearchButton()
	{
		waitForWebElementPresent(searchButton, getTimeOut());
		Assert.assertTrue(searchButton.isDisplayed());
		searchButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, B2BCustomerPage.class);
	}
	
	public B2BCustomerPage clickOnVerifiedButton()
	{
		waitForWebElementPresent(verifiedButton, getTimeOut());
		Assert.assertTrue(verifiedButton.isDisplayed());
		verifiedButton.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, B2BCustomerPage.class);
	}
	
	public B2BCustomerPage clickOnSwitchSearchMode()
	{
		waitForWebElementPresent(switchSearchMode, getTimeOut());
		Assert.assertTrue(switchSearchMode.isDisplayed());
		switchSearchMode.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, B2BCustomerPage.class);
	}
	
	public B2BCustomerPage scrollToUserState()
	{
		waitForWebElementPresent(userState, getTimeOut());
		Assert.assertTrue(userState.isDisplayed());
		scrollToElementView(userState);
		return PageFactory.initElements(driver, B2BCustomerPage.class);
	}
	
	public B2BCustomerPage clickOnDownArrowForUserState()
	{
		waitForWebElementPresent(userState, getTimeOut());
		Assert.assertTrue(userState.isDisplayed());
		userState.click();
		_waitForJStoLoad();
		return PageFactory.initElements(driver, B2BCustomerPage.class);
	}
	
	public B2BCustomerPage clickOnAuthorisedButton()
    {
        waitForWebElementPresent(authorisedButton, getTimeOut());
        Assert.assertTrue(authorisedButton.isDisplayed());
        authorisedButton.click();
        _waitForJStoLoad();
        return PageFactory.initElements(driver, B2BCustomerPage.class);
    }
	
	

}
