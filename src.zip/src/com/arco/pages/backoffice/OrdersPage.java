package com.arco.pages.backoffice;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.arco.util.ArcoDriverHelper;

public class OrdersPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//input[@class='z-bandbox-input z-bandbox-rightedge']")
	private WebElement searchBox;
	
	@FindBy(how=How.XPATH, using="//button[text()='Search']")
	private WebElement searchButton;
	
	@FindBy(how=How.XPATH, using="(//span[@class='yw-listview-cell-label z-label'])[2]")
	private WebElement order;
	
	@FindBy(how=How.XPATH, using="(//div[contains(@id,'-right')]//i[@class='z-icon-chevron-right'])[1]")
	private WebElement arrowButtonToMoveRight;
	
	@FindBy(how=How.XPATH, using="(//button[@class='yw-expandCollapse z-button'])[1]")
    private WebElement clickOnExpandArrow;

	public OrdersPage(final WebDriver driver) 
	{
		super(driver);
	}
	
	public OrdersPage clickOnArrowButtonToMoveRight(int n)
	{
		waitForWebElementPresent(arrowButtonToMoveRight, getTimeOut());
		waitForElementToBeClickable(arrowButtonToMoveRight, getTimeOut());
		Assert.assertTrue(arrowButtonToMoveRight.isDisplayed());
		Assert.assertTrue(arrowButtonToMoveRight.isEnabled());
		for(int i=0;i<=n;i++)
		{
			arrowButtonToMoveRight.click();
			_waitForJStoLoad();
		}
		return PageFactory.initElements(driver, OrdersPage.class);
	}
	
	public OrdersPage clickOnExpandArrowButton()
    {
        waitForWebElementPresent(clickOnExpandArrow, getTimeOut());
        Assert.assertTrue(clickOnExpandArrow.isDisplayed());
        clickOnExpandArrow.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, OrdersPage.class);
    }
	
	public OrdersPage enterValueInSearchBox(String value)
	{
		waitForWebElementPresent(searchBox, getTimeOut());
		Assert.assertTrue(searchBox.isDisplayed());
		searchBox.clear();
		searchBox.sendKeys(value);
		_waitForJStoLoad();
		return PageFactory.initElements(driver, OrdersPage.class);
	}
	
	public OrdersPage clickOnSearchButton()
	{
		waitForWebElementPresent(searchButton, getTimeOut());
		Assert.assertTrue(searchButton.isDisplayed());
		searchButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, OrdersPage.class);
	}
	
	public OrdersPage selectOrder()
	{
		waitForWebElementPresent(order, getTimeOut());
		Assert.assertTrue(order.isDisplayed());
		order.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, OrdersPage.class);
	}

}
