package com.arco.pages.backoffice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class BackofficeDashboardPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//input[@placeholder='Filter Tree entries']")
	private WebElement searchTreeBox;
	
	@FindBy(how=How.XPATH, using="//span[text()='B2B Customer']")
	private WebElement B2BCustomer;
	
	@FindBy(how=How.XPATH, using="//span[text()='No DataHub instances configured. The DataHub perspective will not be functional until you configure at least a single DataHub server.']")
	private WebElement errorMessage;
	
	@FindBy(how=How.XPATH, using="//span[contains(text(),'Orders')]")
	private WebElement orders;
	
	public BackofficeDashboardPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public BackofficeDashboardPage clickOnALeftNavigationMenu(String value)
	{
		String locator = "//span[text()='"+value+"']";
		waitForElementPresent(locator, getTimeOut());
		WebElement ele =		driver.findElement(byLocator(locator));
		scrollToElementView(ele);
		ele.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, BackofficeDashboardPage.class);
	}
	
	public Boolean isLeftNavigationMenuDisplayed(String value)
	{
		String locator = "//span[text()='"+value+"']";
		WebElement ele = driver.findElement(byLocator(locator));
		return isElementPresent(ele);
		
	}
	
	public BackofficeDashboardPage ifOkMessageDisplayThenClickOnIt()
	{
		boolean exist = driver.findElements(byLocator("//button[text()='OK']")).size()>0;
		if(exist)
		{
			driver.findElement(byLocator("//button[text()='OK']")).click();
		}
		_waitForJStoLoad();
		return PageFactory.initElements(driver, BackofficeDashboardPage.class);
	}
	
	public BackofficeDashboardPage ifErrorMessageExistThenClickOnIt()
	{
		boolean exist = driver.findElements(byLocator("//span[text()='No DataHub instances configured. The DataHub perspective will not be functional until you configure at least a single DataHub server.']")).size()>0;
		if(exist)
		{
			driver.findElement(byLocator("//span[text()='No DataHub instances configured. The DataHub perspective will not be functional until you configure at least a single DataHub server.']")).click();
		}
		_waitForJStoLoad();
		return PageFactory.initElements(driver, BackofficeDashboardPage.class);
	}
	
	public BackofficeDashboardPage enterSearchTermInSearchTreeBox(String value)
	{
		waitForWebElementPresent(searchTreeBox, getTimeOut());
		Assert.assertTrue(searchTreeBox.isDisplayed());
		searchTreeBox.clear();
		searchTreeBox.sendKeys(value);
		_waitForJStoLoad();
		waitForElementVisible("//span[text()='"+value+"']", getTimeOut());
		return PageFactory.initElements(driver, BackofficeDashboardPage.class);
	}
	
	public B2BCustomerPage clickOnB2BCustomer()
	{
		waitForWebElementPresent(B2BCustomer, getTimeOut());
		Assert.assertTrue(B2BCustomer.isDisplayed());
		B2BCustomer.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, B2BCustomerPage.class);
	}
	
	public OrdersPage clickOnOrders()
	{
		waitForWebElementPresent(orders, getTimeOut());
		Assert.assertTrue(orders.isDisplayed());
		orders.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, OrdersPage.class);
	}

}
