package com.arco.pages.backoffice;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.arco.util.ArcoDriverHelper;
import com.arco.util.PropertyReaderArco;


public class BackofficeHomePage extends ArcoDriverHelper
{
	@FindBy(how=How.NAME, using="j_username")
	private WebElement userName;
	
	@FindBy(how=How.NAME, using="j_password")
	private WebElement passWord;
	
	public BackofficeHomePage(final WebDriver driver)
	{
		super(driver);
	}
	
	public BackofficeHomePage enterUserName(final String username) {
		waitForWebElementPresent(userName, getTimeOut());
		userName.clear();
		userName.sendKeys(username);

		return PageFactory.initElements(driver, BackofficeHomePage.class);
	}

	public BackofficeHomePage enterPassword(final String password) {
		passWord.clear();
		passWord.sendKeys(password);
		return PageFactory.initElements(driver, BackofficeHomePage.class);
	}

	public BackofficeDashboardPage login() throws Exception 
	{
		String emailID = propertyReader.readApplicationFile(PropertyReaderArco.getDomain() + "_BackofficeUser");
		String password = propertyReader.readApplicationFile(PropertyReaderArco.getDomain() + "_Password");
		enterUserName(emailID);
		enterPassword(password);
		Robot robot = new Robot();
		  robot.keyRelease(KeyEvent.VK_TAB);
		  Thread.sleep(5000);
		  robot.keyPress(KeyEvent.VK_ENTER);
		  Thread.sleep(5000);
		  _waitForPageLoad(driver);
		return PageFactory.initElements(driver, BackofficeDashboardPage.class);
	}
	
	
}
