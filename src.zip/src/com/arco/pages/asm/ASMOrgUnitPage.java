package com.arco.pages.asm;

import com.arco.util.ArcoDriverHelper;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class ASMOrgUnitPage extends ArcoDriverHelper
{
	
	 
	 
	 @FindBy(how=How.XPATH, using="(//a[@href='/my-account'])[1]")
	    private WebElement accountOverview;

	    @FindBy(how=How.XPATH, using="(//div[@id='orgUnitDisplay']/div)[1]")
	    private WebElement clickRootOrgUnit;
	    
	    @FindBy(how=How.XPATH, using="(//div[@id='orgUnitDisplay']/a)[2]")
	    private WebElement clickUnitOrg;
	    
	    @FindBy(how=How.XPATH, using="(//div[@id='orgUnitDisplay']/a)[3]")
	    private WebElement clickOrgUnit;
	    
	    @FindBy(how=How.XPATH, using="//select[@id='org-setting']")
	    private WebElement clickToSelectUserFromDropdown;
	    
	    @FindBy(how=How.XPATH, using="//select[@id='org-setting']")
	    private WebElement clickToSelectPurchaseListFromDropdown;
	    
	    @FindBy(how=How.XPATH, using="(//strong)[4]")
	    private WebElement userName;
	    
	    @FindBy(how=How.XPATH, using="//button[@class='btn btn-primary orgUnitPLassociateBtn']")
	    private WebElement clickAssociateButton;
	    
	    @FindBy(how=How.XPATH, using="//input[@placeholder='search purchase lists']")
	    private WebElement searchBox;
	    
	    @FindBy(how=How.XPATH, using="(//div[text()='Account'])[12]")
	    private WebElement clickToSelectPurchaseListAfterSearch;
	    
	    @FindBy(how=How.XPATH, using="//a[@title='PurchasingList']")
	    private WebElement purchaseListLink;
	    
	    public ASMOrgUnitPage(WebDriver webdriver)
	    {
	        super(webdriver);
	        
	    }
	    
	    public ASMUserPurchaseListPage clickOnPurchaseListLink()
	    {
	        waitForWebElementPresent(purchaseListLink, getTimeOut());
	        Assert.assertTrue(purchaseListLink.isDisplayed());
	        purchaseListLink.click();
	        return PageFactory.initElements(driver, ASMUserPurchaseListPage.class);
	    }
	    
	    public ASMOrgUnitPage clickToSelectPurchaseListAfterSearch()
	    {
	        waitForWebElementPresent(clickToSelectPurchaseListAfterSearch, getTimeOut());
	        Assert.assertTrue(clickToSelectPurchaseListAfterSearch.isDisplayed());
	        _clickUsingJavaScript(clickToSelectPurchaseListAfterSearch);
	        return PageFactory.initElements(driver, ASMOrgUnitPage.class);
	    }
	    
	    public ASMOrgUnitPage enterPurchaseListInSearchBox(String purchaseListName)
	    {
	        waitForWebElementPresent(searchBox, getTimeOut());
	        Assert.assertTrue(searchBox.isDisplayed());
	        searchBox.click();
	        searchBox.clear();
	        searchBox.sendKeys(purchaseListName);
	        return PageFactory.initElements(driver, ASMOrgUnitPage.class);
	    }
	    
	    
	    public ASMOrgUnitPage clickOnAssociateButton()
	    {
	        waitForWebElementPresent(clickAssociateButton, getTimeOut());
	        Assert.assertTrue(clickAssociateButton.isDisplayed());
	        clickAssociateButton.click();
	        return PageFactory.initElements(driver, ASMOrgUnitPage.class);
	    }
	    
	    public ASMUserMyAccountPage clickAccountOverview()
	    {
	        waitForWebElementPresent(accountOverview, getTimeOut());
	        Assert.assertTrue(accountOverview.isDisplayed());
	        accountOverview.click();
	        return PageFactory.initElements(driver, ASMUserMyAccountPage.class);
	    }
	    
	    
	    public ASMOrgUnitPage clickUserName()
	    {
	        waitForWebElementPresent(userName, getTimeOut());
	        Assert.assertTrue(userName.isDisplayed());
	        userName.click();
	        return PageFactory.initElements(driver, ASMOrgUnitPage.class);
	    }

	    public Boolean isUserPresent(String user)
	    {
	        String locator = "//label[text()='"+user+"']";
	        WebElement el = driver.findElement(byLocator(locator));
	        return isElementPresent(el);
	    }
	    
	    
	    public ASMOrgUnitPage clickToExpandRootOrgUnit()
	    {
	        waitForWebElementPresent(clickRootOrgUnit, getTimeOut());
	        Assert.assertTrue(clickRootOrgUnit.isDisplayed());
	        clickRootOrgUnit.click();
	        return PageFactory.initElements(driver, ASMOrgUnitPage.class);
	    }

	    public ASMOrgUnitPage clickToSelectUnitOrg()
	    {
	        waitForWebElementPresent(clickUnitOrg, getTimeOut());
	        Assert.assertTrue(clickUnitOrg.isDisplayed());
	        _clickUsingJavaScript(clickUnitOrg);
	        _waitForPageLoad(driver);
	        return PageFactory.initElements(driver, ASMOrgUnitPage.class);
	    }
	    
	    public ASMOrgUnitPage clickToSelectOrgUnit()
	    {
	        waitForWebElementPresent(clickOrgUnit, getTimeOut());
	        Assert.assertTrue(clickOrgUnit.isDisplayed());
	        _clickUsingJavaScript(clickOrgUnit);
	        _waitForPageLoad(driver);
	        return PageFactory.initElements(driver, ASMOrgUnitPage.class);
	    }
	    
	    public ASMOrgUnitPage clickToSelectUserFromDropdownList()
	    {
	        waitForWebElementPresent(clickToSelectUserFromDropdown, getTimeOut());
	        Assert.assertTrue(clickToSelectUserFromDropdown.isDisplayed());
	        selectDropDown(clickToSelectUserFromDropdown, "Users");
	        return PageFactory.initElements(driver, ASMOrgUnitPage.class);
	    }
	    
	    public ASMOrgUnitPage clickToSelectPurchaseListFromDropdownList()
	    {
	        waitForWebElementPresent(clickToSelectPurchaseListFromDropdown, getTimeOut());
	        Assert.assertTrue(clickToSelectPurchaseListFromDropdown.isDisplayed());
	        selectDropDown(clickToSelectPurchaseListFromDropdown, "Purchase Lists");
	        _waitForPageLoad(driver);
	        return PageFactory.initElements(driver, ASMOrgUnitPage.class);
	        
	    }

}
