package com.arco.pages.asm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.pages.storefront.DashboardPage;
import com.arco.util.ArcoDriverHelper;

public class ASMUserMyAccountPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//img[@alt='Arco Home Page']")
	private WebElement homePageLogo;
	
	@FindBy(how=How.XPATH, using="(//a[@href='/my-account/user-management'])[1]")
    private WebElement userManagementLink;
	
	public ASMUserMyAccountPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public ASMUserDashboardPage clickOnHomePageLogo()
	{
		waitForWebElementPresent(homePageLogo, getTimeOut());
		Assert.assertTrue(homePageLogo.isDisplayed());
		homePageLogo.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ASMUserDashboardPage.class);
	}
	
	public ASMUserUserManagementPage clickOnUserManagementLink()
    {
        waitForWebElementPresent(userManagementLink, getTimeOut());
        Assert.assertTrue(userManagementLink.isDisplayed());
        userManagementLink.click();
        return PageFactory.initElements(driver, ASMUserUserManagementPage.class);
    }

}
