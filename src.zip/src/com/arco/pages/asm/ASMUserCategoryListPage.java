package com.arco.pages.asm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.arco.pages.storefront.ProductDetailsPage;
import com.arco.util.ArcoDriverHelper;

public class ASMUserCategoryListPage extends ArcoDriverHelper
{
	
	public ASMUserCategoryListPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public ASMUserProductDetailsPage clickOnAProductInASM(String productid)
	{
		String locator = "//a[contains(@href,'/p/"+productid+"')]";
		waitForElementPresent(locator, getTimeOut());
		scrollToElementView(driver.findElement(byLocator(locator)));
		clickOn(locator, productid+" base product");
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ASMUserProductDetailsPage.class);
	}

}
