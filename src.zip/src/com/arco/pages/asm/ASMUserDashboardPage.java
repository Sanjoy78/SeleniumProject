package com.arco.pages.asm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.pages.storefront.PurchaseListPage;
import com.arco.util.ArcoDriverHelper;

public class ASMUserDashboardPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//a[@title='PurchasingList']")
	private WebElement purchaseListLink;
	
	@FindBy(how=How.XPATH, using="(//input[@placeholder='Enter product name or code...'])[1]")
	private WebElement searchBox;
	
	@FindBy(how=How.XPATH, using="(//button[@class='glyphicon glyphicon-search'])[1]")
	private WebElement findButton;
	
	public ASMUserDashboardPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public ASMUserCategoryListPage clickOnFindButton()
	{
		waitForWebElementPresent(findButton, getTimeOut());
		Assert.assertTrue(findButton.isDisplayed());
		findButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ASMUserCategoryListPage.class);
	}
	
	
	
	public ASMUserProductDetailsPage clickOnFindButtonToNavigatePDP()
	{
		waitForWebElementPresent(findButton, getTimeOut());
		Assert.assertTrue(findButton.isDisplayed());
		findButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ASMUserProductDetailsPage.class);
	}
	
	public ASMDashboardPage enterProductNameOrCode(String nameOrCode)
	{
		waitForWebElementPresent(searchBox, getTimeOut());
		Assert.assertTrue(searchBox.isDisplayed());
		searchBox.sendKeys(nameOrCode);
		return PageFactory.initElements(driver, ASMDashboardPage.class);
	}
	
	public ASMUserPurchaseListPage clickPurchaseListLink()
	{
		waitForWebElementPresent(purchaseListLink, getTimeOut());
		Assert.assertTrue(purchaseListLink.isDisplayed());
		purchaseListLink.click();
		return PageFactory.initElements(driver, ASMUserPurchaseListPage.class);
	}

}
