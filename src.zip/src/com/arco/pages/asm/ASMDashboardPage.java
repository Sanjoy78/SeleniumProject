package com.arco.pages.asm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.pages.storefront.CategoryListPage;
import com.arco.pages.storefront.DashboardPage;
import com.arco.util.ArcoDriverHelper;

public class ASMDashboardPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//button[@class='ASM-btn ASM-btn-logout']")
	private WebElement logOutButton;
	
	@FindBy(how=How.XPATH, using="//input[@aria-describedby='arcoCustomerName']")
	private WebElement customerNameOrEmailId;
	
	@FindBy(how=How.XPATH, using="//span[@class='name boldAsmUserName']")
	private WebElement user;
	
	@FindBy(how=How.XPATH, using="//button[@class='ASM-btn ASM-btn-start-session']")
	private WebElement startSessionButton;
	
	@FindBy(how=How.XPATH, using="(//input[@placeholder='Select Org Unit'])[2]")
    private WebElement orgUnit;
	
	@FindBy(how=How.XPATH, using="//span[text()='100691']")
    private WebElement selectOrgUnit;
	
	@FindBy(how=How.XPATH, using="//span[text()='MANAGE ORG']")
    private WebElement manageOrg;
	
	public ASMDashboardPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public ASMOrgUnitPage clickManageOrgButton()
    {
        waitForWebElementPresent(manageOrg, getTimeOut());
        Assert.assertTrue(manageOrg.isDisplayed());
        manageOrg.click();
        _waitForPageLoad(driver);
        return PageFactory.initElements(driver, ASMOrgUnitPage.class);
    }
	
	public ASMOrgUnitPage selectOrgUnit(String orgUnit)
    {
		String locator = "//span[text()='"+orgUnit+"']";
		WebElement ele = driver.findElement(byLocator(locator));
		
        waitForWebElementPresent(ele, getTimeOut());
        Assert.assertTrue(ele.isDisplayed());
        ele.click();
        
        return PageFactory.initElements(driver, ASMOrgUnitPage.class);
    }
	
	public ASMDashboardPage enterOrgUnit(String value)
    {
        waitForWebElementPresent(orgUnit, getTimeOut());
        Assert.assertTrue(orgUnit.isDisplayed());
        orgUnit.click();
        orgUnit.clear();
        orgUnit.sendKeys(value);
        waitForElementPresent("//span[text()='"+value+"']", getTimeOut());
        return PageFactory.initElements(driver, ASMDashboardPage.class);
    }
	
	public ASMUserMyAccountPage clickOnStartSessionButton()
	{
		waitForWebElementPresent(startSessionButton, getTimeOut());
		Assert.assertTrue(startSessionButton.isDisplayed());
		startSessionButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ASMUserMyAccountPage.class);
	}
	
	public ASMDashboardPage selectUser()
	{
		waitForWebElementPresent(user, getTimeOut());
		Assert.assertTrue(user.isDisplayed());
		user.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ASMDashboardPage.class);
		
	}
	
	public ASMHomePage clickOnLogOutButton()
	{
		waitForWebElementPresent(logOutButton, getTimeOut());
		Assert.assertTrue(logOutButton.isDisplayed());
		logOutButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ASMHomePage.class);
	}
	
	public ASMDashboardPage enterCustomerNameOrEmailId(String value)
	{
		waitForWebElementPresent(customerNameOrEmailId, getTimeOut());
		scrollToElementView(customerNameOrEmailId);
		customerNameOrEmailId.clear();
		customerNameOrEmailId.sendKeys(value);
		return PageFactory.initElements(driver, ASMDashboardPage.class);
	}

}
