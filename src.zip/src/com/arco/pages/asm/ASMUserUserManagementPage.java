package com.arco.pages.asm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.util.ArcoDriverHelper;

public class ASMUserUserManagementPage extends ArcoDriverHelper
{
	
	@FindBy(how=How.XPATH, using="//label[@for='user-name1_ibmtestersarco+johnhigginsdev1@gmail.com']")
    private WebElement clickToSelectUserCheckBox ;
	
	public ASMUserUserManagementPage (final WebDriver driver)
	{
		super(driver);
	}
	
	 public Boolean isSelectAnActionCTAButton()
	    {
	        return isElementPresent("//span[text()='Select an action']");
	    }

	    public ASMUserUserManagementPage clickToSelectUser()
	    {
	        waitForWebElementPresent(clickToSelectUserCheckBox, getTimeOut());
	        Assert.assertTrue(clickToSelectUserCheckBox.isDisplayed());
	        scrollToElementView(clickToSelectUserCheckBox);
	        clickToSelectUserCheckBox.click();
	        return PageFactory.initElements(driver, ASMUserUserManagementPage.class);
	    }

}
