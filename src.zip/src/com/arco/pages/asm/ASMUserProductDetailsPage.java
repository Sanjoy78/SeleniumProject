package com.arco.pages.asm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.arco.util.ArcoDriverHelper;

public class ASMUserProductDetailsPage extends ArcoDriverHelper
{
	
	@FindBy(how=How.XPATH, using="//button[@class='btn btn-default addToListBtn btn-block dropdown-toggle']")
	private WebElement addToListButton;
	
	@FindBy(how=How.XPATH, using="//a[@title='Purchase list']")
	private WebElement purchaseListButton;
	
	@FindBy(how=How.XPATH, using="//input[@id='profilesearchpurchaselists']")
	private WebElement searchPLBox;
	
	@FindBy(how=How.XPATH, using="//button[@id='modelPurchaseListAddProductsBtn']")
	private WebElement selectProductButton;
	
	@FindBy(how=How.XPATH, using="//button[@id='addToMultipleListBtn']")
	private WebElement addToPlButton;
	
	@FindBy(how=How.XPATH, using="//button[@id='purchaseListSuccessBtn']")
	private WebElement doneButton;
	
	
	
	public ASMUserProductDetailsPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public ASMUserProductDetailsPage clickOnDoneButton()
	{
		waitForWebElementPresent(doneButton, getTimeOut());
		scrollToElementView(doneButton);
		doneButton.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ASMUserProductDetailsPage.class);
	}
	
	public ASMUserProductDetailsPage clickOnAddToPlButton()
	{
		waitForWebElementPresent(addToPlButton, getTimeOut());
		scrollToElementView(addToPlButton);
		addToPlButton.click();
		return PageFactory.initElements(driver, ASMUserProductDetailsPage.class);
	}
	
	public ASMUserProductDetailsPage selectAnSKU(String sku)
	{
		String locator = "//input[@value='"+sku+"']";
		WebElement el = driver.findElement(byLocator(locator));
		_clickUsingJavaScript(el);
		return PageFactory.initElements(driver, ASMUserProductDetailsPage.class);
	}
	
	public ASMUserProductDetailsPage clickOnSelectProductButton()
	{
		waitForWebElementPresent(selectProductButton, getTimeOut());
		scrollToElementView(selectProductButton);
		selectProductButton.click();
		return PageFactory.initElements(driver, ASMUserProductDetailsPage.class);
	}
	
	public ASMUserProductDetailsPage selectAPL(String name)
	{
		String locator = "//input[@value='"+name+":Account']";
		waitForElementPresent(locator, getTimeOut());
		WebElement el = driver.findElement(byLocator(locator));
		_clickUsingJavaScript(el);
		return PageFactory.initElements(driver, ASMUserProductDetailsPage.class);
	}
	
	public ASMUserProductDetailsPage enterPlNameInSearchPLBox(String plname)
	{
		waitForWebElementPresent(searchPLBox, getTimeOut());
		scrollToElementView(searchPLBox);
		searchPLBox.clear();
		searchPLBox.sendKeys(plname);
		return PageFactory.initElements(driver, ASMUserProductDetailsPage.class);
	}
	
	public ASMUserProductDetailsPage clickOnAddToListButton()
	{
		waitForWebElementPresent(addToListButton, getTimeOut());
		scrollToElementView(addToListButton);
		addToListButton.click();
		return PageFactory.initElements(driver, ASMUserProductDetailsPage.class);
	}
	
	public ASMUserProductDetailsPage clickOnPurchaseListButton()
	{
		waitForWebElementPresent(purchaseListButton, getTimeOut());
		scrollToElementView(purchaseListButton);
		purchaseListButton.click();
		return PageFactory.initElements(driver, ASMUserProductDetailsPage.class);
	}

}
