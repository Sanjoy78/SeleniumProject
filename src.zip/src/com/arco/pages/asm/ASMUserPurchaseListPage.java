package com.arco.pages.asm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.arco.pages.storefront.PurchaseListPage;
import com.arco.util.ArcoDriverHelper;

public class ASMUserPurchaseListPage extends ArcoDriverHelper
{
	@FindBy(how=How.XPATH, using="//a[@href='purchasingList/createEdit']")
	private WebElement createListButton;
	
	@FindBy(how=How.XPATH, using="//span[@id='slectAction']")
    private WebElement selectAnActionButton;
	
	@FindBy(how=How.XPATH, using="//input[@id='purchaseNameTest']")
	private WebElement purchaseListName;
	
	@FindBy(how=How.XPATH, using="//select[@id='purchasingListType']")
	private WebElement purchaseListType;
	
	@FindBy(how=How.XPATH, using="//button[@class='purchaseFormButton disablePurchaseButton']")
	private WebElement doneButtonForPurchaseListCreation;
	
	@FindBy(how=How.XPATH, using="//button[@class='purchaseListDone']")
	private WebElement doneButtonAfterPurchaseListCreation;
	
	@FindBy(how=How.XPATH, using="//input[@id='searchUserPurchageListInput']")
	private WebElement searchBoxForPurchaseList;
	
	  @FindBy(how=How.XPATH, using="//button[@id='continueMerge']")
	    private WebElement deletePLConfirmationYesButton;
	  
	  @FindBy(how=How.XPATH, using="//span[@id='slectAction']")
      private WebElement selectActionDropdown;
	
	public ASMUserPurchaseListPage(final WebDriver driver)
	{
		super(driver);
	}
	
	public ASMUserPurchaseListPage clickOnSlectActionDropdown()
    {
        waitForWebElementPresent(selectActionDropdown, getTimeOut());
        Assert.assertTrue(selectActionDropdown.isDisplayed());
        selectActionDropdown.click();
        return PageFactory.initElements(driver, ASMUserPurchaseListPage.class);
    }
	
	public ASMUserPurchaseListPage clickOnCheckBoxForAPL(String plName)
    {
        String locator = "//input[@value='"+plName+"']";
        waitForElementPresent(locator, getTimeOut());
        WebElement ele = driver.findElement(byLocator(locator));
        Actions builder = new Actions(driver);
        builder.moveToElement(ele).click().build().perform();
        return PageFactory.initElements(driver, ASMUserPurchaseListPage.class);
    }
	
	public ASMUserPurchaseListPage clickOnYesButtonForConfirmation()
    {
        waitForWebElementPresent(deletePLConfirmationYesButton, getTimeOut());
        Assert.assertTrue(deletePLConfirmationYesButton.isDisplayed());
        deletePLConfirmationYesButton.click();
        return PageFactory.initElements(driver, ASMUserPurchaseListPage.class);
    }
	
	public ASMUserPurchaseListPage clickOnDotForAPL(String plName)
	{
		String locator = "//input[@value='"+plName+"']/following::i[1]";
		waitForElementPresent(locator, getTimeOut());
		scrollToElementView(driver.findElement(byLocator(locator)));
		clickOn(locator, plName+" clicking on three dots for specific PL");
		return PageFactory.initElements(driver, ASMUserPurchaseListPage.class);
	}
	
	public ASMUserPurchaseListPage clickOnDeleteForAPL(String plName)
	{
		String locator = "//input[@value='"+plName+"']/following::a[@title='Delete']";
		waitForElementPresent(locator, getTimeOut());
		clickOn(locator, plName+" Clicking on delete button for specific PL");
		_waitForJStoLoad();
		return PageFactory.initElements(driver, ASMUserPurchaseListPage.class);
	}
	
	public ASMUserPurchaseListPage searchPurchaseListByName(String plName)
	{
		waitForWebElementPresent(searchBoxForPurchaseList, getTimeOut());
		Assert.assertTrue(searchBoxForPurchaseList.isDisplayed());
		searchBoxForPurchaseList.clear();
		searchBoxForPurchaseList.sendKeys(plName);
		return PageFactory.initElements(driver, ASMUserPurchaseListPage.class);
	}
	
	public ASMUserPurchaseListPage clickCreateListButton()
	{
		waitForWebElementPresent(createListButton, getTimeOut());
		Assert.assertTrue(createListButton.isDisplayed());
		createListButton.click();
		return PageFactory.initElements(driver, ASMUserPurchaseListPage.class);
	}
	
	public ASMUserPurchaseListPage enterPurchaseListName(String name)
	{
		waitForWebElementPresent(purchaseListName, getTimeOut());
		Assert.assertTrue(purchaseListName.isDisplayed());
		purchaseListName.clear();
		purchaseListName.sendKeys(name);
		return PageFactory.initElements(driver, ASMUserPurchaseListPage.class);
	}
	
	public ASMUserPurchaseListPage selectAccountPurchaseListType()
	{
		waitForWebElementPresent(purchaseListType, getTimeOut());
		Assert.assertTrue(purchaseListType.isDisplayed());
		selectDropDown(purchaseListType, "Account");
		return PageFactory.initElements(driver, ASMUserPurchaseListPage.class);
	}
	
	public ASMUserPurchaseListPage clickDoneButtonForPurchaseListCreation()
	{
		waitForWebElementPresent(doneButtonForPurchaseListCreation, getTimeOut());
		Assert.assertTrue(doneButtonForPurchaseListCreation.isDisplayed());
		doneButtonForPurchaseListCreation.click();
		return PageFactory.initElements(driver, ASMUserPurchaseListPage.class);
	}
	
	public ASMUserPurchaseListPage clickDoneButtonAfterPurchaseListCreation()
	{
		waitForWebElementPresent(doneButtonAfterPurchaseListCreation, getTimeOut());
		Assert.assertTrue(doneButtonAfterPurchaseListCreation.isDisplayed());
		doneButtonAfterPurchaseListCreation.click();
		_waitForPageLoad(driver);
		return PageFactory.initElements(driver, ASMUserPurchaseListPage.class);
	}

}
