package com.arco.backoffice.funtionality;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.arco.pages.backoffice.B2BCustomerPage;
import com.arco.pages.backoffice.BackofficeDashboardPage;
import com.arco.pages.backoffice.BackofficeHomePage;
import com.arco.util.ArcoDriverTestCase;

public class DeleteUser extends ArcoDriverTestCase
{
	private String searchTerm;
	private BackofficeHomePage backofficeHomePage;
	private BackofficeDashboardPage backofficeDashboardPage;
	private B2BCustomerPage b2BCustomerPage;
	
	public DeleteUser()
	{
		
	}
	
	public void deleteUser(String userId) throws Exception
	{
		try
		{
			searchTerm = "B2B Customer";
			backofficeHomePage = applicationSetupBackoffice();
			backofficeDashboardPage = backofficeHomePage.login();
			backofficeDashboardPage.ifErrorMessageExistThenClickOnIt();
			backofficeDashboardPage.enterSearchTermInSearchTreeBox(searchTerm);
			b2BCustomerPage = backofficeDashboardPage.clickOnB2BCustomer();
			b2BCustomerPage.enterValueInSearchBox(userId);
			b2BCustomerPage.clickOnSearchButton();
			b2BCustomerPage.selectUser();
			b2BCustomerPage.clickOnDeleteButton();
			b2BCustomerPage.clickOnYesButton();
			
		} catch (Exception e)
		{
			throw e;
		} catch (Error e)
		{
			throw e;
		}
		
		
	}

}
